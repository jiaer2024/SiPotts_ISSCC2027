# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk/cons_mode
create_ccopt_skew_group -name clk/cons_mode -from_clocks {clk} -from_constraint_modes {cons_mode} -from_delay_corners {fast_delay fast_delay typ_delay typ_delay slow_delay slow_delay} -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 0.077 -sinks {couple_en_reg/CP rd_rdy_bus_reg_0_/CP rd_rdy_bus_reg_1_/CP rd_rdy_bus_reg_2_/CP rd_rdy_bus_reg_3_/CP rd_rdy_bus_reg_4_/CP rd_rdy_bus_reg_5_/CP rd_rdy_bus_reg_6_/CP rd_rdy_bus_reg_7_/CP wr_vld_bus_reg_0_/CP wr_vld_bus_reg_1_/CP wr_vld_bus_reg_2_/CP wr_vld_bus_reg_3_/CP wr_vld_bus_reg_4_/CP wr_vld_bus_reg_5_/CP wr_vld_bus_reg_6_/CP wr_vld_bus_reg_7_/CP p_out_vld_g_reg/CP p_out_g_reg/CP p_code_vld_bus_reg_0_/CP p_code_vld_bus_reg_1_/CP p_code_vld_bus_reg_2_/CP p_code_vld_bus_reg_3_/CP p_code_vld_bus_reg_4_/CP p_code_vld_bus_reg_5_/CP p_code_vld_bus_reg_6_/CP p_code_vld_bus_reg_7_/CP rd_vld_g_reg/CP rd_data_out_g_reg/CP wr_data_in_g_d2_reg/CP ul_cur_state_d1_reg_0_/CP phase_row_id_d2_reg_0_/CP phase_row_id_d1_reg_0_/CP phase_row_id_d2_reg_1_/CP phase_row_id_d1_reg_1_/CP phase_row_id_d2_reg_2_/CP phase_row_id_d1_reg_2_/CP dl_cur_state_d2_reg/CP dl_cur_state_d1_reg/CP phase_row_id_reg_2_/CP phase_row_id_reg_1_/CP phase_row_id_reg_0_/CP phase_col_id_reg_6_/CP phase_col_id_reg_5_/CP phase_col_id_reg_4_/CP phase_col_id_reg_3_/CP phase_col_id_reg_2_/CP phase_col_id_reg_1_/CP dl_cur_state_reg/CP phase_col_id_reg_0_/CP rd_row_id_d1_reg_0_/CP rd_row_id_d1_reg_1_/CP rd_row_id_d1_reg_2_/CP rd_row_id_reg_0_/CP rd_row_id_reg_1_/CP rd_row_id_reg_2_/CP row_id_reg_2_/CP row_id_reg_1_/CP row_id_reg_0_/CP col_id_reg_10_/CP col_id_reg_9_/CP col_id_reg_8_/CP col_id_reg_7_/CP col_id_reg_6_/CP col_id_reg_5_/CP col_id_reg_4_/CP col_id_reg_3_/CP col_id_reg_2_/CP col_id_reg_1_/CP ul_cur_state_reg_0_/CP ul_cur_state_reg_1_/CP col_id_reg_0_/CP p_en_d2_reg/CP p_en_d1_reg/CP wr_data_in_g_d1_reg/CP en_g_d1_reg/CP} -rank 0 -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
# Skew Group: clk/cons_mode
create_ccopt_skew_group -name clk/cons_mode -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default