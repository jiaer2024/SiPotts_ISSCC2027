# ccopt saved state skew_groups.tcl.gz

## Tcl for skew_group
# Skew Group Mode: all
switch_ccopt_skew_group_mode -create all
# Skew Group: all
create_ccopt_skew_group -name all -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: default
switch_ccopt_skew_group_mode -create default
# Skew Group: clk/cons_mode
create_ccopt_skew_group -name clk/cons_mode -from_clocks {clk} -from_constraint_modes {cons_mode} -from_delay_corners {fast_delay fast_delay typ_delay typ_delay slow_delay slow_delay} -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: fragment
switch_ccopt_skew_group_mode -create fragment
# Skew Group: 1
create_ccopt_skew_group -name 1 -generated  -fragment  -target_insertion_delay 0.136 -sinks {cp_ctrl_reg_58_/CP cp_ctrl_reg_224_/CP cp_ctrl_reg_385_/CP cp_ctrl_reg_305_/CP cp_ctrl_reg_41_/CP cp_ctrl_reg_124_/CP cp_ctrl_reg_322_/CP cp_ctrl_reg_10_/CP cp_ctrl_reg_8_/CP cp_ctrl_reg_204_/CP cp_ctrl_reg_116_/CP cp_ctrl_reg_45_/CP cp_ctrl_reg_347_/CP cp_ctrl_reg_338_/CP cp_ctrl_reg_158_/CP cp_ctrl_reg_120_/CP cp_ctrl_reg_328_/CP cp_ctrl_reg_72_/CP cp_ctrl_reg_289_/CP cp_ctrl_reg_200_/CP cp_ctrl_reg_33_/CP cp_ctrl_reg_153_/CP cp_ctrl_reg_297_/CP cp_ctrl_reg_266_/CP cp_ctrl_reg_264_/CP cp_ctrl_reg_208_/CP cp_ctrl_reg_372_/CP cp_ctrl_reg_236_/CP cp_ctrl_reg_196_/CP cp_ctrl_reg_157_/CP cp_ctrl_reg_149_/CP cp_ctrl_reg_404_/CP cp_ctrl_reg_76_/CP cp_ctrl_reg_352_/CP cp_ctrl_reg_405_/CP cp_ctrl_reg_339_/CP cp_ctrl_reg_159_/CP cp_ctrl_reg_121_/CP cp_ctrl_reg_225_/CP cp_ctrl_reg_329_/CP cp_ctrl_reg_201_/CP cp_ctrl_reg_73_/CP cp_ctrl_reg_59_/CP cp_ctrl_reg_353_/CP cp_ctrl_reg_323_/CP cp_ctrl_reg_267_/CP cp_ctrl_reg_265_/CP cp_ctrl_reg_11_/CP cp_ctrl_reg_9_/CP cp_ctrl_reg_386_/CP cp_ctrl_reg_125_/CP cp_ctrl_reg_77_/CP cp_ctrl_reg_209_/CP cp_ctrl_reg_373_/CP cp_ctrl_reg_306_/CP cp_ctrl_reg_298_/CP cp_ctrl_reg_290_/CP cp_ctrl_reg_237_/CP cp_ctrl_reg_205_/CP cp_ctrl_reg_197_/CP cp_ctrl_reg_154_/CP cp_ctrl_reg_150_/CP cp_ctrl_reg_117_/CP cp_ctrl_reg_46_/CP cp_ctrl_reg_42_/CP cp_ctrl_reg_34_/CP cp_ctrl_reg_348_/CP cp_ctrl_reg_57_/CP cp_ctrl_reg_55_/CP cp_ctrl_reg_0_/CP cp_ctrl_reg_20_/CP cp_ctrl_reg_60_/CP cp_ctrl_reg_132_/CP cp_ctrl_reg_214_/CP cp_ctrl_reg_223_/CP cp_ctrl_reg_230_/CP cp_ctrl_reg_327_/CP cp_ctrl_reg_334_/CP cp_ctrl_reg_368_/CP cp_ctrl_reg_378_/CP cp_ctrl_reg_113_/CP cp_ctrl_reg_249_/CP cp_ctrl_reg_199_/CP cp_ctrl_reg_238_/CP cp_ctrl_reg_257_/CP cp_ctrl_reg_118_/CP cp_ctrl_reg_119_/CP cp_ctrl_reg_27_/CP cp_ctrl_reg_68_/CP cp_ctrl_reg_244_/CP cp_ctrl_reg_411_/CP cp_ctrl_reg_361_/CP cp_ctrl_reg_151_/CP cp_ctrl_reg_54_/CP cp_ctrl_reg_275_/CP cp_ctrl_reg_409_/CP cp_ctrl_reg_400_/CP cp_ctrl_reg_394_/CP cp_ctrl_reg_393_/CP cp_ctrl_reg_359_/CP cp_ctrl_reg_360_/CP cp_ctrl_reg_346_/CP cp_ctrl_reg_280_/CP cp_ctrl_reg_255_/CP cp_ctrl_reg_163_/CP cp_ctrl_reg_48_/CP cp_ctrl_reg_260_/CP cp_ctrl_reg_261_/CP cp_ctrl_reg_417_/CP cp_ctrl_reg_415_/CP cp_ctrl_reg_414_/CP cp_ctrl_reg_407_/CP cp_ctrl_reg_396_/CP cp_ctrl_reg_381_/CP cp_ctrl_reg_380_/CP cp_ctrl_reg_376_/CP cp_ctrl_reg_375_/CP cp_ctrl_reg_366_/CP cp_ctrl_reg_365_/CP cp_ctrl_reg_357_/CP cp_ctrl_reg_351_/CP cp_ctrl_reg_344_/CP cp_ctrl_reg_343_/CP cp_ctrl_reg_341_/CP cp_ctrl_reg_340_/CP cp_ctrl_reg_337_/CP cp_ctrl_reg_336_/CP cp_ctrl_reg_325_/CP cp_ctrl_reg_324_/CP cp_ctrl_reg_318_/CP cp_ctrl_reg_316_/CP cp_ctrl_reg_315_/CP cp_ctrl_reg_314_/CP cp_ctrl_reg_312_/CP cp_ctrl_reg_311_/CP cp_ctrl_reg_310_/CP cp_ctrl_reg_302_/CP cp_ctrl_reg_295_/CP cp_ctrl_reg_294_/CP cp_ctrl_reg_288_/CP cp_ctrl_reg_282_/CP cp_ctrl_reg_277_/CP cp_ctrl_reg_278_/CP cp_ctrl_reg_253_/CP cp_ctrl_reg_233_/CP cp_ctrl_reg_232_/CP cp_ctrl_reg_221_/CP cp_ctrl_reg_220_/CP cp_ctrl_reg_194_/CP cp_ctrl_reg_193_/CP cp_ctrl_reg_191_/CP cp_ctrl_reg_190_/CP cp_ctrl_reg_188_/CP cp_ctrl_reg_187_/CP cp_ctrl_reg_186_/CP cp_ctrl_reg_184_/CP cp_ctrl_reg_183_/CP cp_ctrl_reg_182_/CP cp_ctrl_reg_180_/CP cp_ctrl_reg_179_/CP cp_ctrl_reg_178_/CP cp_ctrl_reg_176_/CP cp_ctrl_reg_175_/CP cp_ctrl_reg_174_/CP cp_ctrl_reg_172_/CP cp_ctrl_reg_171_/CP cp_ctrl_reg_170_/CP cp_ctrl_reg_168_/CP cp_ctrl_reg_167_/CP cp_ctrl_reg_166_/CP cp_ctrl_reg_147_/CP cp_ctrl_reg_146_/CP cp_ctrl_reg_144_/CP cp_ctrl_reg_143_/CP cp_ctrl_reg_142_/CP cp_ctrl_reg_140_/CP cp_ctrl_reg_139_/CP cp_ctrl_reg_138_/CP cp_ctrl_reg_136_/CP cp_ctrl_reg_135_/CP cp_ctrl_reg_134_/CP cp_ctrl_reg_130_/CP cp_ctrl_reg_129_/CP cp_ctrl_reg_106_/CP cp_ctrl_reg_105_/CP cp_ctrl_reg_104_/CP cp_ctrl_reg_102_/CP cp_ctrl_reg_101_/CP cp_ctrl_reg_100_/CP cp_ctrl_reg_98_/CP cp_ctrl_reg_97_/CP cp_ctrl_reg_96_/CP cp_ctrl_reg_94_/CP cp_ctrl_reg_93_/CP cp_ctrl_reg_92_/CP cp_ctrl_reg_90_/CP cp_ctrl_reg_89_/CP cp_ctrl_reg_88_/CP cp_ctrl_reg_86_/CP cp_ctrl_reg_85_/CP cp_ctrl_reg_84_/CP cp_ctrl_reg_82_/CP cp_ctrl_reg_81_/CP cp_ctrl_reg_66_/CP cp_ctrl_reg_65_/CP cp_ctrl_reg_63_/CP cp_ctrl_reg_62_/CP cp_ctrl_reg_50_/CP cp_ctrl_reg_38_/CP cp_ctrl_reg_31_/CP cp_ctrl_reg_30_/CP cp_ctrl_reg_23_/CP cp_ctrl_reg_6_/CP cp_ctrl_reg_5_/CP cp_ctrl_reg_3_/CP cp_ctrl_reg_2_/CP cp_ctrl_reg_402_/CP cp_ctrl_reg_388_/CP cp_ctrl_reg_304_/CP cp_ctrl_reg_240_/CP cp_ctrl_reg_40_/CP cp_ctrl_reg_18_/CP cp_ctrl_reg_17_/CP cp_ctrl_reg_398_/CP cp_ctrl_reg_391_/CP cp_ctrl_reg_390_/CP cp_ctrl_reg_218_/CP cp_ctrl_reg_217_/CP cp_ctrl_reg_216_/CP cp_ctrl_reg_207_/CP cp_ctrl_reg_161_/CP cp_ctrl_reg_160_/CP cp_ctrl_reg_356_/CP cp_ctrl_reg_355_/CP cp_ctrl_reg_332_/CP cp_ctrl_reg_331_/CP cp_ctrl_reg_308_/CP cp_ctrl_reg_307_/CP cp_ctrl_reg_300_/CP cp_ctrl_reg_299_/CP cp_ctrl_reg_292_/CP cp_ctrl_reg_291_/CP cp_ctrl_reg_271_/CP cp_ctrl_reg_269_/CP cp_ctrl_reg_252_/CP cp_ctrl_reg_251_/CP cp_ctrl_reg_228_/CP cp_ctrl_reg_227_/CP cp_ctrl_reg_212_/CP cp_ctrl_reg_211_/CP cp_ctrl_reg_203_/CP cp_ctrl_reg_155_/CP cp_ctrl_reg_127_/CP cp_ctrl_reg_123_/CP cp_ctrl_reg_115_/CP cp_ctrl_reg_79_/CP cp_ctrl_reg_75_/CP cp_ctrl_reg_43_/CP cp_ctrl_reg_36_/CP cp_ctrl_reg_35_/CP cp_ctrl_reg_15_/CP cp_ctrl_reg_13_/CP cp_ctrl_reg_384_/CP cp_ctrl_reg_370_/CP cp_ctrl_reg_287_/CP cp_ctrl_reg_284_/CP cp_ctrl_reg_246_/CP cp_ctrl_reg_247_/CP cp_ctrl_reg_242_/CP cp_ctrl_reg_110_/CP cp_ctrl_reg_111_/CP cp_ctrl_reg_70_/CP cp_ctrl_reg_71_/CP cp_ctrl_reg_52_/CP cp_ctrl_reg_26_/CP cp_ctrl_reg_25_/CP cp_ctrl_reg_274_/CP cp_ctrl_reg_273_/CP cp_ctrl_reg_321_/CP cp_ctrl_reg_349_/CP cp_ctrl_reg_362_/CP cp_ctrl_reg_363_/CP cp_ctrl_reg_258_/CP cp_ctrl_reg_28_/CP cp_ctrl_reg_107_/CP cp_ctrl_reg_412_/CP cp_ctrl_reg_358_/CP cp_ctrl_reg_345_/CP cp_ctrl_reg_262_/CP cp_ctrl_reg_256_/CP cp_ctrl_reg_254_/CP cp_ctrl_reg_164_/CP cp_ctrl_reg_67_/CP cp_ctrl_reg_413_/CP cp_ctrl_reg_408_/CP cp_ctrl_reg_392_/CP cp_ctrl_reg_382_/CP cp_ctrl_reg_379_/CP cp_ctrl_reg_364_/CP cp_ctrl_reg_350_/CP cp_ctrl_reg_335_/CP cp_ctrl_reg_326_/CP cp_ctrl_reg_317_/CP cp_ctrl_reg_313_/CP cp_ctrl_reg_309_/CP cp_ctrl_reg_301_/CP cp_ctrl_reg_293_/CP cp_ctrl_reg_281_/CP cp_ctrl_reg_276_/CP cp_ctrl_reg_234_/CP cp_ctrl_reg_231_/CP cp_ctrl_reg_222_/CP cp_ctrl_reg_192_/CP cp_ctrl_reg_189_/CP cp_ctrl_reg_185_/CP cp_ctrl_reg_181_/CP cp_ctrl_reg_177_/CP cp_ctrl_reg_173_/CP cp_ctrl_reg_169_/CP cp_ctrl_reg_165_/CP cp_ctrl_reg_145_/CP cp_ctrl_reg_141_/CP cp_ctrl_reg_137_/CP cp_ctrl_reg_133_/CP cp_ctrl_reg_131_/CP cp_ctrl_reg_103_/CP cp_ctrl_reg_99_/CP cp_ctrl_reg_95_/CP cp_ctrl_reg_91_/CP cp_ctrl_reg_87_/CP cp_ctrl_reg_83_/CP cp_ctrl_reg_61_/CP cp_ctrl_reg_49_/CP cp_ctrl_reg_37_/CP cp_ctrl_reg_29_/CP cp_ctrl_reg_21_/CP cp_ctrl_reg_19_/CP cp_ctrl_reg_403_/CP cp_ctrl_reg_401_/CP cp_ctrl_reg_399_/CP cp_ctrl_reg_215_/CP cp_ctrl_reg_270_/CP cp_ctrl_reg_235_/CP cp_ctrl_reg_195_/CP cp_ctrl_reg_16_/CP cp_ctrl_reg_14_/CP cp_ctrl_reg_383_/CP cp_ctrl_reg_24_/CP cp_ctrl_reg_272_/CP cp_ctrl_reg_418_/CP cp_ctrl_reg_416_/CP cp_ctrl_reg_395_/CP cp_ctrl_reg_377_/CP cp_ctrl_reg_342_/CP cp_ctrl_reg_333_/CP cp_ctrl_reg_296_/CP cp_ctrl_reg_229_/CP cp_ctrl_reg_213_/CP cp_ctrl_reg_162_/CP cp_ctrl_reg_112_/CP cp_ctrl_reg_64_/CP cp_ctrl_reg_32_/CP cp_ctrl_reg_7_/CP cp_ctrl_reg_303_/CP cp_ctrl_reg_39_/CP cp_ctrl_reg_397_/CP cp_ctrl_reg_389_/CP cp_ctrl_reg_319_/CP cp_ctrl_reg_128_/CP cp_ctrl_reg_80_/CP cp_ctrl_reg_283_/CP cp_ctrl_reg_51_/CP cp_ctrl_reg_367_/CP cp_ctrl_reg_4_/CP cp_ctrl_reg_198_/CP cp_ctrl_reg_259_/CP cp_ctrl_reg_374_/CP cp_ctrl_reg_206_/CP cp_ctrl_reg_354_/CP cp_ctrl_reg_330_/CP cp_ctrl_reg_226_/CP cp_ctrl_reg_210_/CP cp_ctrl_reg_202_/CP cp_ctrl_reg_122_/CP cp_ctrl_reg_74_/CP cp_ctrl_reg_1_/CP cp_ctrl_reg_250_/CP cp_ctrl_reg_156_/CP cp_ctrl_reg_148_/CP cp_ctrl_reg_114_/CP cp_ctrl_reg_56_/CP cp_ctrl_reg_44_/CP cp_ctrl_reg_152_/CP cp_ctrl_reg_410_/CP cp_ctrl_reg_219_/CP cp_ctrl_reg_239_/CP cp_ctrl_reg_248_/CP cp_ctrl_reg_285_/CP cp_ctrl_reg_53_/CP cp_ctrl_reg_108_/CP cp_ctrl_reg_371_/CP cp_ctrl_reg_243_/CP cp_ctrl_reg_279_/CP cp_ctrl_reg_369_/CP cp_ctrl_reg_286_/CP cp_ctrl_reg_245_/CP cp_ctrl_reg_241_/CP cp_ctrl_reg_109_/CP cp_ctrl_reg_69_/CP cp_ctrl_reg_47_/CP cp_ctrl_reg_406_/CP cp_ctrl_reg_263_/CP cp_ctrl_reg_387_/CP cp_ctrl_reg_268_/CP cp_ctrl_reg_22_/CP cp_ctrl_reg_12_/CP cp_ctrl_reg_126_/CP cp_ctrl_reg_78_/CP cp_ctrl_reg_320_/CP p_out_vld_reg/CP p_out_reg/CP rd_vld_reg/CP cp_ctrl_reg_419_/CP rd_data_out_reg/CP phase_cnt_reg_8_/CP phase_cnt_reg_7_/CP phase_cnt_reg_6_/CP phase_cnt_reg_5_/CP phase_cnt_reg_4_/CP phase_cnt_reg_3_/CP phase_cnt_reg_2_/CP phase_cnt_reg_1_/CP phase_cnt_reg_0_/CP cnt_reg_8_/CP cnt_reg_7_/CP cnt_reg_6_/CP cnt_reg_5_/CP cnt_reg_4_/CP cnt_reg_3_/CP cnt_reg_2_/CP cnt_reg_1_/CP cnt_reg_0_/CP} -rank 0 -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: icts
switch_ccopt_skew_group_mode -create icts
# Skew Group: clk/cons_mode
create_ccopt_skew_group -name clk/cons_mode -auto_sinks -sources {clk}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group
# Skew Group Mode: stagedepth
switch_ccopt_skew_group_mode -create stagedepth
# Skew Group: stagedepth
create_ccopt_skew_group -name stagedepth -generated  -auto_sinks -sources {{clk rise}}
#
# no ignore pins for this skew group
#
# no remove sinks for this skew group
#
# no add sinks for this skew group

# Switch back to default mode.
switch_ccopt_skew_group_mode default