# ccopt saved state prop_store_2.tcl.gz

## RestorePhase2: Post-clock-tree extraction.
## Tcl commands to replicate state of the add_driver_cell property.
# add_driver_cell has default value for all objects.
## Tcl commands to replicate state of the add_exclusion_drivers property.
# add_exclusion_drivers has default value.
## Tcl commands to replicate state of the add_new_ports_to_avoid_buffering_nets_with_assigns property.
# add_new_ports_to_avoid_buffering_nets_with_assigns has default value.
## Tcl commands to replicate state of the add_port_driver property.
# add_port_driver has default value for all objects.
## Tcl commands to replicate state of the additional_buffer_depth property.
# additional_buffer_depth has default value for all objects.
## Tcl commands to replicate state of the additional_buffer_depth_skew_group_fraction property.
# additional_buffer_depth_skew_group_fraction has default value.
## Tcl commands to replicate state of the adjacent_rows_legal property.
set_ccopt_property adjacent_rows_legal false
## Tcl commands to replicate state of the allow_cg_moves_during_implementation property.
# allow_cg_moves_during_implementation has default value.
## Tcl commands to replicate state of the allow_cloning_in_slew_fixing property.
# allow_cloning_in_slew_fixing has default value.
## Tcl commands to replicate state of the allow_clustering_with_weak_drivers property.
# allow_clustering_with_weak_drivers has default value.
## Tcl commands to replicate state of the allow_commute_inversion_to_above_node property.
# allow_commute_inversion_to_above_node has default value.
## Tcl commands to replicate state of the allow_looser_generated_clock_tree_max_trans_targets property.
# allow_looser_generated_clock_tree_max_trans_targets has default value.
## Tcl commands to replicate state of the allow_nano_route_second_pass_for_drc property.
# allow_nano_route_second_pass_for_drc has default value.
## Tcl commands to replicate state of the allow_no_row_cells property.
# allow_no_row_cells has default value.
## Tcl commands to replicate state of the allow_non_fterm_identical_swaps property.
set_ccopt_property allow_non_fterm_identical_swaps 1
## Tcl commands to replicate state of the allow_preroute_spef_annotation property.
# allow_preroute_spef_annotation has default value.
## Tcl commands to replicate state of the allow_resize_of_dont_touch_cells property.
# allow_resize_of_dont_touch_cells has default value.
## Tcl commands to replicate state of the allow_to_write_fragment_clock_dag_timing_stats_in_log property.
# allow_to_write_fragment_clock_dag_timing_stats_in_log has default value.
## Tcl commands to replicate state of the allow_use_of_nrtd_interface_in_set_net_attributes property.
# allow_use_of_nrtd_interface_in_set_net_attributes has default value.
## Tcl commands to replicate state of the alternative_route_types property.
# alternative_route_types has default value for all objects.
## Tcl commands to replicate state of the always_calculate_effective_direction property.
# always_calculate_effective_direction has default value.
## Tcl commands to replicate state of the always_try_power_domain_crossings property.
# always_try_power_domain_crossings has default value.
## Tcl commands to replicate state of the annotated_delay_to property.
# annotated_delay_to has default value for all objects.
## Tcl commands to replicate state of the annotated_transition property.
# annotated_transition has default value for all objects.
## Tcl commands to replicate state of the aocv_estimate_default_stage_count property.
# aocv_estimate_default_stage_count has default value.
## Tcl commands to replicate state of the apply_clock_net_ndrs_before_final_refine_place property.
# apply_clock_net_ndrs_before_final_refine_place has default value.
## Tcl commands to replicate state of the apply_move_limit_after_merging property.
# apply_move_limit_after_merging has default value.
## Tcl commands to replicate state of the apply_source_latency_using_summary property.
# apply_source_latency_using_summary has default value.
## Tcl commands to replicate state of the approximate_balance_attempt_to_buffer_bufferable_subsets property.
# approximate_balance_attempt_to_buffer_bufferable_subsets has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_below_can_change_family property.
# approximate_balance_buffer_below_can_change_family has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_chains_intelligently property.
# approximate_balance_buffer_chains_intelligently has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_output_of_leaf_drivers_that_meet_skew_target property.
# approximate_balance_buffer_output_of_leaf_drivers_that_meet_skew_target has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_spreading_max_drivers_to_add property.
# approximate_balance_buffer_spreading_max_drivers_to_add has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_spreading_threshold property.
# approximate_balance_buffer_spreading_threshold has default value.
## Tcl commands to replicate state of the approximate_balance_buffer_subsets property.
# approximate_balance_buffer_subsets has default value.
## Tcl commands to replicate state of the approximate_balance_do_buffer_spreading property.
# approximate_balance_do_buffer_spreading has default value.
## Tcl commands to replicate state of the artificially_remove_long_paths_considers_id_targets property.
# artificially_remove_long_paths_considers_id_targets has default value.
## Tcl commands to replicate state of the artificially_remove_long_paths_skew_target_window_multiple property.
# artificially_remove_long_paths_skew_target_window_multiple has default value.
## Tcl commands to replicate state of the assigned_clock_trees property.
# assigned_clock_trees has default value for all objects.
## Tcl commands to replicate state of the auto_design_state_for_ilms property.
# auto_design_state_for_ilms has default value.
## Tcl commands to replicate state of the auto_detect_and_tie_lockup_latches property.
# auto_detect_and_tie_lockup_latches has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_factor property.
# auto_limit_insertion_delay_factor has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_factor_skew_group property.
# auto_limit_insertion_delay_factor_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_decrement property.
# auto_limit_insertion_delay_max_decrement has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_decrement_skew_group property.
# auto_limit_insertion_delay_max_decrement_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_increment property.
# auto_limit_insertion_delay_max_increment has default value.
## Tcl commands to replicate state of the auto_limit_insertion_delay_max_increment_skew_group property.
# auto_limit_insertion_delay_max_increment_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_min_insertion_delay_factor property.
# auto_limit_min_insertion_delay_factor has default value.
## Tcl commands to replicate state of the auto_limit_min_insertion_delay_factor_skew_group property.
# auto_limit_min_insertion_delay_factor_skew_group has default value for all objects.
## Tcl commands to replicate state of the auto_limit_use_clustering_delays property.
# auto_limit_use_clustering_delays has default value.
## Tcl commands to replicate state of the auto_select_vias property.
# auto_select_vias has default value.
## Tcl commands to replicate state of the auto_wire_skew_proportion property.
# auto_wire_skew_proportion has default value.
## Tcl commands to replicate state of the avoid_escaped_naming property.
# avoid_escaped_naming has default value.
## Tcl commands to replicate state of the avoid_placing_non_spine_cells_on_hard_spines property.
# avoid_placing_non_spine_cells_on_hard_spines has default value.
## Tcl commands to replicate state of the avoid_verilog_escape_when_cloning_bus_ports property.
# avoid_verilog_escape_when_cloning_bus_ports has default value.
## Tcl commands to replicate state of the balance_edge property.
# balance_edge has default value for all objects.
## Tcl commands to replicate state of the bash_timing_graph_after_cluster property.
# bash_timing_graph_after_cluster has default value.
## Tcl commands to replicate state of the bash_timing_graph_before_cluster property.
# bash_timing_graph_before_cluster has default value.
## Tcl commands to replicate state of the boolexp_enable_extra_checks property.
# boolexp_enable_extra_checks has default value.
## Tcl commands to replicate state of the bottom_up_balancer_buffer_dont_touch_node_outputs property.
# bottom_up_balancer_buffer_dont_touch_node_outputs has default value.
## Tcl commands to replicate state of the bottom_up_balancer_start_with_current_max_latencies property.
# bottom_up_balancer_start_with_current_max_latencies has default value.
## Tcl commands to replicate state of the bound_transition_time_to_greater_than_zero property.
# bound_transition_time_to_greater_than_zero has default value.
## Tcl commands to replicate state of the breakpoint_tcl_function property.
# breakpoint_tcl_function has default value.
## Tcl commands to replicate state of the buffer_cells property.
set_ccopt_property buffer_cells {BUFFD0BWP BUFFD1BWP BUFFD2BWP BUFFD3BWP BUFFD4BWP BUFFD6BWP BUFFD8BWP BUFFD12BWP BUFFD16BWP BUFFD20BWP BUFFD24BWP}
## Tcl commands to replicate state of the buffer_fanout_in_reducing_insertion_delay_2 property.
# buffer_fanout_in_reducing_insertion_delay_2 has default value.
## Tcl commands to replicate state of the bufferability_use_cache property.
# bufferability_use_cache has default value.
## Tcl commands to replicate state of the call_cong_repair_after_buffering_in_implementation property.
# call_cong_repair_after_buffering_in_implementation has default value.
## Tcl commands to replicate state of the call_cong_repair_after_initial_clustering property.
# call_cong_repair_after_initial_clustering has default value.
## Tcl commands to replicate state of the call_cong_repair_before_implementation property.
# call_cong_repair_before_implementation has default value.
## Tcl commands to replicate state of the call_cong_repair_using_flow_tcl property.
# call_cong_repair_using_flow_tcl has default value.
## Tcl commands to replicate state of the call_nanoroute_after_early_global property.
# call_nanoroute_after_early_global has default value.
## Tcl commands to replicate state of the can_add_new_port_checks_if_all_ports_constrained property.
# can_add_new_port_checks_if_all_ports_constrained has default value.
## Tcl commands to replicate state of the can_drive_computation_method property.
# can_drive_computation_method has default value.
## Tcl commands to replicate state of the cannot_clone_reason property.
# cannot_clone_reason has default value for all objects.
## Tcl commands to replicate state of the cannot_fix_pre_route property.
# cannot_fix_pre_route has default value for all objects.
## Tcl commands to replicate state of the cannot_merge_reason property.
# cannot_merge_reason has default value for all objects.
## Tcl commands to replicate state of the capacitance_override property.
# capacitance_override has default value for all objects.
## Tcl commands to replicate state of the case_analysis property.
# case_analysis has default value for all objects.
## Tcl commands to replicate state of the caseh_find_better_location_for_node_above_isolated_sink property.
# caseh_find_better_location_for_node_above_isolated_sink has default value.
## Tcl commands to replicate state of the ccopt_adjust_latches_for_hold property.
# ccopt_adjust_latches_for_hold has default value.
## Tcl commands to replicate state of the ccopt_check_db_continue_after_error property.
# ccopt_check_db_continue_after_error has default value.
## Tcl commands to replicate state of the ccopt_check_db_every_tcl_command property.
# ccopt_check_db_every_tcl_command has default value.
## Tcl commands to replicate state of the ccopt_check_db_release_error_object property.
# ccopt_check_db_release_error_object has default value.
## Tcl commands to replicate state of the ccopt_clear_famous_modes_on_exit property.
# ccopt_clear_famous_modes_on_exit has default value.
## Tcl commands to replicate state of the ccopt_clear_hs_data_after_command property.
# ccopt_clear_hs_data_after_command has default value.
## Tcl commands to replicate state of the ccopt_clear_implementation_mode_on_exit property.
# ccopt_clear_implementation_mode_on_exit has default value.
## Tcl commands to replicate state of the ccopt_debug_line_after_initial_clustering property.
# ccopt_debug_line_after_initial_clustering has default value.
## Tcl commands to replicate state of the ccopt_debug_line_before_final_routing property.
# ccopt_debug_line_before_final_routing has default value.
## Tcl commands to replicate state of the ccopt_debug_line_before_post_conditioning property.
# ccopt_debug_line_before_post_conditioning has default value.
## Tcl commands to replicate state of the ccopt_design_default_full_flow_automation property.
# ccopt_design_default_full_flow_automation has default value.
## Tcl commands to replicate state of the ccopt_design_enable_default_tuning property.
# ccopt_design_enable_default_tuning has default value.
## Tcl commands to replicate state of the ccopt_design_post_db property.
# ccopt_design_post_db has default value.
## Tcl commands to replicate state of the ccopt_design_pre_db property.
# ccopt_design_pre_db has default value.
## Tcl commands to replicate state of the ccopt_effort_internal_copy property.
set_ccopt_property ccopt_effort_internal_copy low
## Tcl commands to replicate state of the ccopt_enable_detailed_balancer property.
# ccopt_enable_detailed_balancer has default value.
## Tcl commands to replicate state of the ccopt_enable_route_buffering_skew_fixer property.
# ccopt_enable_route_buffering_skew_fixer has default value.
## Tcl commands to replicate state of the ccopt_engine_before_implement_update_timing property.
# ccopt_engine_before_implement_update_timing has default value.
## Tcl commands to replicate state of the ccopt_engine_do_trial_route property.
# ccopt_engine_do_trial_route has default value.
## Tcl commands to replicate state of the ccopt_engine_do_trial_route_before_recluster property.
# ccopt_engine_do_trial_route_before_recluster has default value.
## Tcl commands to replicate state of the ccopt_engine_pin_state property.
# ccopt_engine_pin_state has default value for all objects.
## Tcl commands to replicate state of the ccopt_engine_state property.
# ccopt_engine_state has default value.
## Tcl commands to replicate state of the ccopt_engine_state_reset_on_destroy property.
# ccopt_engine_state_reset_on_destroy has default value.
## Tcl commands to replicate state of the ccopt_exp_approximate_balance_buffer_output_of_leaf_drivers_that_meet_skew_target property.
# ccopt_exp_approximate_balance_buffer_output_of_leaf_drivers_that_meet_skew_target has default value.
## Tcl commands to replicate state of the ccopt_implementation_recalculate_windows property.
# ccopt_implementation_recalculate_windows has default value.
## Tcl commands to replicate state of the ccopt_merge_clock_gates property.
# ccopt_merge_clock_gates has default value for all objects.
## Tcl commands to replicate state of the ccopt_merge_clock_logic property.
# ccopt_merge_clock_logic has default value for all objects.
## Tcl commands to replicate state of the ccopt_operations_after_tns_opt property.
# ccopt_operations_after_tns_opt has default value.
## Tcl commands to replicate state of the ccopt_operations_critical_high property.
# ccopt_operations_critical_high has default value.
## Tcl commands to replicate state of the ccopt_operations_critical_low property.
# ccopt_operations_critical_low has default value.
## Tcl commands to replicate state of the ccopt_operations_critical_medium property.
# ccopt_operations_critical_medium has default value.
## Tcl commands to replicate state of the ccopt_operations_extended_high property.
# ccopt_operations_extended_high has default value.
## Tcl commands to replicate state of the ccopt_operations_extended_low property.
# ccopt_operations_extended_low has default value.
## Tcl commands to replicate state of the ccopt_operations_extended_medium property.
# ccopt_operations_extended_medium has default value.
## Tcl commands to replicate state of the ccopt_property_return_display_limit property.
# ccopt_property_return_display_limit has default value.
## Tcl commands to replicate state of the ccopt_refresh_schedule_before_hyperspace_cluster property.
# ccopt_refresh_schedule_before_hyperspace_cluster has default value.
## Tcl commands to replicate state of the ccopt_refresh_schedule_before_implementation property.
# ccopt_refresh_schedule_before_implementation has default value.
## Tcl commands to replicate state of the ccopt_refresh_schedule_before_mini_cluster property.
# ccopt_refresh_schedule_before_mini_cluster has default value.
## Tcl commands to replicate state of the ccopt_speedup property.
# ccopt_speedup has default value.
## Tcl commands to replicate state of the ccopt_use_skew_clock property.
# ccopt_use_skew_clock has default value.
## Tcl commands to replicate state of the ccopt_worst_chain_report_timing_too property.
# ccopt_worst_chain_report_timing_too has default value.
## Tcl commands to replicate state of the cell_density property.
# cell_density has default value for all objects.
## Tcl commands to replicate state of the cell_halo_mode property.
# cell_halo_mode has default value.
## Tcl commands to replicate state of the cell_halo_mode_sum_row_height_multiplier property.
# cell_halo_mode_sum_row_height_multiplier has default value.
## Tcl commands to replicate state of the cell_halo_rows property.
set_ccopt_property cell_halo_rows 1
## Tcl commands to replicate state of the cell_halo_sites property.
set_ccopt_property cell_halo_sites 4
## Tcl commands to replicate state of the cell_halo_x property.
# cell_halo_x has default value for all objects.
## Tcl commands to replicate state of the cell_halo_y property.
# cell_halo_y has default value for all objects.
## Tcl commands to replicate state of the cerebrus_data_dir property.
# cerebrus_data_dir has default value.
## Tcl commands to replicate state of the change_fences_to_guides property.
# change_fences_to_guides has default value.
## Tcl commands to replicate state of the channel_graph_ignore_routing_blockages_with_detour_smaller_than property.
# channel_graph_ignore_routing_blockages_with_detour_smaller_than has default value.
## Tcl commands to replicate state of the check_drive_strength_ordering_matches_area_ordering property.
# check_drive_strength_ordering_matches_area_ordering has default value.
## Tcl commands to replicate state of the check_prerequisites_check_place property.
# check_prerequisites_check_place has default value.
## Tcl commands to replicate state of the check_route_follows_guide property.
# check_route_follows_guide has default value.
## Tcl commands to replicate state of the check_route_follows_guide_min_length property.
# check_route_follows_guide_min_length has default value.
## Tcl commands to replicate state of the choose_aon_cell_by_bias_type property.
# choose_aon_cell_by_bias_type has default value.
## Tcl commands to replicate state of the chosen_route_type property.
# chosen_route_type has default value for all objects.
## Tcl commands to replicate state of the chosen_route_type_source property.
# chosen_route_type_source has default value for all objects.
## Tcl commands to replicate state of the clean_up_start_of_nets property.
# clean_up_start_of_nets has default value.
## Tcl commands to replicate state of the clock_domain_skew_group property.
# clock_domain_skew_group has default value for all objects.
## Tcl commands to replicate state of the clock_gate_buffering_location property.
# clock_gate_buffering_location has default value for all objects.
## Tcl commands to replicate state of the clock_gating_cells property.
# clock_gating_cells has default value for all objects.
## Tcl commands to replicate state of the clock_nets_detailed_routed property.
set_ccopt_property clock_nets_detailed_routed 1
## Tcl commands to replicate state of the clock_period property.
set_ccopt_property clock_period -pin clk 9.5
## Tcl commands to replicate state of the clock_source_cells property.
# clock_source_cells has default value for all objects.
## Tcl commands to replicate state of the clock_spine_cell_do_not_flip property.
# clock_spine_cell_do_not_flip has default value.
## Tcl commands to replicate state of the clock_spine_cell_preserve_orient property.
# clock_spine_cell_preserve_orient has default value.
## Tcl commands to replicate state of the clock_tree_source_group_placement property.
# clock_tree_source_group_placement has default value for all objects.
## Tcl commands to replicate state of the clock_tree_source_group_placement_rects property.
# clock_tree_source_group_placement_rects has default value for all objects.
## Tcl commands to replicate state of the clone_clock_gates property.
# clone_clock_gates has default value for all objects.
## Tcl commands to replicate state of the clone_clock_gates_band_size property.
# clone_clock_gates_band_size has default value.
## Tcl commands to replicate state of the clone_clock_logic property.
# clone_clock_logic has default value for all objects.
## Tcl commands to replicate state of the cloned_gates_always_movable property.
# cloned_gates_always_movable has default value.
## Tcl commands to replicate state of the cloned_logics_always_movable property.
# cloned_logics_always_movable has default value.
## Tcl commands to replicate state of the cloned_power_management_cells_always_movable property.
# cloned_power_management_cells_always_movable has default value.
## Tcl commands to replicate state of the cloning_copy_activity property.
set_ccopt_property cloning_copy_activity 0
## Tcl commands to replicate state of the cloning_ignore_dont_touch_sdc property.
# cloning_ignore_dont_touch_sdc has default value.
## Tcl commands to replicate state of the cluster_agglom_balance_cap_pin_move_iterations property.
# cluster_agglom_balance_cap_pin_move_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_borderline_passing_threshold property.
# cluster_agglom_borderline_passing_threshold has default value.
## Tcl commands to replicate state of the cluster_agglom_bounding_box_limit_per_cluster property.
# cluster_agglom_bounding_box_limit_per_cluster has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_based_initial_k property.
# cluster_agglom_cap_based_initial_k has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_cost_exponent property.
# cluster_agglom_cap_cost_exponent has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_limit_per_cluster property.
# cluster_agglom_cap_limit_per_cluster has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_opt_level property.
# cluster_agglom_cap_opt_level has default value.
## Tcl commands to replicate state of the cluster_agglom_cap_opt_mode property.
# cluster_agglom_cap_opt_mode has default value.
## Tcl commands to replicate state of the cluster_agglom_find_ideal_sink_location_in_region property.
# cluster_agglom_find_ideal_sink_location_in_region has default value.
## Tcl commands to replicate state of the cluster_agglom_find_ideal_sink_location_in_region_iterations property.
# cluster_agglom_find_ideal_sink_location_in_region_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine property.
# cluster_agglom_kmeans_refine has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine_iterations property.
# cluster_agglom_kmeans_refine_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine_split_limit property.
# cluster_agglom_kmeans_refine_split_limit has default value.
## Tcl commands to replicate state of the cluster_agglom_kmeans_refine_split_proportion property.
# cluster_agglom_kmeans_refine_split_proportion has default value.
## Tcl commands to replicate state of the cluster_agglom_max_neighbor_distance_to_radius_sum_ratio property.
# cluster_agglom_max_neighbor_distance_to_radius_sum_ratio has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement property.
# cluster_agglom_refinement has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_iterations property.
# cluster_agglom_refinement_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_non_slew_cap_target_threshold property.
# cluster_agglom_refinement_non_slew_cap_target_threshold has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_pin_move property.
# cluster_agglom_refinement_pin_move has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_pin_move_pin_cap_cost_weight property.
# cluster_agglom_refinement_pin_move_pin_cap_cost_weight has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_slew_to_cap_change_scaling_factor property.
# cluster_agglom_refinement_slew_to_cap_change_scaling_factor has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_split_and_merge property.
# cluster_agglom_refinement_split_and_merge has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_split_and_merge_frequency property.
# cluster_agglom_refinement_split_and_merge_frequency has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_split_only property.
# cluster_agglom_refinement_split_only has default value.
## Tcl commands to replicate state of the cluster_agglom_refinement_trigger_threshold property.
# cluster_agglom_refinement_trigger_threshold has default value.
## Tcl commands to replicate state of the cluster_agglom_run_single_iteration property.
# cluster_agglom_run_single_iteration has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering property.
# cluster_agglom_two_stage_global_clustering has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering_balancing_iterations property.
# cluster_agglom_two_stage_global_clustering_balancing_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering_flow_iterations property.
# cluster_agglom_two_stage_global_clustering_flow_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_two_stage_global_clustering_pin_move_iterations property.
# cluster_agglom_two_stage_global_clustering_pin_move_iterations has default value.
## Tcl commands to replicate state of the cluster_agglom_verbose_level property.
# cluster_agglom_verbose_level has default value.
## Tcl commands to replicate state of the cluster_agglom_wire_cap_weight property.
# cluster_agglom_wire_cap_weight has default value.
## Tcl commands to replicate state of the cluster_algorithm property.
# cluster_algorithm has default value.
## Tcl commands to replicate state of the cluster_icg_file_name_style property.
# cluster_icg_file_name_style has default value.
## Tcl commands to replicate state of the cluster_kmeans_calculate_k property.
# cluster_kmeans_calculate_k has default value.
## Tcl commands to replicate state of the cluster_kmeans_debug_tcl property.
# cluster_kmeans_debug_tcl has default value.
## Tcl commands to replicate state of the cluster_kmeans_fix_small_clusters property.
# cluster_kmeans_fix_small_clusters has default value.
## Tcl commands to replicate state of the cluster_kmeans_fix_small_clusters_limit property.
# cluster_kmeans_fix_small_clusters_limit has default value.
## Tcl commands to replicate state of the cluster_kmeans_fix_small_clusters_max_iterations property.
# cluster_kmeans_fix_small_clusters_max_iterations has default value.
## Tcl commands to replicate state of the cluster_kmeans_get_min_clusters property.
# cluster_kmeans_get_min_clusters has default value.
## Tcl commands to replicate state of the cluster_kmeans_max_inner_iterations property.
# cluster_kmeans_max_inner_iterations has default value.
## Tcl commands to replicate state of the cluster_kmeans_new_rload_normalisation property.
# cluster_kmeans_new_rload_normalisation has default value.
## Tcl commands to replicate state of the cluster_kmeans_preserve_rload property.
# cluster_kmeans_preserve_rload has default value.
## Tcl commands to replicate state of the cluster_kmeans_split_limit property.
# cluster_kmeans_split_limit has default value.
## Tcl commands to replicate state of the cluster_kmeans_split_proportion property.
# cluster_kmeans_split_proportion has default value.
## Tcl commands to replicate state of the cluster_kmeans_trivial_increment_value property.
# cluster_kmeans_trivial_increment_value has default value.
## Tcl commands to replicate state of the cluster_when_starting_skewing property.
set_ccopt_property cluster_when_starting_skewing 0
## Tcl commands to replicate state of the clustering_agglom_cap_eval_use_cluster_weight property.
# clustering_agglom_cap_eval_use_cluster_weight has default value.
## Tcl commands to replicate state of the clustering_agglom_fix_can_cluster_accept_sink property.
# clustering_agglom_fix_can_cluster_accept_sink has default value.
## Tcl commands to replicate state of the clustering_agglom_levels property.
# clustering_agglom_levels has default value.
## Tcl commands to replicate state of the clustering_agglom_non_leaf_calculate_k property.
# clustering_agglom_non_leaf_calculate_k has default value.
## Tcl commands to replicate state of the clustering_agglom_non_leaf_cluster_algorithm property.
# clustering_agglom_non_leaf_cluster_algorithm has default value.
## Tcl commands to replicate state of the clustering_agglom_switch_to_kmeans_if_all_sinks_not_compatible property.
# clustering_agglom_switch_to_kmeans_if_all_sinks_not_compatible has default value.
## Tcl commands to replicate state of the clustering_avoid_adding_ccd_gates property.
# clustering_avoid_adding_ccd_gates has default value.
## Tcl commands to replicate state of the clustering_balance_stage_depths property.
# clustering_balance_stage_depths has default value.
## Tcl commands to replicate state of the clustering_calculate_stage_depths property.
# clustering_calculate_stage_depths has default value.
## Tcl commands to replicate state of the clustering_cap_based_evaluator_mode property.
# clustering_cap_based_evaluator_mode has default value.
## Tcl commands to replicate state of the clustering_caseb_make_progress_check property.
# clustering_caseb_make_progress_check has default value.
## Tcl commands to replicate state of the clustering_consider_cap_during_cluster_evaluation property.
# clustering_consider_cap_during_cluster_evaluation has default value.
## Tcl commands to replicate state of the clustering_consider_cap_for_cluster_acceptance property.
# clustering_consider_cap_for_cluster_acceptance has default value.
## Tcl commands to replicate state of the clustering_consider_wire_cap_for_isolating_sinks property.
# clustering_consider_wire_cap_for_isolating_sinks has default value.
## Tcl commands to replicate state of the clustering_convert_pin_insertion_delays_to_stage_depth property.
# clustering_convert_pin_insertion_delays_to_stage_depth has default value.
## Tcl commands to replicate state of the clustering_debug_data property.
# clustering_debug_data has default value.
## Tcl commands to replicate state of the clustering_debug_plots property.
# clustering_debug_plots has default value.
## Tcl commands to replicate state of the clustering_downsizing property.
# clustering_downsizing has default value for all objects.
## Tcl commands to replicate state of the clustering_downsizing_stage_depth_limit property.
# clustering_downsizing_stage_depth_limit has default value for all objects.
## Tcl commands to replicate state of the clustering_fix_region_expansion_offsets property.
# clustering_fix_region_expansion_offsets has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing property.
# clustering_id_safe_downsizing has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_extra_unit_delays_factor property.
# clustering_id_safe_downsizing_extra_unit_delays_factor has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_inversion_unit_delay_factor property.
# clustering_id_safe_downsizing_inversion_unit_delay_factor has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_preserve_sinkinfo_flags property.
# clustering_id_safe_downsizing_preserve_sinkinfo_flags has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_stage_depth_limit property.
# clustering_id_safe_downsizing_stage_depth_limit has default value.
## Tcl commands to replicate state of the clustering_id_safe_downsizing_unit_delay_limit property.
# clustering_id_safe_downsizing_unit_delay_limit has default value.
## Tcl commands to replicate state of the clustering_id_safe_region_adjustment property.
# clustering_id_safe_region_adjustment has default value.
## Tcl commands to replicate state of the clustering_ignore_max_cap_computed_from_slew_target property.
# clustering_ignore_max_cap_computed_from_slew_target has default value.
## Tcl commands to replicate state of the clustering_input_transition_modeling_scale_factor property.
# clustering_input_transition_modeling_scale_factor has default value.
## Tcl commands to replicate state of the clustering_length_based_max_cap_scaling_factor property.
# clustering_length_based_max_cap_scaling_factor has default value.
## Tcl commands to replicate state of the clustering_length_based_max_radius_scaling_factor property.
# clustering_length_based_max_radius_scaling_factor has default value.
## Tcl commands to replicate state of the clustering_max_cap_target_factor property.
# clustering_max_cap_target_factor has default value.
## Tcl commands to replicate state of the clustering_max_radius_target property.
# clustering_max_radius_target has default value.
## Tcl commands to replicate state of the clustering_mix_inverters_and_buffers property.
# clustering_mix_inverters_and_buffers has default value.
## Tcl commands to replicate state of the clustering_mix_inverters_and_buffers_match_cell_instances property.
# clustering_mix_inverters_and_buffers_match_cell_instances has default value.
## Tcl commands to replicate state of the clustering_only_consider_cap_target property.
# clustering_only_consider_cap_target has default value.
## Tcl commands to replicate state of the clustering_only_consider_cap_target_levels property.
# clustering_only_consider_cap_target_levels has default value.
## Tcl commands to replicate state of the clustering_partition_sinks_using_agglom property.
# clustering_partition_sinks_using_agglom has default value.
## Tcl commands to replicate state of the clustering_partition_sinks_using_agglom_use_two_stage property.
# clustering_partition_sinks_using_agglom_use_two_stage has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit property.
# clustering_per_stage_total_delay_limit has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_clock_gates property.
# clustering_per_stage_total_delay_limit_clock_gates has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_clock_logic property.
# clustering_per_stage_total_delay_limit_clock_logic has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_drivers property.
# clustering_per_stage_total_delay_limit_drivers has default value.
## Tcl commands to replicate state of the clustering_per_stage_total_delay_limit_transitively property.
# clustering_per_stage_total_delay_limit_transitively has default value.
## Tcl commands to replicate state of the clustering_per_stage_wire_delay_limit property.
# clustering_per_stage_wire_delay_limit has default value.
## Tcl commands to replicate state of the clustering_region property.
# clustering_region has default value for all objects.
## Tcl commands to replicate state of the clustering_region_expansion_downsize_commit_change property.
# clustering_region_expansion_downsize_commit_change has default value.
## Tcl commands to replicate state of the clustering_region_expansion_downsize_first property.
# clustering_region_expansion_downsize_first has default value.
## Tcl commands to replicate state of the clustering_region_expansion_use_route property.
# clustering_region_expansion_use_route has default value.
## Tcl commands to replicate state of the clustering_region_expansion_use_route_expand_beyond property.
# clustering_region_expansion_use_route_expand_beyond has default value.
## Tcl commands to replicate state of the clustering_resolve_user_module_before_finding_legal_location property.
# clustering_resolve_user_module_before_finding_legal_location has default value.
## Tcl commands to replicate state of the clustering_size_based_trivial_increment property.
# clustering_size_based_trivial_increment has default value.
## Tcl commands to replicate state of the clustering_skip_mix_inverters_and_buffers_under_icg property.
# clustering_skip_mix_inverters_and_buffers_under_icg has default value.
## Tcl commands to replicate state of the clustering_source_group_assign_fanout_by_distance_only property.
# clustering_source_group_assign_fanout_by_distance_only has default value.
## Tcl commands to replicate state of the clustering_source_group_debug_file_directory property.
# clustering_source_group_debug_file_directory has default value.
## Tcl commands to replicate state of the clustering_source_group_distance_metric property.
# clustering_source_group_distance_metric has default value.
## Tcl commands to replicate state of the clustering_source_group_icg_driving_distance property.
# clustering_source_group_icg_driving_distance has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_icg_driving_distances property.
# clustering_source_group_icg_driving_distances has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_max_cloned_fraction property.
# clustering_source_group_max_cloned_fraction has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_max_sink_per_tap property.
# clustering_source_group_max_sink_per_tap has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_max_sink_per_tap_ratio property.
# clustering_source_group_max_sink_per_tap_ratio has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_min_sink_per_tap_ratio property.
# clustering_source_group_min_sink_per_tap_ratio has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_optimization_effort property.
# clustering_source_group_optimization_effort has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_single_root_sink_assignment_warning_threshold property.
# clustering_source_group_single_root_sink_assignment_warning_threshold has default value for all objects.
## Tcl commands to replicate state of the clustering_source_group_tap_radius_threshold_ratio property.
# clustering_source_group_tap_radius_threshold_ratio has default value for all objects.
## Tcl commands to replicate state of the clustering_tighten_input_transitions property.
# clustering_tighten_input_transitions has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions_at_clock_root_fanout property.
# clustering_tighten_input_transitions_at_clock_root_fanout has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions_pre_char_distance_factor property.
# clustering_tighten_input_transitions_pre_char_distance_factor has default value.
## Tcl commands to replicate state of the clustering_tighten_input_transitions_pre_char_fanout_factor property.
# clustering_tighten_input_transitions_pre_char_fanout_factor has default value.
## Tcl commands to replicate state of the clustering_unit_wire_cap_scaling_factor property.
# clustering_unit_wire_cap_scaling_factor has default value.
## Tcl commands to replicate state of the clustering_use_agglom_cap_evaluator property.
# clustering_use_agglom_cap_evaluator has default value.
## Tcl commands to replicate state of the clustering_use_disjoint_region_count_for_expanding_regions property.
# clustering_use_disjoint_region_count_for_expanding_regions has default value.
## Tcl commands to replicate state of the clustering_user_max_cap_target property.
# clustering_user_max_cap_target has default value.
## Tcl commands to replicate state of the clustering_with_clones_fallback_to_buffering property.
# clustering_with_clones_fallback_to_buffering has default value.
## Tcl commands to replicate state of the compatibility_warning property.
# compatibility_warning has default value.
## Tcl commands to replicate state of the congested_rectangles property.
# congested_rectangles has default value.
## Tcl commands to replicate state of the congestion_override property.
# congestion_override has default value for all objects.
## Tcl commands to replicate state of the congestion_override_for_clustering property.
# congestion_override_for_clustering has default value for all objects.
## Tcl commands to replicate state of the consider_approximate_delay_of_cell_in_sizing property.
# consider_approximate_delay_of_cell_in_sizing has default value.
## Tcl commands to replicate state of the consider_bus_ports_dont_touch property.
# consider_bus_ports_dont_touch has default value.
## Tcl commands to replicate state of the consider_during_latency_update property.
# consider_during_latency_update has default value for all objects.
## Tcl commands to replicate state of the consider_em_constraints property.
# consider_em_constraints has default value.
## Tcl commands to replicate state of the consider_em_distance_factor property.
# consider_em_distance_factor has default value.
## Tcl commands to replicate state of the consider_liberty_pin_max_trans property.
# consider_liberty_pin_max_trans has default value.
## Tcl commands to replicate state of the consider_power_management property.
# consider_power_management has default value.
## Tcl commands to replicate state of the consider_restricted_placement_region_during_upsizing property.
# consider_restricted_placement_region_during_upsizing has default value.
## Tcl commands to replicate state of the consider_unbufferable_siblings_in_case_h property.
# consider_unbufferable_siblings_in_case_h has default value.
## Tcl commands to replicate state of the constrain_for_right_size_after_delay property.
# constrain_for_right_size_after_delay has default value.
## Tcl commands to replicate state of the constrain_output_pin_max_trans property.
# constrain_output_pin_max_trans has default value.
## Tcl commands to replicate state of the constrained_node_delay_cache_max_size property.
# constrained_node_delay_cache_max_size has default value.
## Tcl commands to replicate state of the constrained_node_transform_cache_max_size property.
# constrained_node_transform_cache_max_size has default value.
## Tcl commands to replicate state of the constrains property.
# constrains has default value for all objects.
## Tcl commands to replicate state of the convert_pin_insertion_delays_to_stage_depth property.
# convert_pin_insertion_delays_to_stage_depth has default value.
## Tcl commands to replicate state of the convert_special_wires property.
# convert_special_wires has default value.
## Tcl commands to replicate state of the create_route_guides_for_two_term_nets property.
# create_route_guides_for_two_term_nets has default value.
## Tcl commands to replicate state of the ctd_debug_always_show_windows property.
# ctd_debug_always_show_windows has default value.
## Tcl commands to replicate state of the ctd_debug_min_object_count property.
# ctd_debug_min_object_count has default value.
## Tcl commands to replicate state of the ctd_debug_min_sink_count property.
# ctd_debug_min_sink_count has default value.
## Tcl commands to replicate state of the ctd_debug_skip_path_timing property.
# ctd_debug_skip_path_timing has default value.
## Tcl commands to replicate state of the ctd_enable_internal_features property.
# ctd_enable_internal_features has default value.
## Tcl commands to replicate state of the cte_identify_clock_tree_incremental_mode property.
# cte_identify_clock_tree_incremental_mode has default value.
## Tcl commands to replicate state of the cts_binary_chop_to_validate_cell_lists property.
# cts_binary_chop_to_validate_cell_lists has default value.
## Tcl commands to replicate state of the cts_check_design_fixed_inst_fraction property.
# cts_check_design_fixed_inst_fraction has default value.
## Tcl commands to replicate state of the cts_clock_gate_movement_limit property.
# cts_clock_gate_movement_limit has default value.
## Tcl commands to replicate state of the cts_critical_capture_pin property.
# cts_critical_capture_pin has default value for all objects.
## Tcl commands to replicate state of the cts_critical_capture_slew property.
# cts_critical_capture_slew has default value for all objects.
## Tcl commands to replicate state of the cts_critical_launch_load property.
# cts_critical_launch_load has default value for all objects.
## Tcl commands to replicate state of the cts_critical_launch_pin property.
# cts_critical_launch_pin has default value for all objects.
## Tcl commands to replicate state of the cts_def_lock_clock_network_after_resynthesis property.
# cts_def_lock_clock_network_after_resynthesis has default value.
## Tcl commands to replicate state of the cts_def_lock_clock_sinks property.
# cts_def_lock_clock_sinks has default value.
## Tcl commands to replicate state of the cts_def_lock_clock_sinks_after_routing property.
# cts_def_lock_clock_sinks_after_routing has default value.
## Tcl commands to replicate state of the cts_def_lock_clock_sinks_at_ccopt_engine_destroy property.
# cts_def_lock_clock_sinks_at_ccopt_engine_destroy has default value.
## Tcl commands to replicate state of the cts_edge_sensitivity property.
# cts_edge_sensitivity has default value for all objects.
## Tcl commands to replicate state of the cts_enable_generator_path_fragments property.
# cts_enable_generator_path_fragments has default value.
## Tcl commands to replicate state of the cts_force_clock_objects_to_propagated property.
# cts_force_clock_objects_to_propagated has default value.
## Tcl commands to replicate state of the cts_internal_messages property.
# cts_internal_messages has default value.
## Tcl commands to replicate state of the cts_isolated property.
# cts_isolated has default value for all objects.
## Tcl commands to replicate state of the cts_max_thread_override property.
set_ccopt_property cts_max_thread_override auto
## Tcl commands to replicate state of the cts_merge_clock_gates property.
# cts_merge_clock_gates has default value for all objects.
## Tcl commands to replicate state of the cts_merge_clock_gates_vertically property.
# cts_merge_clock_gates_vertically has default value.
## Tcl commands to replicate state of the cts_merge_clock_logic property.
# cts_merge_clock_logic has default value for all objects.
## Tcl commands to replicate state of the cts_multi_corner_sink_type property.
# cts_multi_corner_sink_type has default value.
## Tcl commands to replicate state of the cts_multi_corner_slew_targets property.
# cts_multi_corner_slew_targets has default value.
## Tcl commands to replicate state of the cts_multi_sink_node_to_node_fragments property.
# cts_multi_sink_node_to_node_fragments has default value.
## Tcl commands to replicate state of the cts_relax_skew_target property.
# cts_relax_skew_target has default value.
## Tcl commands to replicate state of the cts_relax_skew_target_ratio property.
# cts_relax_skew_target_ratio has default value.
## Tcl commands to replicate state of the cts_relax_skew_target_ratio_low property.
# cts_relax_skew_target_ratio_low has default value.
## Tcl commands to replicate state of the cts_relax_skew_target_restore property.
# cts_relax_skew_target_restore has default value.
## Tcl commands to replicate state of the cts_rnd_virtual_delay_cross_corner_scale_factor property.
# cts_rnd_virtual_delay_cross_corner_scale_factor has default value for all objects.
## Tcl commands to replicate state of the cts_route_buffering_allow_preserved_ports property.
# cts_route_buffering_allow_preserved_ports has default value.
## Tcl commands to replicate state of the cts_route_buffering_allow_preserved_ports_on_ilm_nets property.
# cts_route_buffering_allow_preserved_ports_on_ilm_nets has default value.
## Tcl commands to replicate state of the cts_route_buffering_draw_svg property.
# cts_route_buffering_draw_svg has default value.
## Tcl commands to replicate state of the cts_route_buffering_export_topology property.
# cts_route_buffering_export_topology has default value.
## Tcl commands to replicate state of the cts_route_buffering_include_root_in_timing property.
# cts_route_buffering_include_root_in_timing has default value.
## Tcl commands to replicate state of the cts_route_buffering_include_sinks_in_timing property.
# cts_route_buffering_include_sinks_in_timing has default value.
## Tcl commands to replicate state of the cts_route_buffering_loose_skew_margin_multiplier property.
# cts_route_buffering_loose_skew_margin_multiplier has default value.
## Tcl commands to replicate state of the cts_route_buffering_max_merged_solutions property.
# cts_route_buffering_max_merged_solutions has default value.
## Tcl commands to replicate state of the cts_route_buffering_split_branch_and_buffer property.
# cts_route_buffering_split_branch_and_buffer has default value.
## Tcl commands to replicate state of the cts_routing_estimate_spread_nodes property.
# cts_routing_estimate_spread_nodes has default value.
## Tcl commands to replicate state of the cts_share_global_timing_engine property.
# cts_share_global_timing_engine has default value.
## Tcl commands to replicate state of the cts_split_run_trial property.
# cts_split_run_trial has default value.
## Tcl commands to replicate state of the cts_unfixable_overload_use_override_targets property.
# cts_unfixable_overload_use_override_targets has default value.
## Tcl commands to replicate state of the cts_use_sp_ideal_orientation property.
# cts_use_sp_ideal_orientation has default value.
## Tcl commands to replicate state of the dag_stats_always_include_detailed_skew property.
# dag_stats_always_include_detailed_skew has default value.
## Tcl commands to replicate state of the debug_cong_repair_after_clustering property.
# debug_cong_repair_after_clustering has default value.
## Tcl commands to replicate state of the debug_locks_on_large_legalizer_difference property.
# debug_locks_on_large_legalizer_difference has default value.
## Tcl commands to replicate state of the debug_log_errors_during_ccopt_restore property.
# debug_log_errors_during_ccopt_restore has default value.
## Tcl commands to replicate state of the debug_output_report_dir property.
# debug_output_report_dir has default value.
## Tcl commands to replicate state of the debug_output_report_step_list property.
# debug_output_report_step_list has default value.
## Tcl commands to replicate state of the debug_saved_ccopt_state_to_dir property.
# debug_saved_ccopt_state_to_dir has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_designobject_uid_list property.
# debug_stacktrace_on_designobject_uid_list has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_length property.
# debug_stacktrace_on_length has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_netlist_object_fhn_list property.
# debug_stacktrace_on_netlist_object_fhn_list has default value.
## Tcl commands to replicate state of the debug_stacktrace_on_uid_list property.
# debug_stacktrace_on_uid_list has default value.
## Tcl commands to replicate state of the debug_stage_delays_for_nodes property.
# debug_stage_delays_for_nodes has default value.
## Tcl commands to replicate state of the default_prim_dijkstra_factor_for_clustering_leaf_net property.
# default_prim_dijkstra_factor_for_clustering_leaf_net has default value.
## Tcl commands to replicate state of the default_prim_dijkstra_factor_for_clustering_top_net property.
# default_prim_dijkstra_factor_for_clustering_top_net has default value.
## Tcl commands to replicate state of the default_prim_dijkstra_factor_for_clustering_trunk_net property.
# default_prim_dijkstra_factor_for_clustering_trunk_net has default value.
## Tcl commands to replicate state of the define_clock_tree_release_nonclock_gates_patch property.
# define_clock_tree_release_nonclock_gates_patch has default value.
## Tcl commands to replicate state of the degenerate_routing_estimate_cap_factor property.
# degenerate_routing_estimate_cap_factor has default value.
## Tcl commands to replicate state of the degrade_asserted_transition property.
# degrade_asserted_transition has default value.
## Tcl commands to replicate state of the delay_cells property.
# delay_cells has default value for all objects.
## Tcl commands to replicate state of the delay_corner_filtering property.
# delay_corner_filtering has default value.
## Tcl commands to replicate state of the delay_corner_filtering_keep_views property.
# delay_corner_filtering_keep_views has default value.
## Tcl commands to replicate state of the detach_gates_iterate_over_all_hnets_in_hinst property.
# detach_gates_iterate_over_all_hnets_in_hinst has default value.
## Tcl commands to replicate state of the detailed_balance_max_drive_cell property.
# detailed_balance_max_drive_cell has default value.
## Tcl commands to replicate state of the detailed_cell_warnings property.
# detailed_cell_warnings has default value.
## Tcl commands to replicate state of the detailed_dag_stats_window_outage_report property.
# detailed_dag_stats_window_outage_report has default value.
## Tcl commands to replicate state of the detailed_final_ignore_exclusion property.
# detailed_final_ignore_exclusion has default value.
## Tcl commands to replicate state of the diag_on_non_fatal_assert property.
# diag_on_non_fatal_assert has default value.
## Tcl commands to replicate state of the disable_cell_renaming property.
# disable_cell_renaming has default value.
## Tcl commands to replicate state of the disable_timing_arc_across_ilm_boundary property.
# disable_timing_arc_across_ilm_boundary has default value.
## Tcl commands to replicate state of the distance_from_locked_parent_restriction property.
# distance_from_locked_parent_restriction has default value for all objects.
## Tcl commands to replicate state of the distance_from_locked_parent_restriction_calculation_uses_all_cells property.
# distance_from_locked_parent_restriction_calculation_uses_all_cells has default value.
## Tcl commands to replicate state of the dont_commit_attributes_more_than_once property.
# dont_commit_attributes_more_than_once has default value.
## Tcl commands to replicate state of the dont_touch_non_flop_clock_gating_treat_latches_as_flops property.
# dont_touch_non_flop_clock_gating_treat_latches_as_flops has default value.
## Tcl commands to replicate state of the down_skew_band_size_ideal_mode property.
# down_skew_band_size_ideal_mode has default value.
## Tcl commands to replicate state of the driver_levels property.
## Tcl commands to replicate state of the driver_movement_limit property.
# driver_movement_limit has default value.
## Tcl commands to replicate state of the early_global_layer_relax property.
# early_global_layer_relax has default value.
## Tcl commands to replicate state of the early_global_layer_relax_ratio property.
# early_global_layer_relax_ratio has default value.
## Tcl commands to replicate state of the early_global_leaf_congestion_ratio property.
# early_global_leaf_congestion_ratio has default value.
## Tcl commands to replicate state of the early_global_leaf_rows_per_gcell property.
# early_global_leaf_rows_per_gcell has default value.
## Tcl commands to replicate state of the early_global_leaf_scenic_ratio property.
# early_global_leaf_scenic_ratio has default value.
## Tcl commands to replicate state of the early_global_leaf_source_sink_ratio property.
# early_global_leaf_source_sink_ratio has default value.
## Tcl commands to replicate state of the early_global_route_guide_align_to_gcell_centers property.
# early_global_route_guide_align_to_gcell_centers has default value.
## Tcl commands to replicate state of the early_global_route_guide_min_downstream_wirelength property.
# early_global_route_guide_min_downstream_wirelength has default value.
## Tcl commands to replicate state of the early_global_route_guide_pruning_method property.
# early_global_route_guide_pruning_method has default value.
## Tcl commands to replicate state of the early_global_trunk_congestion_ratio property.
# early_global_trunk_congestion_ratio has default value.
## Tcl commands to replicate state of the early_global_trunk_rows_per_gcell property.
# early_global_trunk_rows_per_gcell has default value.
## Tcl commands to replicate state of the early_global_trunk_scenic_ratio property.
# early_global_trunk_scenic_ratio has default value.
## Tcl commands to replicate state of the early_global_trunk_source_sink_ratio property.
# early_global_trunk_source_sink_ratio has default value.
## Tcl commands to replicate state of the early_global_use_existing_estimate_as_guide property.
# early_global_use_existing_estimate_as_guide has default value.
## Tcl commands to replicate state of the echo_sylog_to_debug property.
# echo_sylog_to_debug has default value.
## Tcl commands to replicate state of the effective_distance_from_locked_parent_restriction property.
# effective_distance_from_locked_parent_restriction has default value for all objects.
## Tcl commands to replicate state of the egrpc_agglom_clustering_ratio_threshold property.
# egrpc_agglom_clustering_ratio_threshold has default value.
## Tcl commands to replicate state of the egrpc_call_refine_place_in_loop property.
# egrpc_call_refine_place_in_loop has default value.
## Tcl commands to replicate state of the egrpc_clone_and_divide_overslew_threshold property.
# egrpc_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the egrpc_downsize_algorithm_passes property.
# egrpc_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the egrpc_downsize_algorithm_use_single_step property.
# egrpc_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the egrpc_downsize_slew_target_multiplier property.
# egrpc_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the egrpc_downsize_with_cloning property.
# egrpc_downsize_with_cloning has default value.
## Tcl commands to replicate state of the egrpc_drv_buffering_number_to_keep property.
# egrpc_drv_buffering_number_to_keep has default value.
## Tcl commands to replicate state of the egrpc_drv_buffering_second_pass_number_to_keep property.
# egrpc_drv_buffering_second_pass_number_to_keep has default value.
## Tcl commands to replicate state of the egrpc_enable property.
# egrpc_enable has default value.
## Tcl commands to replicate state of the egrpc_enable_agglom_clustering property.
# egrpc_enable_agglom_clustering has default value.
## Tcl commands to replicate state of the egrpc_enable_clone_and_divide property.
# egrpc_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the egrpc_enable_down_sizing_pass property.
# egrpc_enable_down_sizing_pass has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_fixing_by_rebuffering property.
# egrpc_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_fixing_by_rebuffering_second_pass property.
# egrpc_enable_drv_fixing_by_rebuffering_second_pass has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_fixing_with_restructuring property.
# egrpc_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the egrpc_enable_drv_initial_sizing property.
# egrpc_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_down_sizing_pass property.
# egrpc_enable_initial_down_sizing_pass has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_fixing_long_paths property.
# egrpc_enable_initial_fixing_long_paths has default value.
## Tcl commands to replicate state of the egrpc_enable_initial_move_for_pin_access property.
# egrpc_enable_initial_move_for_pin_access has default value.
## Tcl commands to replicate state of the egrpc_enable_max_length_checks property.
# egrpc_enable_max_length_checks has default value.
## Tcl commands to replicate state of the egrpc_enable_move_down property.
# egrpc_enable_move_down has default value.
## Tcl commands to replicate state of the egrpc_enable_move_for_pin_access property.
# egrpc_enable_move_for_pin_access has default value.
## Tcl commands to replicate state of the egrpc_enable_move_to_geodesic_center property.
# egrpc_enable_move_to_geodesic_center has default value.
## Tcl commands to replicate state of the egrpc_enable_prim_dijkstra_adjust property.
# egrpc_enable_prim_dijkstra_adjust has default value.
## Tcl commands to replicate state of the egrpc_enable_routing_correlation_report property.
# egrpc_enable_routing_correlation_report has default value.
## Tcl commands to replicate state of the egrpc_enable_skew_fixing_by_cell_sizing property.
# egrpc_enable_skew_fixing_by_cell_sizing has default value.
## Tcl commands to replicate state of the egrpc_enable_skew_fixing_by_rebuffering property.
# egrpc_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the egrpc_final_down_sizing_pass property.
# egrpc_final_down_sizing_pass has default value.
## Tcl commands to replicate state of the egrpc_fix_routes property.
# egrpc_fix_routes has default value.
## Tcl commands to replicate state of the egrpc_loop_limit property.
# egrpc_loop_limit has default value.
## Tcl commands to replicate state of the egrpc_max_move_multiplier property.
# egrpc_max_move_multiplier has default value.
## Tcl commands to replicate state of the egrpc_min_overslew_to_fix_using_buffering_in_ps property.
# egrpc_min_overslew_to_fix_using_buffering_in_ps has default value.
## Tcl commands to replicate state of the egrpc_min_overslew_to_fix_using_buffering_second_pass_in_ps property.
# egrpc_min_overslew_to_fix_using_buffering_second_pass_in_ps has default value.
## Tcl commands to replicate state of the egrpc_min_overslew_to_fix_using_sizing_in_ps property.
# egrpc_min_overslew_to_fix_using_sizing_in_ps has default value.
## Tcl commands to replicate state of the egrpc_update_timing property.
# egrpc_update_timing has default value.
## Tcl commands to replicate state of the egrpc_use_fast_cell_sizing_algorithm property.
# egrpc_use_fast_cell_sizing_algorithm has default value.
## Tcl commands to replicate state of the egrpc_verify_legal property.
# egrpc_verify_legal has default value.
## Tcl commands to replicate state of the em_constraints_target_max_cap_pin_cap_factor property.
# em_constraints_target_max_cap_pin_cap_factor has default value.
## Tcl commands to replicate state of the enable_adjacent_cell_color_checks property.
# enable_adjacent_cell_color_checks has default value.
## Tcl commands to replicate state of the enable_all_views_for_io_latency_update property.
# enable_all_views_for_io_latency_update has default value.
## Tcl commands to replicate state of the enable_assert_single_threaded property.
# enable_assert_single_threaded has default value.
## Tcl commands to replicate state of the enable_channel_graph_line_coverage property.
# enable_channel_graph_line_coverage has default value.
## Tcl commands to replicate state of the enable_clock_pin_alignment_during_refine_place property.
# enable_clock_pin_alignment_during_refine_place has default value.
## Tcl commands to replicate state of the enable_constraints_from_xhinsts property.
# enable_constraints_from_xhinsts has default value.
## Tcl commands to replicate state of the enable_correlation_report_extra_stats property.
# enable_correlation_report_extra_stats has default value.
## Tcl commands to replicate state of the enable_downstream_net_route_invalidation property.
# enable_downstream_net_route_invalidation has default value.
## Tcl commands to replicate state of the enable_evaluate_cluster_cache property.
# enable_evaluate_cluster_cache has default value.
## Tcl commands to replicate state of the enable_flop_merge_split_support property.
# enable_flop_merge_split_support has default value.
## Tcl commands to replicate state of the enable_implementation property.
# enable_implementation has default value.
## Tcl commands to replicate state of the enable_initial_clustering property.
# enable_initial_clustering has default value.
## Tcl commands to replicate state of the enable_invalidate_timing_after_resynth property.
# enable_invalidate_timing_after_resynth has default value.
## Tcl commands to replicate state of the enable_latch_sta_updates property.
# enable_latch_sta_updates has default value.
## Tcl commands to replicate state of the enable_legacy_cts_metric_reporting property.
# enable_legacy_cts_metric_reporting has default value.
## Tcl commands to replicate state of the enable_nanoroute_layer_check_failure property.
# enable_nanoroute_layer_check_failure has default value.
## Tcl commands to replicate state of the enable_new_stage_depth_counting property.
# enable_new_stage_depth_counting has default value.
## Tcl commands to replicate state of the enable_power_analysis property.
# enable_power_analysis has default value.
## Tcl commands to replicate state of the enable_primdijkstra_xgraph_dump property.
# enable_primdijkstra_xgraph_dump has default value.
## Tcl commands to replicate state of the enable_ratchet_detailed_balancer property.
# enable_ratchet_detailed_balancer has default value.
## Tcl commands to replicate state of the enable_resynthesis_correlation_report property.
# enable_resynthesis_correlation_report has default value.
## Tcl commands to replicate state of the enable_routing_correlation_report property.
# enable_routing_correlation_report has default value.
## Tcl commands to replicate state of the enable_timing_chain_manager_in_ccopt_design property.
# enable_timing_chain_manager_in_ccopt_design has default value.
## Tcl commands to replicate state of the enable_worst_chain_report_in_ccopt_design property.
# enable_worst_chain_report_in_ccopt_design has default value.
## Tcl commands to replicate state of the ensure_connected_rc_net property.
# ensure_connected_rc_net has default value.
## Tcl commands to replicate state of the equalize_net_lengths property.
# equalize_net_lengths has default value for all objects.
## Tcl commands to replicate state of the estimate_to_detailed_route_capacitance_scaling_factor property.
# estimate_to_detailed_route_capacitance_scaling_factor has default value.
## Tcl commands to replicate state of the estimate_to_detailed_route_capacitance_scaling_factor_applied property.
# estimate_to_detailed_route_capacitance_scaling_factor_applied has default value.
## Tcl commands to replicate state of the estimate_to_detailed_route_resistance_scaling_factor property.
# estimate_to_detailed_route_resistance_scaling_factor has default value.
## Tcl commands to replicate state of the estimate_to_detailed_route_resistance_scaling_factor_applied property.
# estimate_to_detailed_route_resistance_scaling_factor_applied has default value.
## Tcl commands to replicate state of the exclude_delays_below_sinks property.
# exclude_delays_below_sinks has default value for all objects.
## Tcl commands to replicate state of the exclusive_sinks_rank property.
# exclusive_sinks_rank has default value for all objects.
## Tcl commands to replicate state of the exit_if_trial_balance_delay_estimation_high property.
# exit_if_trial_balance_delay_estimation_high has default value.
## Tcl commands to replicate state of the exp_activity_driven_decrease_wire_cap_preserve_route_lengths property.
# exp_activity_driven_decrease_wire_cap_preserve_route_lengths has default value.
## Tcl commands to replicate state of the exp_activity_driven_do_diagonal_diamond_moves property.
# exp_activity_driven_do_diagonal_diamond_moves has default value.
## Tcl commands to replicate state of the exp_activity_driven_do_tiny_horizontal_moves property.
# exp_activity_driven_do_tiny_horizontal_moves has default value.
## Tcl commands to replicate state of the exp_activity_driven_improving_clock_tree_routing_method property.
# exp_activity_driven_improving_clock_tree_routing_method has default value.
## Tcl commands to replicate state of the exp_activity_driven_max_move_gate_passes property.
# exp_activity_driven_max_move_gate_passes has default value.
## Tcl commands to replicate state of the exp_activity_driven_move_gate_distance_divisor property.
# exp_activity_driven_move_gate_distance_divisor has default value.
## Tcl commands to replicate state of the exp_activity_driven_move_gate_max_move_iterations property.
# exp_activity_driven_move_gate_max_move_iterations has default value.
## Tcl commands to replicate state of the exp_activity_driven_move_gate_max_move_row_height_multiple property.
# exp_activity_driven_move_gate_max_move_row_height_multiple has default value.
## Tcl commands to replicate state of the exp_activity_driven_move_gate_prune_mode property.
# exp_activity_driven_move_gate_prune_mode has default value.
## Tcl commands to replicate state of the exp_activity_driven_move_gate_wl_based_pruning_threshold property.
# exp_activity_driven_move_gate_wl_based_pruning_threshold has default value.
## Tcl commands to replicate state of the exp_activity_driven_movegates_multithreaded property.
# exp_activity_driven_movegates_multithreaded has default value.
## Tcl commands to replicate state of the exp_activity_driven_overslew_in_delayed_legalization_ordering property.
# exp_activity_driven_overslew_in_delayed_legalization_ordering has default value.
## Tcl commands to replicate state of the exp_activity_driven_preserve_band property.
# exp_activity_driven_preserve_band has default value.
## Tcl commands to replicate state of the exp_activity_driven_preserve_band_per_iteration property.
# exp_activity_driven_preserve_band_per_iteration has default value.
## Tcl commands to replicate state of the exp_activity_driven_preserve_band_safely property.
# exp_activity_driven_preserve_band_safely has default value.
## Tcl commands to replicate state of the exp_activity_driven_single_move_per_unit_distance property.
# exp_activity_driven_single_move_per_unit_distance has default value.
## Tcl commands to replicate state of the exp_activity_driven_skew_margin_multiplier property.
# exp_activity_driven_skew_margin_multiplier has default value.
## Tcl commands to replicate state of the exp_activity_driven_skip_post_move_verification property.
# exp_activity_driven_skip_post_move_verification has default value.
## Tcl commands to replicate state of the exp_activity_driven_slew_margin_multiplier property.
# exp_activity_driven_slew_margin_multiplier has default value.
## Tcl commands to replicate state of the exp_activity_driven_use_integral_row_height_multiple property.
# exp_activity_driven_use_integral_row_height_multiple has default value.
## Tcl commands to replicate state of the exp_activity_driven_wire_cap_reduction_multithreaded property.
# exp_activity_driven_wire_cap_reduction_multithreaded has default value.
## Tcl commands to replicate state of the exp_add_port_drivers_use_msv_aware_buffering_context property.
# exp_add_port_drivers_use_msv_aware_buffering_context has default value.
## Tcl commands to replicate state of the exp_advanced_clock_routing property.
# exp_advanced_clock_routing has default value.
## Tcl commands to replicate state of the exp_advanced_clock_routing_fix property.
# exp_advanced_clock_routing_fix has default value.
## Tcl commands to replicate state of the exp_advanced_clock_routing_via_pillar property.
# exp_advanced_clock_routing_via_pillar has default value.
## Tcl commands to replicate state of the exp_advanced_early_global_guide property.
# exp_advanced_early_global_guide has default value.
## Tcl commands to replicate state of the exp_allow_legalizer_to_search_outside_preferred_rectangle property.
# exp_allow_legalizer_to_search_outside_preferred_rectangle has default value.
## Tcl commands to replicate state of the exp_allow_multithreading_with_non_integrated_clock_gates property.
# exp_allow_multithreading_with_non_integrated_clock_gates has default value.
## Tcl commands to replicate state of the exp_allow_pin_insertion_delay_offsets_to_dominate_max_id property.
# exp_allow_pin_insertion_delay_offsets_to_dominate_max_id has default value.
## Tcl commands to replicate state of the exp_allow_pruning_of_primary_delay_corner property.
# exp_allow_pruning_of_primary_delay_corner has default value.
## Tcl commands to replicate state of the exp_allow_resize_of_instances_touching_pre_routes property.
# exp_allow_resize_of_instances_touching_pre_routes has default value.
## Tcl commands to replicate state of the exp_allow_stage_delay_change_in_sizing property.
# exp_allow_stage_delay_change_in_sizing has default value.
## Tcl commands to replicate state of the exp_always_reactivate_legalizer property.
# exp_always_reactivate_legalizer has default value.
## Tcl commands to replicate state of the exp_always_use_thread_safe_power_analysis property.
# exp_always_use_thread_safe_power_analysis has default value.
## Tcl commands to replicate state of the exp_apply_clock_halos_to_roots property.
# exp_apply_clock_halos_to_roots has default value.
## Tcl commands to replicate state of the exp_apply_timing_delta_for_after_approx_balancing property.
# exp_apply_timing_delta_for_after_approx_balancing has default value.
## Tcl commands to replicate state of the exp_apply_timing_delta_for_after_clustering property.
# exp_apply_timing_delta_for_after_clustering has default value.
## Tcl commands to replicate state of the exp_apply_timing_delta_for_clustering property.
# exp_apply_timing_delta_for_clustering has default value.
## Tcl commands to replicate state of the exp_approximate_balance_buffer_under_delayed_fanout_by_unbuffering property.
# exp_approximate_balance_buffer_under_delayed_fanout_by_unbuffering has default value.
## Tcl commands to replicate state of the exp_auto_compute_slew_target_row_height_factor property.
# exp_auto_compute_slew_target_row_height_factor has default value.
## Tcl commands to replicate state of the exp_auto_slew_target_buffer_count property.
# exp_auto_slew_target_buffer_count has default value.
## Tcl commands to replicate state of the exp_auto_slew_target_inverter_count property.
# exp_auto_slew_target_inverter_count has default value.
## Tcl commands to replicate state of the exp_balance_source_group_allow_std_dev_increase property.
# exp_balance_source_group_allow_std_dev_increase has default value.
## Tcl commands to replicate state of the exp_balancing_with_transforms_enable_multithreading property.
# exp_balancing_with_transforms_enable_multithreading has default value.
## Tcl commands to replicate state of the exp_block_space_for_soft_fixed_insts property.
# exp_block_space_for_soft_fixed_insts has default value.
## Tcl commands to replicate state of the exp_bottom_up_balancer_infinite_only_limit property.
# exp_bottom_up_balancer_infinite_only_limit has default value.
## Tcl commands to replicate state of the exp_buf_buf_distribution_span property.
# exp_buf_buf_distribution_span has default value.
## Tcl commands to replicate state of the exp_buffer_fanout_in_reducing_insertion_delay_2_offload_driver_only property.
# exp_buffer_fanout_in_reducing_insertion_delay_2_offload_driver_only has default value.
## Tcl commands to replicate state of the exp_buffer_fanout_in_reducing_insertion_delay_2_root_branch_point_only property.
# exp_buffer_fanout_in_reducing_insertion_delay_2_root_branch_point_only has default value.
## Tcl commands to replicate state of the exp_bufferability_consider_hnet_dont_touch property.
# exp_bufferability_consider_hnet_dont_touch has default value.
## Tcl commands to replicate state of the exp_call_steiner_opt_recovery property.
# exp_call_steiner_opt_recovery has default value.
## Tcl commands to replicate state of the exp_can_change_ilm_type property.
# exp_can_change_ilm_type has default value.
## Tcl commands to replicate state of the exp_cellinst_record_touches_preroute_map property.
# exp_cellinst_record_touches_preroute_map has default value.
## Tcl commands to replicate state of the exp_check_design_too_many_unbufferable_nets_threshold property.
# exp_check_design_too_many_unbufferable_nets_threshold has default value.
## Tcl commands to replicate state of the exp_check_overlap_placement_group_and_power_domain_region property.
# exp_check_overlap_placement_group_and_power_domain_region has default value.
## Tcl commands to replicate state of the exp_check_sink_inversion_for_each_step property.
# exp_check_sink_inversion_for_each_step has default value.
## Tcl commands to replicate state of the exp_check_timing_pin_status property.
# exp_check_timing_pin_status has default value.
## Tcl commands to replicate state of the exp_clear_aae_data_after_command property.
# exp_clear_aae_data_after_command has default value.
## Tcl commands to replicate state of the exp_clock_gate_movement_limit_um property.
# exp_clock_gate_movement_limit_um has default value.
## Tcl commands to replicate state of the exp_clock_gate_multiple_delay_groups property.
# exp_clock_gate_multiple_delay_groups has default value.
## Tcl commands to replicate state of the exp_clock_gates_must_be_legal_in_power_domain_analysis property.
# exp_clock_gates_must_be_legal_in_power_domain_analysis has default value.
## Tcl commands to replicate state of the exp_clock_halo_types_supplied_to_opt_design property.
# exp_clock_halo_types_supplied_to_opt_design has default value.
## Tcl commands to replicate state of the exp_clock_node_clone_instance_placement_group_fix property.
# exp_clock_node_clone_instance_placement_group_fix has default value.
## Tcl commands to replicate state of the exp_clock_node_restricted_placement_region_fix property.
# exp_clock_node_restricted_placement_region_fix has default value.
## Tcl commands to replicate state of the exp_clock_tree_timing_assert_on_un_placed_instances property.
# exp_clock_tree_timing_assert_on_un_placed_instances has default value.
## Tcl commands to replicate state of the exp_clone_power_domain_boundary_cells property.
# exp_clone_power_domain_boundary_cells has default value.
## Tcl commands to replicate state of the exp_cluster_agglom_borderline_failing_threshold property.
# exp_cluster_agglom_borderline_failing_threshold has default value.
## Tcl commands to replicate state of the exp_cluster_agglom_pin_move_estimated_cost_mode property.
# exp_cluster_agglom_pin_move_estimated_cost_mode has default value.
## Tcl commands to replicate state of the exp_cluster_icg_driving_distance_refinement_fix property.
# exp_cluster_icg_driving_distance_refinement_fix has default value.
## Tcl commands to replicate state of the exp_cluster_icg_empty_tap_assignment_fix property.
# exp_cluster_icg_empty_tap_assignment_fix has default value.
## Tcl commands to replicate state of the exp_cluster_icg_verbose_level property.
# exp_cluster_icg_verbose_level has default value.
## Tcl commands to replicate state of the exp_clustering_assume_buffer_drive_for_untimeable_instances property.
# exp_clustering_assume_buffer_drive_for_untimeable_instances has default value.
## Tcl commands to replicate state of the exp_clustering_avoid_routing_long_nets_checking_mode property.
# exp_clustering_avoid_routing_long_nets_checking_mode has default value.
## Tcl commands to replicate state of the exp_clustering_avoid_routing_long_nets_factor property.
# exp_clustering_avoid_routing_long_nets_factor has default value.
## Tcl commands to replicate state of the exp_clustering_avoid_routing_long_nets_in_case_c property.
# exp_clustering_avoid_routing_long_nets_in_case_c has default value.
## Tcl commands to replicate state of the exp_clustering_avoid_routing_long_nets_in_evaluate_clusters property.
# exp_clustering_avoid_routing_long_nets_in_evaluate_clusters has default value.
## Tcl commands to replicate state of the exp_clustering_cache_driver_skew_groups property.
# exp_clustering_cache_driver_skew_groups has default value.
## Tcl commands to replicate state of the exp_clustering_cloning_partition_delay property.
# exp_clustering_cloning_partition_delay has default value for all objects.
## Tcl commands to replicate state of the exp_clustering_consider_created_by_agglom_in_gdc_bailout property.
# exp_clustering_consider_created_by_agglom_in_gdc_bailout has default value.
## Tcl commands to replicate state of the exp_clustering_consider_skew_target_tightening_multiplier property.
# exp_clustering_consider_skew_target_tightening_multiplier has default value.
## Tcl commands to replicate state of the exp_clustering_consider_unbufferable_sinks_in_caseb_if_cloning property.
# exp_clustering_consider_unbufferable_sinks_in_caseb_if_cloning has default value.
## Tcl commands to replicate state of the exp_clustering_drive_regions_fix_macro_drive_region_for_1999064 property.
# exp_clustering_drive_regions_fix_macro_drive_region_for_1999064 has default value.
## Tcl commands to replicate state of the exp_clustering_fix_drive_region_caching property.
# exp_clustering_fix_drive_region_caching has default value.
## Tcl commands to replicate state of the exp_clustering_fix_drive_regions_at_power_domain_boundaries property.
# exp_clustering_fix_drive_regions_at_power_domain_boundaries has default value.
## Tcl commands to replicate state of the exp_clustering_fix_drv_issue_with_refine_regions_to_improve_wire_cap property.
# exp_clustering_fix_drv_issue_with_refine_regions_to_improve_wire_cap has default value.
## Tcl commands to replicate state of the exp_clustering_fix_gate_driving_code_routing_info_category property.
# exp_clustering_fix_gate_driving_code_routing_info_category has default value.
## Tcl commands to replicate state of the exp_clustering_fix_logical_power_domain_partitioning property.
# exp_clustering_fix_logical_power_domain_partitioning has default value.
## Tcl commands to replicate state of the exp_clustering_gate_driving_code_fix_region_clipping property.
# exp_clustering_gate_driving_code_fix_region_clipping has default value.
## Tcl commands to replicate state of the exp_clustering_large_design property.
# exp_clustering_large_design has default value.
## Tcl commands to replicate state of the exp_clustering_place_driver_in_center_of_fanout_method property.
# exp_clustering_place_driver_in_center_of_fanout_method has default value.
## Tcl commands to replicate state of the exp_clustering_place_driver_in_center_of_fanout_use_route property.
# exp_clustering_place_driver_in_center_of_fanout_use_route has default value.
## Tcl commands to replicate state of the exp_clustering_progress_check_backstop_limit property.
# exp_clustering_progress_check_backstop_limit has default value.
## Tcl commands to replicate state of the exp_clustering_size_in_delay_partitioning property.
# exp_clustering_size_in_delay_partitioning has default value.
## Tcl commands to replicate state of the exp_clustering_size_in_delay_partitioning_consider_inversions property.
# exp_clustering_size_in_delay_partitioning_consider_inversions has default value.
## Tcl commands to replicate state of the exp_clustering_size_in_delay_partitioning_stage_depth_limit property.
# exp_clustering_size_in_delay_partitioning_stage_depth_limit has default value.
## Tcl commands to replicate state of the exp_clustering_size_in_delay_partitioning_upsize_fanout property.
# exp_clustering_size_in_delay_partitioning_upsize_fanout has default value.
## Tcl commands to replicate state of the exp_clustering_size_in_delay_partitioning_use_intermediate_caps property.
# exp_clustering_size_in_delay_partitioning_use_intermediate_caps has default value.
## Tcl commands to replicate state of the exp_clustering_source_group_initial_clone_placement property.
# exp_clustering_source_group_initial_clone_placement has default value.
## Tcl commands to replicate state of the exp_clustering_source_group_revert_assignment_before_merging property.
# exp_clustering_source_group_revert_assignment_before_merging has default value.
## Tcl commands to replicate state of the exp_clustering_source_group_root_separation_distance property.
# exp_clustering_source_group_root_separation_distance has default value.
## Tcl commands to replicate state of the exp_clustering_source_group_tap_relocation_iterations property.
# exp_clustering_source_group_tap_relocation_iterations has default value for all objects.
## Tcl commands to replicate state of the exp_clustering_unit_delay_fallback_value property.
# exp_clustering_unit_delay_fallback_value has default value.
## Tcl commands to replicate state of the exp_clustering_use_multi_corner_input_slews property.
# exp_clustering_use_multi_corner_input_slews has default value.
## Tcl commands to replicate state of the exp_clustering_use_route_estimator_for_sinks_in_ilm property.
# exp_clustering_use_route_estimator_for_sinks_in_ilm has default value.
## Tcl commands to replicate state of the exp_commmit_net_attributes_only_before_cong_repair property.
# exp_commmit_net_attributes_only_before_cong_repair has default value.
## Tcl commands to replicate state of the exp_compare_power_domains_by_voltage property.
# exp_compare_power_domains_by_voltage has default value.
## Tcl commands to replicate state of the exp_connect_aon_cell_pg_terms_to_location_supply_if_needed property.
# exp_connect_aon_cell_pg_terms_to_location_supply_if_needed has default value.
## Tcl commands to replicate state of the exp_consider_multi_driver_nets_to_be_ideal property.
# exp_consider_multi_driver_nets_to_be_ideal has default value.
## Tcl commands to replicate state of the exp_consider_multi_output_cells_driving_mesh property.
# exp_consider_multi_output_cells_driving_mesh has default value.
## Tcl commands to replicate state of the exp_consider_overslew_in_delayed_legalization_ordering property.
# exp_consider_overslew_in_delayed_legalization_ordering has default value.
## Tcl commands to replicate state of the exp_consider_skew_group_equivalence_classes_in_default_mode property.
# exp_consider_skew_group_equivalence_classes_in_default_mode has default value.
## Tcl commands to replicate state of the exp_consider_underdelay_in_delayed_legalization_ordering property.
# exp_consider_underdelay_in_delayed_legalization_ordering has default value.
## Tcl commands to replicate state of the exp_constraint_analysis_minimum_safe_skew_unit_delay_factor property.
# exp_constraint_analysis_minimum_safe_skew_unit_delay_factor has default value.
## Tcl commands to replicate state of the exp_constraint_analysis_override_slackened_skew_targets property.
# exp_constraint_analysis_override_slackened_skew_targets has default value.
## Tcl commands to replicate state of the exp_criteria_early_exit_on_overslew property.
# exp_criteria_early_exit_on_overslew has default value.
## Tcl commands to replicate state of the exp_db_is_dual_view_wire_enabled property.
# exp_db_is_dual_view_wire_enabled has default value.
## Tcl commands to replicate state of the exp_debug_output_report_include_detailed_dump property.
# exp_debug_output_report_include_detailed_dump has default value.
## Tcl commands to replicate state of the exp_debug_sink_delay_and_skew_step_list property.
# exp_debug_sink_delay_and_skew_step_list has default value.
## Tcl commands to replicate state of the exp_decrease_wire_capacitance_preserves_route_lengths property.
# exp_decrease_wire_capacitance_preserves_route_lengths has default value.
## Tcl commands to replicate state of the exp_disable_dag_stats_before_routing_clock_trees property.
# exp_disable_dag_stats_before_routing_clock_trees has default value.
## Tcl commands to replicate state of the exp_dont_change_ilm_type_during_opt_design property.
# exp_dont_change_ilm_type_during_opt_design has default value.
## Tcl commands to replicate state of the exp_dont_touch_ideal_special_nets property.
# exp_dont_touch_ideal_special_nets has default value.
## Tcl commands to replicate state of the exp_driver_movement_limit_um property.
# exp_driver_movement_limit_um has default value.
## Tcl commands to replicate state of the exp_dump_locked_record_for_find_legal_location_fails property.
# exp_dump_locked_record_for_find_legal_location_fails has default value.
## Tcl commands to replicate state of the exp_dump_out_sink_delays property.
# exp_dump_out_sink_delays has default value.
## Tcl commands to replicate state of the exp_dynamic_increment_narrow_failures_fraction_large_size property.
# exp_dynamic_increment_narrow_failures_fraction_large_size has default value.
## Tcl commands to replicate state of the exp_dynamic_increment_narrow_failures_fraction_small_size property.
# exp_dynamic_increment_narrow_failures_fraction_small_size has default value.
## Tcl commands to replicate state of the exp_dynamic_increment_severe_failures_fraction_large_size property.
# exp_dynamic_increment_severe_failures_fraction_large_size has default value.
## Tcl commands to replicate state of the exp_dynamic_increment_severe_failures_fraction_small_size property.
# exp_dynamic_increment_severe_failures_fraction_small_size has default value.
## Tcl commands to replicate state of the exp_dynamic_increment_small_size_sink_count property.
# exp_dynamic_increment_small_size_sink_count has default value.
## Tcl commands to replicate state of the exp_early_clock_enable_ilm_internal_timing property.
# exp_early_clock_enable_ilm_internal_timing has default value.
## Tcl commands to replicate state of the exp_early_clock_set_net_weights property.
# exp_early_clock_set_net_weights has default value.
## Tcl commands to replicate state of the exp_early_global_enhanced_ndr_handling property.
# exp_early_global_enhanced_ndr_handling has default value.
## Tcl commands to replicate state of the exp_early_global_enhanced_track_assignment property.
# exp_early_global_enhanced_track_assignment has default value.
## Tcl commands to replicate state of the exp_early_global_layer_assignment_fix property.
# exp_early_global_layer_assignment_fix has default value.
## Tcl commands to replicate state of the exp_early_global_layer_relax_assignment property.
# exp_early_global_layer_relax_assignment has default value.
## Tcl commands to replicate state of the exp_early_global_post_routing_fix property.
# exp_early_global_post_routing_fix has default value.
## Tcl commands to replicate state of the exp_early_global_route_by_layer_sets property.
# exp_early_global_route_by_layer_sets has default value.
## Tcl commands to replicate state of the exp_early_global_route_ignore_net_type property.
# exp_early_global_route_ignore_net_type has default value.
## Tcl commands to replicate state of the exp_early_global_route_ignore_net_type_with_same_demand property.
# exp_early_global_route_ignore_net_type_with_same_demand has default value.
## Tcl commands to replicate state of the exp_early_global_speedup_clock_routing property.
# exp_early_global_speedup_clock_routing has default value.
## Tcl commands to replicate state of the exp_early_global_strong_post_routing property.
# exp_early_global_strong_post_routing has default value.
## Tcl commands to replicate state of the exp_effective_target_max_trans property.
## Tcl commands to replicate state of the exp_effective_target_max_trans_source property.
## Tcl commands to replicate state of the exp_egrpc_block_out_space_for_clock_sinks property.
# exp_egrpc_block_out_space_for_clock_sinks has default value.
## Tcl commands to replicate state of the exp_egrpc_enable_final_dag_stats property.
# exp_egrpc_enable_final_dag_stats has default value.
## Tcl commands to replicate state of the exp_egrpc_enable_move_sinks_for_skew property.
# exp_egrpc_enable_move_sinks_for_skew has default value.
## Tcl commands to replicate state of the exp_egrpc_enable_move_sinks_for_slew property.
# exp_egrpc_enable_move_sinks_for_slew has default value.
## Tcl commands to replicate state of the exp_egrpc_enable_timing_invalidate_after_optimize property.
# exp_egrpc_enable_timing_invalidate_after_optimize has default value.
## Tcl commands to replicate state of the exp_egrpc_enable_timing_invalidate_after_route_destroying_optimize property.
# exp_egrpc_enable_timing_invalidate_after_route_destroying_optimize has default value.
## Tcl commands to replicate state of the exp_egrpc_flipopt_cell_types property.
# exp_egrpc_flipopt_cell_types has default value.
## Tcl commands to replicate state of the exp_egrpc_flipopt_enable property.
# exp_egrpc_flipopt_enable has default value.
## Tcl commands to replicate state of the exp_egrpc_initial_pass property.
# exp_egrpc_initial_pass has default value.
## Tcl commands to replicate state of the exp_egrpc_initial_pass_drim_dijkstra_adjust property.
# exp_egrpc_initial_pass_drim_dijkstra_adjust has default value.
## Tcl commands to replicate state of the exp_egrpc_initial_pass_move_sinks_for_slew property.
# exp_egrpc_initial_pass_move_sinks_for_slew has default value.
## Tcl commands to replicate state of the exp_egrpc_mark_clock_sinks_on_grid_during_move_sinks property.
# exp_egrpc_mark_clock_sinks_on_grid_during_move_sinks has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_skew_max_percentage_to_move property.
# exp_egrpc_move_sinks_for_skew_max_percentage_to_move has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_skew_max_row_heights property.
# exp_egrpc_move_sinks_for_skew_max_row_heights has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_slew_algorithm property.
# exp_egrpc_move_sinks_for_slew_algorithm has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_slew_max_percentage_to_move property.
# exp_egrpc_move_sinks_for_slew_max_percentage_to_move has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_slew_max_row_heights property.
# exp_egrpc_move_sinks_for_slew_max_row_heights has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_slew_nearer_driver property.
# exp_egrpc_move_sinks_for_slew_nearer_driver has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_for_slew_stop_when_no_net_violation property.
# exp_egrpc_move_sinks_for_slew_stop_when_no_net_violation has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_max_slew_violations_for_net property.
# exp_egrpc_move_sinks_max_slew_violations_for_net has default value.
## Tcl commands to replicate state of the exp_egrpc_move_sinks_min_overslew_to_fix_in_ps property.
# exp_egrpc_move_sinks_min_overslew_to_fix_in_ps has default value.
## Tcl commands to replicate state of the exp_egrpc_recompute_icts_targets property.
# exp_egrpc_recompute_icts_targets has default value.
## Tcl commands to replicate state of the exp_egrpc_refine_place_soft_fix_clock_sinks property.
# exp_egrpc_refine_place_soft_fix_clock_sinks has default value.
## Tcl commands to replicate state of the exp_egrpc_route_destroying_optimization_slew_target_multiplier property.
# exp_egrpc_route_destroying_optimization_slew_target_multiplier has default value.
## Tcl commands to replicate state of the exp_enable_balancing_with_transforms property.
# exp_enable_balancing_with_transforms has default value.
## Tcl commands to replicate state of the exp_enable_buffering_full_search_in_gals property.
# exp_enable_buffering_full_search_in_gals has default value.
## Tcl commands to replicate state of the exp_enable_clock_padding_for_opt_design property.
# exp_enable_clock_padding_for_opt_design has default value.
## Tcl commands to replicate state of the exp_enable_clustering_cong_repair_call_in_lightweight_cts property.
# exp_enable_clustering_cong_repair_call_in_lightweight_cts has default value.
## Tcl commands to replicate state of the exp_enable_clustering_multithreaded property.
# exp_enable_clustering_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_cmu_caching property.
# exp_enable_cmu_caching has default value.
## Tcl commands to replicate state of the exp_enable_copy_activity_checking property.
# exp_enable_copy_activity_checking has default value.
## Tcl commands to replicate state of the exp_enable_cts_runtime_report property.
# exp_enable_cts_runtime_report has default value.
## Tcl commands to replicate state of the exp_enable_debug_for_find_legal_location_fails property.
# exp_enable_debug_for_find_legal_location_fails has default value.
## Tcl commands to replicate state of the exp_enable_extract_rc_no_route_check property.
# exp_enable_extract_rc_no_route_check has default value.
## Tcl commands to replicate state of the exp_enable_globalupdate_multithreaded property.
# exp_enable_globalupdate_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_mode_accessor_cache property.
# exp_enable_mode_accessor_cache has default value.
## Tcl commands to replicate state of the exp_enable_movegate_multithreaded property.
# exp_enable_movegate_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_movegates_multithreaded property.
# exp_enable_movegates_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_movement_report_for_cong_repair_during_final_implementation property.
# exp_enable_movement_report_for_cong_repair_during_final_implementation has default value.
## Tcl commands to replicate state of the exp_enable_new_method_for_auto_slew_target property.
# exp_enable_new_method_for_auto_slew_target has default value.
## Tcl commands to replicate state of the exp_enable_nsigma_delay_calculation property.
# exp_enable_nsigma_delay_calculation has default value.
## Tcl commands to replicate state of the exp_enable_nsigma_transition_model property.
# exp_enable_nsigma_transition_model has default value.
## Tcl commands to replicate state of the exp_enable_overlay_partitioning_for_high_fanout_nets property.
# exp_enable_overlay_partitioning_for_high_fanout_nets has default value.
## Tcl commands to replicate state of the exp_enable_pathoptimization_multithreaded property.
# exp_enable_pathoptimization_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_post_clustering_cong_repair_flow property.
# exp_enable_post_clustering_cong_repair_flow has default value.
## Tcl commands to replicate state of the exp_enable_post_clustering_cong_repair_flow_in_ecf property.
# exp_enable_post_clustering_cong_repair_flow_in_ecf has default value.
## Tcl commands to replicate state of the exp_enable_post_egrpc_stats property.
# exp_enable_post_egrpc_stats has default value.
## Tcl commands to replicate state of the exp_enable_prim_dijkstra_mst property.
# exp_enable_prim_dijkstra_mst has default value.
## Tcl commands to replicate state of the exp_enable_pro_multithreaded property.
# exp_enable_pro_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_resizegate_multithreaded property.
# exp_enable_resizegate_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_resizegates_multithreaded property.
# exp_enable_resizegates_multithreaded has default value.
## Tcl commands to replicate state of the exp_enable_sink_extract_clock_gate_as_logic property.
# exp_enable_sink_extract_clock_gate_as_logic has default value.
## Tcl commands to replicate state of the exp_enable_stage_delay_model_internal_arc_support property.
# exp_enable_stage_delay_model_internal_arc_support has default value.
## Tcl commands to replicate state of the exp_enable_stage_delay_virtual_delay_lookup_fix property.
# exp_enable_stage_delay_virtual_delay_lookup_fix has default value.
## Tcl commands to replicate state of the exp_enable_trans_density_report_in_dag_stats property.
# exp_enable_trans_density_report_in_dag_stats has default value.
## Tcl commands to replicate state of the exp_enable_weighted_slacks property.
# exp_enable_weighted_slacks has default value.
## Tcl commands to replicate state of the exp_enable_wire_cap_reduction_multithreaded property.
# exp_enable_wire_cap_reduction_multithreaded has default value.
## Tcl commands to replicate state of the exp_ensure_clock_tree_is_fixed_during_cong_repair property.
# exp_ensure_clock_tree_is_fixed_during_cong_repair has default value.
## Tcl commands to replicate state of the exp_ensure_net_for_all_clone_pins property.
# exp_ensure_net_for_all_clone_pins has default value.
## Tcl commands to replicate state of the exp_ensure_rcdb_access_before_clustering property.
# exp_ensure_rcdb_access_before_clustering has default value.
## Tcl commands to replicate state of the exp_escape_pin_over_pref_layer property.
# exp_escape_pin_over_pref_layer has default value.
## Tcl commands to replicate state of the exp_exclude_fixed_cells_from_placeable_region_calculation property.
# exp_exclude_fixed_cells_from_placeable_region_calculation has default value.
## Tcl commands to replicate state of the exp_expand_regions_override property.
# exp_expand_regions_override has default value for all objects.
## Tcl commands to replicate state of the exp_extract_implicit_stop_pin_at_trigger_arc property.
# exp_extract_implicit_stop_pin_at_trigger_arc has default value.
## Tcl commands to replicate state of the exp_extract_multi_corner_pin_insertion_delays property.
# exp_extract_multi_corner_pin_insertion_delays has default value.
## Tcl commands to replicate state of the exp_extract_power_contexts_is_preroute_speedup property.
# exp_extract_power_contexts_is_preroute_speedup has default value.
## Tcl commands to replicate state of the exp_extract_sort_clock_definition_objects property.
# exp_extract_sort_clock_definition_objects has default value.
## Tcl commands to replicate state of the exp_extract_stop_no_sdc_clock_pin_insertion_delays property.
# exp_extract_stop_no_sdc_clock_pin_insertion_delays has default value.
## Tcl commands to replicate state of the exp_faster_hinst_look_up_for_power_domain property.
# exp_faster_hinst_look_up_for_power_domain has default value.
## Tcl commands to replicate state of the exp_faster_route_place_option property.
# exp_faster_route_place_option has default value.
## Tcl commands to replicate state of the exp_faster_run_time_in_recalculate_offsets property.
# exp_faster_run_time_in_recalculate_offsets has default value.
## Tcl commands to replicate state of the exp_faster_run_time_in_timing property.
# exp_faster_run_time_in_timing has default value.
## Tcl commands to replicate state of the exp_faster_run_time_in_timing_until_clustering property.
# exp_faster_run_time_in_timing_until_clustering has default value.
## Tcl commands to replicate state of the exp_filter_cell_lists_for_legality property.
# exp_filter_cell_lists_for_legality has default value.
## Tcl commands to replicate state of the exp_filter_refine_place_fails property.
# exp_filter_refine_place_fails has default value.
## Tcl commands to replicate state of the exp_find_legal_location_length_threshold_in_module_search property.
# exp_find_legal_location_length_threshold_in_module_search has default value.
## Tcl commands to replicate state of the exp_fine_balance_resize_iteration_limit_threshold property.
# exp_fine_balance_resize_iteration_limit_threshold has default value.
## Tcl commands to replicate state of the exp_fix_ccr_2064583 property.
# exp_fix_ccr_2064583 has default value.
## Tcl commands to replicate state of the exp_fix_early_global_pin_connection_fix property.
# exp_fix_early_global_pin_connection_fix has default value.
## Tcl commands to replicate state of the exp_flexible_htree_adjust_gcell_size_to_ndr property.
# exp_flexible_htree_adjust_gcell_size_to_ndr has default value.
## Tcl commands to replicate state of the exp_flexible_htree_advanced_matching property.
# exp_flexible_htree_advanced_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_advanced_matching_fixes property.
# exp_flexible_htree_advanced_matching_fixes has default value.
## Tcl commands to replicate state of the exp_flexible_htree_allow_sink_grid_center_expansion property.
# exp_flexible_htree_allow_sink_grid_center_expansion has default value.
## Tcl commands to replicate state of the exp_flexible_htree_allow_symmetry_branches property.
# exp_flexible_htree_allow_symmetry_branches has default value.
## Tcl commands to replicate state of the exp_flexible_htree_avoid_overflow property.
# exp_flexible_htree_avoid_overflow has default value.
## Tcl commands to replicate state of the exp_flexible_htree_avoid_self_intersections property.
# exp_flexible_htree_avoid_self_intersections has default value.
## Tcl commands to replicate state of the exp_flexible_htree_beam_width property.
# exp_flexible_htree_beam_width has default value.
## Tcl commands to replicate state of the exp_flexible_htree_beam_width_narrow property.
# exp_flexible_htree_beam_width_narrow has default value.
## Tcl commands to replicate state of the exp_flexible_htree_best_effort_placement_expansion property.
# exp_flexible_htree_best_effort_placement_expansion has default value.
## Tcl commands to replicate state of the exp_flexible_htree_best_path_length_margin property.
# exp_flexible_htree_best_path_length_margin has default value.
## Tcl commands to replicate state of the exp_flexible_htree_blocked_driver_cost property.
# exp_flexible_htree_blocked_driver_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_branch_point_inst_displace_row_height_multiplier property.
# exp_flexible_htree_branch_point_inst_displace_row_height_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_branch_point_inst_displace_row_height_multiplier_improvements_for_matching property.
# exp_flexible_htree_branch_point_inst_displace_row_height_multiplier_improvements_for_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_bufferable_violation_cost property.
# exp_flexible_htree_bufferable_violation_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_cluster_band_multiplier property.
# exp_flexible_htree_cluster_band_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_cluster_band_row_height_multiplier property.
# exp_flexible_htree_cluster_band_row_height_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_cluster_band_row_height_multiplier_for_matching property.
# exp_flexible_htree_cluster_band_row_height_multiplier_for_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_cluster_tolerance_factor property.
# exp_flexible_htree_cluster_tolerance_factor has default value.
## Tcl commands to replicate state of the exp_flexible_htree_consider_blocked_strip_nets property.
# exp_flexible_htree_consider_blocked_strip_nets has default value.
## Tcl commands to replicate state of the exp_flexible_htree_consider_stacked_vias_for_sink_output_pins property.
# exp_flexible_htree_consider_stacked_vias_for_sink_output_pins has default value.
## Tcl commands to replicate state of the exp_flexible_htree_debug_solution_id property.
# exp_flexible_htree_debug_solution_id has default value.
## Tcl commands to replicate state of the exp_flexible_htree_default_version property.
# exp_flexible_htree_default_version has default value.
## Tcl commands to replicate state of the exp_flexible_htree_disable_eeq_cell_swapping_in_legalizer property.
# exp_flexible_htree_disable_eeq_cell_swapping_in_legalizer has default value.
## Tcl commands to replicate state of the exp_flexible_htree_dist_tolerance_factor property.
# exp_flexible_htree_dist_tolerance_factor has default value.
## Tcl commands to replicate state of the exp_flexible_htree_diversity_interval property.
# exp_flexible_htree_diversity_interval has default value.
## Tcl commands to replicate state of the exp_flexible_htree_driven_fold_back_cost property.
# exp_flexible_htree_driven_fold_back_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_driver_asymmetry_cost property.
# exp_flexible_htree_driver_asymmetry_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_driver_cost_in_microns property.
# exp_flexible_htree_driver_cost_in_microns has default value.
## Tcl commands to replicate state of the exp_flexible_htree_driver_level_path_splitting property.
# exp_flexible_htree_driver_level_path_splitting has default value.
## Tcl commands to replicate state of the exp_flexible_htree_driver_levels_increase_cost property.
# exp_flexible_htree_driver_levels_increase_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_drv_cost property.
# exp_flexible_htree_drv_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_enable_improvements_for_matching property.
# exp_flexible_htree_enable_improvements_for_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_enable_local_search property.
# exp_flexible_htree_enable_local_search has default value.
## Tcl commands to replicate state of the exp_flexible_htree_enable_shield_sharing property.
# exp_flexible_htree_enable_shield_sharing has default value.
## Tcl commands to replicate state of the exp_flexible_htree_enable_special_modeling property.
# exp_flexible_htree_enable_special_modeling has default value.
## Tcl commands to replicate state of the exp_flexible_htree_enable_timing_driven_htree_routing property.
# exp_flexible_htree_enable_timing_driven_htree_routing has default value.
## Tcl commands to replicate state of the exp_flexible_htree_extend_route_guides_to_drivers property.
# exp_flexible_htree_extend_route_guides_to_drivers has default value.
## Tcl commands to replicate state of the exp_flexible_htree_fanout_dependent_driver_distances property.
# exp_flexible_htree_fanout_dependent_driver_distances has default value.
## Tcl commands to replicate state of the exp_flexible_htree_fold_back_cost property.
# exp_flexible_htree_fold_back_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_global_search_iteration_limit_per_step property.
# exp_flexible_htree_global_search_iteration_limit_per_step has default value.
## Tcl commands to replicate state of the exp_flexible_htree_global_search_iterations_per_step_high property.
# exp_flexible_htree_global_search_iterations_per_step_high has default value.
## Tcl commands to replicate state of the exp_flexible_htree_global_search_iterations_per_step_low property.
# exp_flexible_htree_global_search_iterations_per_step_low has default value.
## Tcl commands to replicate state of the exp_flexible_htree_global_search_iterations_per_step_medium property.
# exp_flexible_htree_global_search_iterations_per_step_medium has default value.
## Tcl commands to replicate state of the exp_flexible_htree_grid_coarsening_factor property.
# exp_flexible_htree_grid_coarsening_factor has default value.
## Tcl commands to replicate state of the exp_flexible_htree_grid_detour_factor property.
# exp_flexible_htree_grid_detour_factor has default value.
## Tcl commands to replicate state of the exp_flexible_htree_grid_halo_expansion_multiplier property.
# exp_flexible_htree_grid_halo_expansion_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_halo_violation_cost property.
# exp_flexible_htree_halo_violation_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_hierarchical_track_assignment property.
# exp_flexible_htree_hierarchical_track_assignment has default value.
## Tcl commands to replicate state of the exp_flexible_htree_honor_parallel_run_length_spacing property.
# exp_flexible_htree_honor_parallel_run_length_spacing has default value.
## Tcl commands to replicate state of the exp_flexible_htree_hv_balancing_improvements property.
# exp_flexible_htree_hv_balancing_improvements has default value.
## Tcl commands to replicate state of the exp_flexible_htree_ideal_driver_dist_excess_cost property.
# exp_flexible_htree_ideal_driver_dist_excess_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_large_cell_threshold_in_rows property.
# exp_flexible_htree_large_cell_threshold_in_rows has default value.
## Tcl commands to replicate state of the exp_flexible_htree_layer_demote_distance property.
# exp_flexible_htree_layer_demote_distance has default value for all objects.
## Tcl commands to replicate state of the exp_flexible_htree_local_search_iterations_per_step_high property.
# exp_flexible_htree_local_search_iterations_per_step_high has default value.
## Tcl commands to replicate state of the exp_flexible_htree_local_search_iterations_per_step_low property.
# exp_flexible_htree_local_search_iterations_per_step_low has default value.
## Tcl commands to replicate state of the exp_flexible_htree_local_search_iterations_per_step_medium property.
# exp_flexible_htree_local_search_iterations_per_step_medium has default value.
## Tcl commands to replicate state of the exp_flexible_htree_lower_layer_blocked_cost property.
# exp_flexible_htree_lower_layer_blocked_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_max_cluster_band_expansions property.
# exp_flexible_htree_max_cluster_band_expansions has default value.
## Tcl commands to replicate state of the exp_flexible_htree_max_source_sink_increase property.
# exp_flexible_htree_max_source_sink_increase has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_cost_percentile property.
# exp_flexible_htree_merge_cost_percentile has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_orientation_tolerance property.
# exp_flexible_htree_merge_orientation_tolerance has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_base_length_fraction property.
# exp_flexible_htree_merge_point_base_length_fraction has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_driver_level_excess_cost property.
# exp_flexible_htree_merge_point_driver_level_excess_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_length_imbalance_cost property.
# exp_flexible_htree_merge_point_length_imbalance_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_length_mismatch_cost property.
# exp_flexible_htree_merge_point_length_mismatch_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_length_mismatch_cost_for_matching property.
# exp_flexible_htree_merge_point_length_mismatch_cost_for_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_length_penalty_cost property.
# exp_flexible_htree_merge_point_length_penalty_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_max_candidates property.
# exp_flexible_htree_merge_point_max_candidates has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_overflow_cost property.
# exp_flexible_htree_merge_point_overflow_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_target_displacement_cost property.
# exp_flexible_htree_merge_point_target_displacement_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_tolerance property.
# exp_flexible_htree_merge_point_tolerance has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_tolerance_for_matching property.
# exp_flexible_htree_merge_point_tolerance_for_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_turn_cost property.
# exp_flexible_htree_merge_point_turn_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_turn_cost_for_matching property.
# exp_flexible_htree_merge_point_turn_cost_for_matching has default value.
## Tcl commands to replicate state of the exp_flexible_htree_merge_point_twist_cost property.
# exp_flexible_htree_merge_point_twist_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_min_ideal_driver_dist_multiplier property.
# exp_flexible_htree_min_ideal_driver_dist_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_min_run_length_increase property.
# exp_flexible_htree_min_run_length_increase has default value.
## Tcl commands to replicate state of the exp_flexible_htree_min_split_level_violation_cost property.
# exp_flexible_htree_min_split_level_violation_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_minimum_symmetry_branch_row_height_multiplier property.
# exp_flexible_htree_minimum_symmetry_branch_row_height_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_model_ndr_on_blockages property.
# exp_flexible_htree_model_ndr_on_blockages has default value.
## Tcl commands to replicate state of the exp_flexible_htree_move_source property.
# exp_flexible_htree_move_source has default value.
## Tcl commands to replicate state of the exp_flexible_htree_no_cluster_band_min_tree_levels property.
# exp_flexible_htree_no_cluster_band_min_tree_levels has default value.
## Tcl commands to replicate state of the exp_flexible_htree_non_min_length_cost property.
# exp_flexible_htree_non_min_length_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_num_quantized_slews property.
# exp_flexible_htree_num_quantized_slews has default value.
## Tcl commands to replicate state of the exp_flexible_htree_overflow_cost property.
# exp_flexible_htree_overflow_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_pad_htree_insts property.
# exp_flexible_htree_pad_htree_insts has default value.
## Tcl commands to replicate state of the exp_flexible_htree_partition_boundary_net_length_excess_cost property.
# exp_flexible_htree_partition_boundary_net_length_excess_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_placement_region_check property.
# exp_flexible_htree_placement_region_check has default value.
## Tcl commands to replicate state of the exp_flexible_htree_preferred_rectangle_center_factor property.
# exp_flexible_htree_preferred_rectangle_center_factor has default value.
## Tcl commands to replicate state of the exp_flexible_htree_preferred_routing_layer_effort property.
# exp_flexible_htree_preferred_routing_layer_effort has default value.
## Tcl commands to replicate state of the exp_flexible_htree_routing_estimate_use_new_steiner_package property.
# exp_flexible_htree_routing_estimate_use_new_steiner_package has default value.
## Tcl commands to replicate state of the exp_flexible_htree_self_intersection_cost property.
# exp_flexible_htree_self_intersection_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_simple_route_guides property.
# exp_flexible_htree_simple_route_guides has default value.
## Tcl commands to replicate state of the exp_flexible_htree_sink_expansion property.
# exp_flexible_htree_sink_expansion has default value.
## Tcl commands to replicate state of the exp_flexible_htree_sink_expansion_row_height_multiplier property.
# exp_flexible_htree_sink_expansion_row_height_multiplier has default value.
## Tcl commands to replicate state of the exp_flexible_htree_small_gcell_directional_ratio_threshold property.
# exp_flexible_htree_small_gcell_directional_ratio_threshold has default value.
## Tcl commands to replicate state of the exp_flexible_htree_split_asymmetry_cost property.
# exp_flexible_htree_split_asymmetry_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_straighten_routes property.
# exp_flexible_htree_straighten_routes has default value.
## Tcl commands to replicate state of the exp_flexible_htree_strip_net_width_threshold property.
# exp_flexible_htree_strip_net_width_threshold has default value.
## Tcl commands to replicate state of the exp_flexible_htree_symmetry_branches_may_cross_partition_boundaries property.
# exp_flexible_htree_symmetry_branches_may_cross_partition_boundaries has default value.
## Tcl commands to replicate state of the exp_flexible_htree_target_length_percentile property.
# exp_flexible_htree_target_length_percentile has default value.
## Tcl commands to replicate state of the exp_flexible_htree_track_merge_cost_of_node_id property.
# exp_flexible_htree_track_merge_cost_of_node_id has default value.
## Tcl commands to replicate state of the exp_flexible_htree_track_propagation_of_node_id property.
# exp_flexible_htree_track_propagation_of_node_id has default value.
## Tcl commands to replicate state of the exp_flexible_htree_turn_weight property.
# exp_flexible_htree_turn_weight has default value.
## Tcl commands to replicate state of the exp_flexible_htree_two_level_legalization property.
# exp_flexible_htree_two_level_legalization has default value.
## Tcl commands to replicate state of the exp_flexible_htree_unblocked_tracks property.
# exp_flexible_htree_unblocked_tracks has default value.
## Tcl commands to replicate state of the exp_flexible_htree_use_high_frequency_router property.
# exp_flexible_htree_use_high_frequency_router has default value.
## Tcl commands to replicate state of the exp_flexible_htree_use_refine_place property.
# exp_flexible_htree_use_refine_place has default value.
## Tcl commands to replicate state of the exp_flexible_htree_wire_asymmetry_cost property.
# exp_flexible_htree_wire_asymmetry_cost has default value.
## Tcl commands to replicate state of the exp_flexible_htree_wire_length_weight property.
# exp_flexible_htree_wire_length_weight has default value.
## Tcl commands to replicate state of the exp_force_cluster_only_legalize_clock_trees property.
# exp_force_cluster_only_legalize_clock_trees has default value.
## Tcl commands to replicate state of the exp_gals_buffering_fast_mode property.
# exp_gals_buffering_fast_mode has default value.
## Tcl commands to replicate state of the exp_halo_warning_threshold_in_um property.
# exp_halo_warning_threshold_in_um has default value.
## Tcl commands to replicate state of the exp_heco_continue_on_preserved_module_boundaries property.
# exp_heco_continue_on_preserved_module_boundaries has default value.
## Tcl commands to replicate state of the exp_high_priority_assignment_in_clustering_refine_place property.
# exp_high_priority_assignment_in_clustering_refine_place has default value.
## Tcl commands to replicate state of the exp_hnet_dont_touch_implies_hterm_dont_touch property.
# exp_hnet_dont_touch_implies_hterm_dont_touch has default value.
## Tcl commands to replicate state of the exp_hnet_dont_touch_implies_inst_dont_touch property.
# exp_hnet_dont_touch_implies_inst_dont_touch has default value.
## Tcl commands to replicate state of the exp_honor_upf_hnet_isolation_constraints property.
# exp_honor_upf_hnet_isolation_constraints has default value.
## Tcl commands to replicate state of the exp_honor_upf_hterm_constraints property.
# exp_honor_upf_hterm_constraints has default value.
## Tcl commands to replicate state of the exp_icg_depth_hpwl_reporting property.
# exp_icg_depth_hpwl_reporting has default value.
## Tcl commands to replicate state of the exp_ictr_high_effort_preserve_band_with_timing_windows property.
# exp_ictr_high_effort_preserve_band_with_timing_windows has default value.
## Tcl commands to replicate state of the exp_ictr_in_polishing_decrease_wire_cap_preserve_route_lengths property.
# exp_ictr_in_polishing_decrease_wire_cap_preserve_route_lengths has default value.
## Tcl commands to replicate state of the exp_ictr_in_polishing_movegates_multithreaded property.
# exp_ictr_in_polishing_movegates_multithreaded has default value.
## Tcl commands to replicate state of the exp_ictr_in_polishing_wire_cap_reduction_multithreaded property.
# exp_ictr_in_polishing_wire_cap_reduction_multithreaded has default value.
## Tcl commands to replicate state of the exp_id_safe_downsizing_driver_resizing_fix property.
# exp_id_safe_downsizing_driver_resizing_fix has default value.
## Tcl commands to replicate state of the exp_ideal_net_fanout_threshold property.
# exp_ideal_net_fanout_threshold has default value.
## Tcl commands to replicate state of the exp_ilm_type_honors_si_aware property.
# exp_ilm_type_honors_si_aware has default value.
## Tcl commands to replicate state of the exp_improved_capacitance_override_handling property.
# exp_improved_capacitance_override_handling has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_high_effort_preserve_band property.
# exp_improving_clock_tree_routing_high_effort_preserve_band has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_high_effort_preserve_band_per_iter property.
# exp_improving_clock_tree_routing_high_effort_preserve_band_per_iter has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_high_effort_preserve_band_safely property.
# exp_improving_clock_tree_routing_high_effort_preserve_band_safely has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_high_effort_skew_margin_multiplier property.
# exp_improving_clock_tree_routing_high_effort_skew_margin_multiplier has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_high_effort_slew_margin_multiplier property.
# exp_improving_clock_tree_routing_high_effort_slew_margin_multiplier has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_in_polishing_method property.
# exp_improving_clock_tree_routing_in_polishing_method has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_in_polishing_use_rctp4_recipe property.
# exp_improving_clock_tree_routing_in_polishing_use_rctp4_recipe has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_skew_safety property.
# exp_improving_clock_tree_routing_skew_safety has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_target_power property.
# exp_improving_clock_tree_routing_target_power has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_use_routing_move_multi_input_cells property.
# exp_improving_clock_tree_routing_use_routing_move_multi_input_cells has default value.
## Tcl commands to replicate state of the exp_improving_clock_tree_routing_use_routing_use_pin_locations property.
# exp_improving_clock_tree_routing_use_routing_use_pin_locations has default value.
## Tcl commands to replicate state of the exp_include_power_ground_nets_in_compute_touches_pre_route property.
# exp_include_power_ground_nets_in_compute_touches_pre_route has default value.
## Tcl commands to replicate state of the exp_increase_accuracy_of_approximate_delay_calc_in_sizing property.
# exp_increase_accuracy_of_approximate_delay_calc_in_sizing has default value.
## Tcl commands to replicate state of the exp_inverting_clock_gate_skip_pos_edge_checking property.
# exp_inverting_clock_gate_skip_pos_edge_checking has default value.
## Tcl commands to replicate state of the exp_large_cell_threshold_in_rows property.
# exp_large_cell_threshold_in_rows has default value.
## Tcl commands to replicate state of the exp_library_trimming_consider_power_domain_half_corner property.
# exp_library_trimming_consider_power_domain_half_corner has default value.
## Tcl commands to replicate state of the exp_limit_over_slew_invalidation_for_ideal_nets property.
# exp_limit_over_slew_invalidation_for_ideal_nets has default value.
## Tcl commands to replicate state of the exp_limit_stage_delay_invalidation_for_high_fanout_nets property.
# exp_limit_stage_delay_invalidation_for_high_fanout_nets has default value.
## Tcl commands to replicate state of the exp_limit_stage_delay_invalidation_for_ideal_nets property.
# exp_limit_stage_delay_invalidation_for_ideal_nets has default value.
## Tcl commands to replicate state of the exp_local_wire_reclaim_after_cts property.
# exp_local_wire_reclaim_after_cts has default value.
## Tcl commands to replicate state of the exp_logic_movement_limit_um property.
# exp_logic_movement_limit_um has default value.
## Tcl commands to replicate state of the exp_long_path_removal_consider_longest_and_shortest property.
# exp_long_path_removal_consider_longest_and_shortest has default value.
## Tcl commands to replicate state of the exp_long_path_removal_remove_skew_band_safely property.
set_ccopt_property exp_long_path_removal_remove_skew_band_safely 0
## Tcl commands to replicate state of the exp_long_path_removal_round_offsets property.
# exp_long_path_removal_round_offsets has default value.
## Tcl commands to replicate state of the exp_manage_antenna_diodes property.
# exp_manage_antenna_diodes has default value.
## Tcl commands to replicate state of the exp_mark_clock_sinks_on_grid_after_clustering property.
# exp_mark_clock_sinks_on_grid_after_clustering has default value.
## Tcl commands to replicate state of the exp_mark_only_unfixable_slews_caused_by_design_constraints property.
# exp_mark_only_unfixable_slews_caused_by_design_constraints has default value.
## Tcl commands to replicate state of the exp_max_ictr_passes_for_ictr_passes_then_move_gates_method property.
# exp_max_ictr_passes_for_ictr_passes_then_move_gates_method has default value.
## Tcl commands to replicate state of the exp_max_search_window_size_in_row_heights property.
# exp_max_search_window_size_in_row_heights has default value.
## Tcl commands to replicate state of the exp_max_stage_delay_queue_size_for_incremental_update property.
# exp_max_stage_delay_queue_size_for_incremental_update has default value.
## Tcl commands to replicate state of the exp_maximize_abstraction_clear_shield_wires property.
# exp_maximize_abstraction_clear_shield_wires has default value.
## Tcl commands to replicate state of the exp_maximum_number_of_high_fanout_net_overlay_partitions property.
# exp_maximum_number_of_high_fanout_net_overlay_partitions has default value.
## Tcl commands to replicate state of the exp_merge_balancing_drivers_for_power_check_skew_latency property.
# exp_merge_balancing_drivers_for_power_check_skew_latency has default value.
## Tcl commands to replicate state of the exp_merging_consider_constant_enables property.
# exp_merging_consider_constant_enables has default value.
## Tcl commands to replicate state of the exp_move_gate_do_diagonal_diamond_moves property.
# exp_move_gate_do_diagonal_diamond_moves has default value.
## Tcl commands to replicate state of the exp_move_gate_do_tiny_horizontal_moves property.
# exp_move_gate_do_tiny_horizontal_moves has default value.
## Tcl commands to replicate state of the exp_move_gate_prune_mode property.
# exp_move_gate_prune_mode has default value.
## Tcl commands to replicate state of the exp_move_gate_single_move_per_unit_distance property.
# exp_move_gate_single_move_per_unit_distance has default value.
## Tcl commands to replicate state of the exp_move_gate_skip_post_move_verification property.
# exp_move_gate_skip_post_move_verification has default value.
## Tcl commands to replicate state of the exp_move_gate_use_integral_row_height_multiple property.
# exp_move_gate_use_integral_row_height_multiple has default value.
## Tcl commands to replicate state of the exp_move_gate_wirelength_pruning_net_weight_type property.
# exp_move_gate_wirelength_pruning_net_weight_type has default value.
## Tcl commands to replicate state of the exp_move_gate_wl_based_pruning_threshold property.
# exp_move_gate_wl_based_pruning_threshold has default value.
## Tcl commands to replicate state of the exp_move_gate_wl_pruning_use_pin_locations_for_hpwl_calculation property.
# exp_move_gate_wl_pruning_use_pin_locations_for_hpwl_calculation has default value.
## Tcl commands to replicate state of the exp_move_gates_to_siblings_move_distance_factor property.
# exp_move_gates_to_siblings_move_distance_factor has default value.
## Tcl commands to replicate state of the exp_movement_limit_um property.
# exp_movement_limit_um has default value for all objects.
## Tcl commands to replicate state of the exp_moving_gates_to_reduce_subtree_wire_skew_optimize_with_routeopt property.
# exp_moving_gates_to_reduce_subtree_wire_skew_optimize_with_routeopt has default value.
## Tcl commands to replicate state of the exp_moving_gates_to_reduce_subtree_wire_skew_penalty_scale_factor property.
# exp_moving_gates_to_reduce_subtree_wire_skew_penalty_scale_factor has default value.
## Tcl commands to replicate state of the exp_mt_compute_placeable_area property.
# exp_mt_compute_placeable_area has default value.
## Tcl commands to replicate state of the exp_multi_corner_approx_balance property.
# exp_multi_corner_approx_balance has default value.
## Tcl commands to replicate state of the exp_multi_tap_clone_power_domain_boundary_cells property.
# exp_multi_tap_clone_power_domain_boundary_cells has default value.
## Tcl commands to replicate state of the exp_multi_tap_clone_power_management_cells property.
# exp_multi_tap_clone_power_management_cells has default value.
## Tcl commands to replicate state of the exp_multicorner_slews_in_approximate_delay_calc_in_sizing property.
# exp_multicorner_slews_in_approximate_delay_calc_in_sizing has default value.
## Tcl commands to replicate state of the exp_multicorner_slews_in_approximate_delay_calc_in_sizing_bottom_up_balancing property.
# exp_multicorner_slews_in_approximate_delay_calc_in_sizing_bottom_up_balancing has default value.
## Tcl commands to replicate state of the exp_multidriver_nets_are_dont_touch property.
# exp_multidriver_nets_are_dont_touch has default value.
## Tcl commands to replicate state of the exp_multitap_dangling_port_fix property.
# exp_multitap_dangling_port_fix has default value.
## Tcl commands to replicate state of the exp_netlist_batch_delete_gate property.
# exp_netlist_batch_delete_gate has default value.
## Tcl commands to replicate state of the exp_netlist_clear_shield_wires_before_heco property.
# exp_netlist_clear_shield_wires_before_heco has default value.
## Tcl commands to replicate state of the exp_nma_finder_max_arc_chains property.
# exp_nma_finder_max_arc_chains has default value.
## Tcl commands to replicate state of the exp_non_fatal_assert_upon_verify_legal_fails property.
# exp_non_fatal_assert_upon_verify_legal_fails has default value.
## Tcl commands to replicate state of the exp_optimize_activity_weighted_wire_cap_in_activity_driven_ictr property.
# exp_optimize_activity_weighted_wire_cap_in_activity_driven_ictr has default value.
## Tcl commands to replicate state of the exp_optimize_routes_in_reposition_for_skew property.
# exp_optimize_routes_in_reposition_for_skew has default value.
## Tcl commands to replicate state of the exp_original_location_and_orient property.
# exp_original_location_and_orient has default value for all objects.
## Tcl commands to replicate state of the exp_override_cloning_failure_reasons property.
# exp_override_cloning_failure_reasons has default value.
## Tcl commands to replicate state of the exp_perform_refine_place_sp_api_halo_run_time_check_for_clustering property.
# exp_perform_refine_place_sp_api_halo_run_time_check_for_clustering has default value.
## Tcl commands to replicate state of the exp_perform_refine_place_sp_api_halo_run_time_check_for_egrpc property.
# exp_perform_refine_place_sp_api_halo_run_time_check_for_egrpc has default value.
## Tcl commands to replicate state of the exp_perform_refine_place_sp_api_halo_run_time_check_for_implementation property.
# exp_perform_refine_place_sp_api_halo_run_time_check_for_implementation has default value.
## Tcl commands to replicate state of the exp_perform_refine_place_sp_api_halo_run_time_check_for_post_conditioning property.
# exp_perform_refine_place_sp_api_halo_run_time_check_for_post_conditioning has default value.
## Tcl commands to replicate state of the exp_permit_non_fterm_equiv_eeq_swaps_in_cong_repair property.
# exp_permit_non_fterm_equiv_eeq_swaps_in_cong_repair has default value.
## Tcl commands to replicate state of the exp_pin_insertion_delay_target_skew_bias_factor property.
# exp_pin_insertion_delay_target_skew_bias_factor has default value.
## Tcl commands to replicate state of the exp_pin_insertion_delay_target_skew_offset_factor property.
# exp_pin_insertion_delay_target_skew_offset_factor has default value.
## Tcl commands to replicate state of the exp_pin_insertion_delay_target_skew_rescale_in_fragment_mode property.
# exp_pin_insertion_delay_target_skew_rescale_in_fragment_mode has default value.
## Tcl commands to replicate state of the exp_pin_insertion_delay_target_skew_scaling_enabled property.
# exp_pin_insertion_delay_target_skew_scaling_enabled has default value.
## Tcl commands to replicate state of the exp_pin_insertion_delay_target_skew_scaling_factor property.
# exp_pin_insertion_delay_target_skew_scaling_factor has default value.
## Tcl commands to replicate state of the exp_pin_route_type_propagate_through_single_clock_input_instances property.
# exp_pin_route_type_propagate_through_single_clock_input_instances has default value.
## Tcl commands to replicate state of the exp_place_allow_clock_cells_in_soft_blockages property.
# exp_place_allow_clock_cells_in_soft_blockages has default value.
## Tcl commands to replicate state of the exp_place_disable_eeq_cell_swapping_in_legalizer property.
# exp_place_disable_eeq_cell_swapping_in_legalizer has default value.
## Tcl commands to replicate state of the exp_place_do_repeated_merging property.
# exp_place_do_repeated_merging has default value.
## Tcl commands to replicate state of the exp_place_effective_width_percentile property.
# exp_place_effective_width_percentile has default value.
## Tcl commands to replicate state of the exp_place_enable_sp_mode_reset_fix property.
# exp_place_enable_sp_mode_reset_fix has default value.
## Tcl commands to replicate state of the exp_place_filter_fixed_cell_fix property.
# exp_place_filter_fixed_cell_fix has default value.
## Tcl commands to replicate state of the exp_place_ignore_fixed_bin_density property.
# exp_place_ignore_fixed_bin_density has default value.
## Tcl commands to replicate state of the exp_place_legal_effort property.
# exp_place_legal_effort has default value.
## Tcl commands to replicate state of the exp_place_legalizer_use_orients_for_flexible_htree property.
# exp_place_legalizer_use_orients_for_flexible_htree has default value.
## Tcl commands to replicate state of the exp_place_max_cell_height_by_row property.
# exp_place_max_cell_height_by_row has default value.
## Tcl commands to replicate state of the exp_place_max_merging_passes property.
# exp_place_max_merging_passes has default value.
## Tcl commands to replicate state of the exp_place_merge_bbox_fix property.
# exp_place_merge_bbox_fix has default value.
## Tcl commands to replicate state of the exp_place_narrow_channel_threshold property.
# exp_place_narrow_channel_threshold has default value.
## Tcl commands to replicate state of the exp_place_nested_fence_fix property.
# exp_place_nested_fence_fix has default value.
## Tcl commands to replicate state of the exp_place_new_legal_api_uses_all_effort_level property.
# exp_place_new_legal_api_uses_all_effort_level has default value.
## Tcl commands to replicate state of the exp_place_num_fixed_inst_as_blk property.
# exp_place_num_fixed_inst_as_blk has default value.
## Tcl commands to replicate state of the exp_place_placeable_region_check_legality property.
# exp_place_placeable_region_check_legality has default value.
## Tcl commands to replicate state of the exp_place_psp_use_cell_bloat_suspender property.
# exp_place_psp_use_cell_bloat_suspender has default value.
## Tcl commands to replicate state of the exp_place_psp_verbose property.
# exp_place_psp_verbose has default value.
## Tcl commands to replicate state of the exp_place_query_region_by_rtree property.
# exp_place_query_region_by_rtree has default value.
## Tcl commands to replicate state of the exp_place_reactivate_always_init_psp property.
# exp_place_reactivate_always_init_psp has default value.
## Tcl commands to replicate state of the exp_place_search_window_consider_cell_width property.
# exp_place_search_window_consider_cell_width has default value.
## Tcl commands to replicate state of the exp_place_small_search_window_by_row property.
# exp_place_small_search_window_by_row has default value.
## Tcl commands to replicate state of the exp_place_support_non_default_site property.
# exp_place_support_non_default_site has default value.
## Tcl commands to replicate state of the exp_place_two_pass_refine_place_handle_softfix property.
# exp_place_two_pass_refine_place_handle_softfix has default value.
## Tcl commands to replicate state of the exp_place_use_encloses_consider_db_snapping_for_nested_fences property.
# exp_place_use_encloses_consider_db_snapping_for_nested_fences has default value.
## Tcl commands to replicate state of the exp_place_use_pd_bbox_if_hinst_is_not_fence property.
# exp_place_use_pd_bbox_if_hinst_is_not_fence has default value.
## Tcl commands to replicate state of the exp_placeable_region_large_cell_threshold_in_rows property.
# exp_placeable_region_large_cell_threshold_in_rows has default value.
## Tcl commands to replicate state of the exp_position_logics_near_multitap_parents property.
# exp_position_logics_near_multitap_parents has default value.
## Tcl commands to replicate state of the exp_post_conditioning_block_out_space_for_clock_sinks property.
# exp_post_conditioning_block_out_space_for_clock_sinks has default value.
## Tcl commands to replicate state of the exp_post_conditioning_enable_dag_stats_for_longest_path_removal property.
# exp_post_conditioning_enable_dag_stats_for_longest_path_removal has default value.
## Tcl commands to replicate state of the exp_post_conditioning_enable_final_dag_stats property.
# exp_post_conditioning_enable_final_dag_stats has default value.
## Tcl commands to replicate state of the exp_post_conditioning_enable_final_extract property.
# exp_post_conditioning_enable_final_extract has default value.
## Tcl commands to replicate state of the exp_post_conditioning_enable_full_search_route_buffering property.
# exp_post_conditioning_enable_full_search_route_buffering has default value.
## Tcl commands to replicate state of the exp_post_conditioning_refine_place_fixes_routes property.
# exp_post_conditioning_refine_place_fixes_routes has default value.
## Tcl commands to replicate state of the exp_post_conditioning_refine_place_soft_fix_clock_sinks property.
# exp_post_conditioning_refine_place_soft_fix_clock_sinks has default value.
## Tcl commands to replicate state of the exp_post_conditioning_skewfix_upsize_one_step_only property.
# exp_post_conditioning_skewfix_upsize_one_step_only has default value.
## Tcl commands to replicate state of the exp_postpone_ilm_antenna_handling_to_flattening property.
# exp_postpone_ilm_antenna_handling_to_flattening has default value.
## Tcl commands to replicate state of the exp_power_analysis_max_cap_factor property.
# exp_power_analysis_max_cap_factor has default value.
## Tcl commands to replicate state of the exp_power_analysis_max_trans_factor property.
# exp_power_analysis_max_trans_factor has default value.
## Tcl commands to replicate state of the exp_power_consider_all_sink_pins_internal_power property.
# exp_power_consider_all_sink_pins_internal_power has default value.
## Tcl commands to replicate state of the exp_power_effort_activity_driven_high_aggressive property.
# exp_power_effort_activity_driven_high_aggressive has default value.
## Tcl commands to replicate state of the exp_power_opt_move_clock_gate property.
# exp_power_opt_move_clock_gate has default value.
## Tcl commands to replicate state of the exp_power_opt_resize property.
# exp_power_opt_resize has default value.
## Tcl commands to replicate state of the exp_pre_existing_driver property.
# exp_pre_existing_driver has default value for all objects.
## Tcl commands to replicate state of the exp_prebalance_check_implied_port_directions property.
# exp_prebalance_check_implied_port_directions has default value.
## Tcl commands to replicate state of the exp_prebalance_consider_inverting_icgs property.
# exp_prebalance_consider_inverting_icgs has default value.
## Tcl commands to replicate state of the exp_prebalance_consider_power_domains_in_slew_target_calculations property.
# exp_prebalance_consider_power_domains_in_slew_target_calculations has default value.
## Tcl commands to replicate state of the exp_prebalance_multi_tap_unclonable_inst_transitive_sinks_fraction property.
# exp_prebalance_multi_tap_unclonable_inst_transitive_sinks_fraction has default value.
## Tcl commands to replicate state of the exp_prebalance_too_many_dont_touch_cells_fraction property.
# exp_prebalance_too_many_dont_touch_cells_fraction has default value.
## Tcl commands to replicate state of the exp_primary_delay_corner_to_time_for_drv_in_clustering property.
# exp_primary_delay_corner_to_time_for_drv_in_clustering has default value.
## Tcl commands to replicate state of the exp_print_gate_and_wire_stats_in_dag_stats property.
# exp_print_gate_and_wire_stats_in_dag_stats has default value.
## Tcl commands to replicate state of the exp_print_gate_and_wire_stats_in_dag_stats_directory property.
# exp_print_gate_and_wire_stats_in_dag_stats_directory has default value.
## Tcl commands to replicate state of the exp_pro_block_out_space_for_clock_sinks property.
# exp_pro_block_out_space_for_clock_sinks has default value.
## Tcl commands to replicate state of the exp_pro_downsize_preserve_local_skew property.
# exp_pro_downsize_preserve_local_skew has default value.
## Tcl commands to replicate state of the exp_pro_drv_buffering_second_pass_permit_quick_buffering property.
# exp_pro_drv_buffering_second_pass_permit_quick_buffering has default value.
## Tcl commands to replicate state of the exp_pro_enable_route_and_rc_slew_checks property.
# exp_pro_enable_route_and_rc_slew_checks has default value.
## Tcl commands to replicate state of the exp_pro_enable_route_and_rc_timing_invalidation property.
# exp_pro_enable_route_and_rc_timing_invalidation has default value.
## Tcl commands to replicate state of the exp_pro_permit_sizing_connected_to_preroutes property.
# exp_pro_permit_sizing_connected_to_preroutes has default value.
## Tcl commands to replicate state of the exp_pro_permit_sizing_connected_to_special_routes property.
# exp_pro_permit_sizing_connected_to_special_routes has default value.
## Tcl commands to replicate state of the exp_pro_prim_dijkstra_can_reduce_alpha property.
# exp_pro_prim_dijkstra_can_reduce_alpha has default value.
## Tcl commands to replicate state of the exp_pro_refine_place_fixes_routes property.
# exp_pro_refine_place_fixes_routes has default value.
## Tcl commands to replicate state of the exp_pro_skew_fixing_can_upsize_short_paths property.
# exp_pro_skew_fixing_can_upsize_short_paths has default value.
## Tcl commands to replicate state of the exp_pro_skew_fixing_require_minimum_improvement property.
# exp_pro_skew_fixing_require_minimum_improvement has default value.
## Tcl commands to replicate state of the exp_pro_write_estimates_for_missing_routes property.
# exp_pro_write_estimates_for_missing_routes has default value.
## Tcl commands to replicate state of the exp_rctp3_preserve_skew_band_occupancy property.
# exp_rctp3_preserve_skew_band_occupancy has default value.
## Tcl commands to replicate state of the exp_rctp3_preserve_skew_band_occupancy_with_timing_windows property.
# exp_rctp3_preserve_skew_band_occupancy_with_timing_windows has default value.
## Tcl commands to replicate state of the exp_rctp4_decrease_wire_cap_preserve_route_lengths property.
# exp_rctp4_decrease_wire_cap_preserve_route_lengths has default value.
## Tcl commands to replicate state of the exp_rctp4_do_diagonal_diamond_moves property.
# exp_rctp4_do_diagonal_diamond_moves has default value.
## Tcl commands to replicate state of the exp_rctp4_do_tiny_horizontal_moves property.
# exp_rctp4_do_tiny_horizontal_moves has default value.
## Tcl commands to replicate state of the exp_rctp4_max_move_gate_passes property.
# exp_rctp4_max_move_gate_passes has default value.
## Tcl commands to replicate state of the exp_rctp4_move_gate_distance_divisor property.
# exp_rctp4_move_gate_distance_divisor has default value.
## Tcl commands to replicate state of the exp_rctp4_move_gate_max_move_iterations property.
# exp_rctp4_move_gate_max_move_iterations has default value.
## Tcl commands to replicate state of the exp_rctp4_move_gate_max_move_row_height_multiple property.
# exp_rctp4_move_gate_max_move_row_height_multiple has default value.
## Tcl commands to replicate state of the exp_rctp4_move_gate_prune_mode property.
# exp_rctp4_move_gate_prune_mode has default value.
## Tcl commands to replicate state of the exp_rctp4_move_gate_wl_based_pruning_threshold property.
# exp_rctp4_move_gate_wl_based_pruning_threshold has default value.
## Tcl commands to replicate state of the exp_rctp4_movegates_multithreaded property.
# exp_rctp4_movegates_multithreaded has default value.
## Tcl commands to replicate state of the exp_rctp4_overslew_in_delayed_legalization_ordering property.
# exp_rctp4_overslew_in_delayed_legalization_ordering has default value.
## Tcl commands to replicate state of the exp_rctp4_preserve_band property.
# exp_rctp4_preserve_band has default value.
## Tcl commands to replicate state of the exp_rctp4_preserve_band_per_iteration property.
# exp_rctp4_preserve_band_per_iteration has default value.
## Tcl commands to replicate state of the exp_rctp4_preserve_band_safely property.
# exp_rctp4_preserve_band_safely has default value.
## Tcl commands to replicate state of the exp_rctp4_single_move_per_unit_distance property.
# exp_rctp4_single_move_per_unit_distance has default value.
## Tcl commands to replicate state of the exp_rctp4_skew_margin_multiplier property.
# exp_rctp4_skew_margin_multiplier has default value.
## Tcl commands to replicate state of the exp_rctp4_skip_post_move_verification property.
# exp_rctp4_skip_post_move_verification has default value.
## Tcl commands to replicate state of the exp_rctp4_slew_margin_multiplier property.
# exp_rctp4_slew_margin_multiplier has default value.
## Tcl commands to replicate state of the exp_rctp4_use_integral_row_height_multiple property.
# exp_rctp4_use_integral_row_height_multiple has default value.
## Tcl commands to replicate state of the exp_rctp4_wire_cap_reduction_multithreaded property.
# exp_rctp4_wire_cap_reduction_multithreaded has default value.
## Tcl commands to replicate state of the exp_reactivate_legalizer_after_clustering property.
# exp_reactivate_legalizer_after_clustering has default value.
## Tcl commands to replicate state of the exp_rebuild_ccopt_fragment_mode_if_rebuild_constraint_graph property.
# exp_rebuild_ccopt_fragment_mode_if_rebuild_constraint_graph has default value.
## Tcl commands to replicate state of the exp_reducing_clock_tree_power4_method property.
# exp_reducing_clock_tree_power4_method has default value.
## Tcl commands to replicate state of the exp_reducing_clock_tree_wire_cap_preserve_skew property.
# exp_reducing_clock_tree_wire_cap_preserve_skew has default value.
## Tcl commands to replicate state of the exp_reducing_clock_tree_wire_cap_preserve_skew_band property.
# exp_reducing_clock_tree_wire_cap_preserve_skew_band has default value.
## Tcl commands to replicate state of the exp_refine_place_soft_fix_clock_cells property.
# exp_refine_place_soft_fix_clock_cells has default value.
## Tcl commands to replicate state of the exp_refine_place_soft_fix_clock_sinks_at_the_end_of_implementation property.
# exp_refine_place_soft_fix_clock_sinks_at_the_end_of_implementation has default value.
## Tcl commands to replicate state of the exp_refresh_sdc_annotations_before_multithreading property.
# exp_refresh_sdc_annotations_before_multithreading has default value.
## Tcl commands to replicate state of the exp_relax_skew_target_unit_delay_multiplier property.
# exp_relax_skew_target_unit_delay_multiplier has default value.
## Tcl commands to replicate state of the exp_replace_cell_handle_route_physical_terminals property.
# exp_replace_cell_handle_route_physical_terminals has default value.
## Tcl commands to replicate state of the exp_replace_cell_update_post_route_rc property.
# exp_replace_cell_update_post_route_rc has default value.
## Tcl commands to replicate state of the exp_report_cell_halo_viols_uses_common_code property.
# exp_report_cell_halo_viols_uses_common_code has default value.
## Tcl commands to replicate state of the exp_report_short_dag_stats_at_end_of_cts property.
# exp_report_short_dag_stats_at_end_of_cts has default value.
## Tcl commands to replicate state of the exp_report_source_group_latency_summary_all_steps property.
# exp_report_source_group_latency_summary_all_steps has default value.
## Tcl commands to replicate state of the exp_representative_driver property.
# exp_representative_driver has default value for all objects.
## Tcl commands to replicate state of the exp_resize_gate_permits_snap_to_placeable_area property.
# exp_resize_gate_permits_snap_to_placeable_area has default value.
## Tcl commands to replicate state of the exp_resize_gate_reduce_invalidations property.
# exp_resize_gate_reduce_invalidations has default value.
## Tcl commands to replicate state of the exp_resize_within_delay_famililes_when_changing_delay_families property.
# exp_resize_within_delay_famililes_when_changing_delay_families has default value.
## Tcl commands to replicate state of the exp_restore_original_skew_target_after_detailed_balancing property.
# exp_restore_original_skew_target_after_detailed_balancing has default value.
## Tcl commands to replicate state of the exp_resynthesis_propagate_activity property.
# exp_resynthesis_propagate_activity has default value.
## Tcl commands to replicate state of the exp_route_buffering_downsize_from_smallest property.
# exp_route_buffering_downsize_from_smallest has default value.
## Tcl commands to replicate state of the exp_route_buffering_only_force_slew_on_violators property.
# exp_route_buffering_only_force_slew_on_violators has default value.
## Tcl commands to replicate state of the exp_route_buffering_quick_buffer_save_mini_single property.
# exp_route_buffering_quick_buffer_save_mini_single has default value.
## Tcl commands to replicate state of the exp_route_opt_leaf_net_level property.
# exp_route_opt_leaf_net_level has default value.
## Tcl commands to replicate state of the exp_route_opt_through_alternative_route_types property.
# exp_route_opt_through_alternative_route_types has default value.
## Tcl commands to replicate state of the exp_route_opt_through_lollipop_topology_transform property.
# exp_route_opt_through_lollipop_topology_transform has default value.
## Tcl commands to replicate state of the exp_route_opt_through_pd_ratio_transform property.
# exp_route_opt_through_pd_ratio_transform has default value.
## Tcl commands to replicate state of the exp_route_opt_through_roi_criterion property.
# exp_route_opt_through_roi_criterion has default value.
## Tcl commands to replicate state of the exp_route_opt_through_topology property.
# exp_route_opt_through_topology has default value.
## Tcl commands to replicate state of the exp_route_opt_through_topology_activity_factor property.
# exp_route_opt_through_topology_activity_factor has default value.
## Tcl commands to replicate state of the exp_route_opt_with_skew_and_wirelength_tradeoff property.
# exp_route_opt_with_skew_and_wirelength_tradeoff has default value.
## Tcl commands to replicate state of the exp_route_opt_with_wirelength_bound property.
# exp_route_opt_with_wirelength_bound has default value.
## Tcl commands to replicate state of the exp_route_wire_rebuild_diag property.
# exp_route_wire_rebuild_diag has default value.
## Tcl commands to replicate state of the exp_routeandrc_check_are_net_wires_ok property.
# exp_routeandrc_check_are_net_wires_ok has default value.
## Tcl commands to replicate state of the exp_routeandrc_delete_buffer_avoid_wrong_way_wires property.
# exp_routeandrc_delete_buffer_avoid_wrong_way_wires has default value.
## Tcl commands to replicate state of the exp_routeandrc_edge_cap_by_dfs property.
# exp_routeandrc_edge_cap_by_dfs has default value.
## Tcl commands to replicate state of the exp_routeandrc_insert_buffer_stitching property.
# exp_routeandrc_insert_buffer_stitching has default value.
## Tcl commands to replicate state of the exp_routeandrc_insert_buffer_stitching_preserve_cut_segment_attributes property.
# exp_routeandrc_insert_buffer_stitching_preserve_cut_segment_attributes has default value.
## Tcl commands to replicate state of the exp_routeandrc_lost_resistance_threshold_multiplier property.
# exp_routeandrc_lost_resistance_threshold_multiplier has default value.
## Tcl commands to replicate state of the exp_routeandrc_robustness_mkii property.
# exp_routeandrc_robustness_mkii has default value.
## Tcl commands to replicate state of the exp_routeandrc_undo_use_checksum property.
# exp_routeandrc_undo_use_checksum has default value.
## Tcl commands to replicate state of the exp_routing_estimate_aggressive_pin_escape property.
# exp_routing_estimate_aggressive_pin_escape has default value.
## Tcl commands to replicate state of the exp_routing_estimate_avoid_topology_change property.
# exp_routing_estimate_avoid_topology_change has default value.
## Tcl commands to replicate state of the exp_routing_estimate_build_spine_tree property.
# exp_routing_estimate_build_spine_tree has default value.
## Tcl commands to replicate state of the exp_routing_estimate_check_rcnet_connectivity property.
# exp_routing_estimate_check_rcnet_connectivity has default value.
## Tcl commands to replicate state of the exp_routing_estimate_check_route_est_connectivity property.
# exp_routing_estimate_check_route_est_connectivity has default value.
## Tcl commands to replicate state of the exp_routing_estimate_dump_debug_file property.
# exp_routing_estimate_dump_debug_file has default value.
## Tcl commands to replicate state of the exp_routing_estimate_escape_pin_to_access_in_both_direction property.
# exp_routing_estimate_escape_pin_to_access_in_both_direction has default value.
## Tcl commands to replicate state of the exp_routing_estimate_fast_post_routing_fix property.
# exp_routing_estimate_fast_post_routing_fix has default value.
## Tcl commands to replicate state of the exp_routing_estimate_faster_clean_wires property.
# exp_routing_estimate_faster_clean_wires has default value.
## Tcl commands to replicate state of the exp_routing_estimate_fix_adjust_resource_for_pin_access property.
# exp_routing_estimate_fix_adjust_resource_for_pin_access has default value.
## Tcl commands to replicate state of the exp_routing_estimate_ignore_pg_blockages property.
# exp_routing_estimate_ignore_pg_blockages has default value.
## Tcl commands to replicate state of the exp_routing_estimate_min_num_gcell_search_for_pin_escape property.
# exp_routing_estimate_min_num_gcell_search_for_pin_escape has default value.
## Tcl commands to replicate state of the exp_routing_estimate_model_pass_through_capacity property.
# exp_routing_estimate_model_pass_through_capacity has default value.
## Tcl commands to replicate state of the exp_routing_estimate_model_pass_through_capacity_fix property.
# exp_routing_estimate_model_pass_through_capacity_fix has default value.
## Tcl commands to replicate state of the exp_routing_estimate_reach_length_threshold_in_pin_access property.
# exp_routing_estimate_reach_length_threshold_in_pin_access has default value.
## Tcl commands to replicate state of the exp_routing_estimate_read_blockages_layer_by_layer property.
# exp_routing_estimate_read_blockages_layer_by_layer has default value.
## Tcl commands to replicate state of the exp_routing_estimate_refine_tree property.
# exp_routing_estimate_refine_tree has default value.
## Tcl commands to replicate state of the exp_routing_estimate_routing_via_cost_fix property.
# exp_routing_estimate_routing_via_cost_fix has default value.
## Tcl commands to replicate state of the exp_routing_estimate_scale_for_gcell_size property.
# exp_routing_estimate_scale_for_gcell_size has default value.
## Tcl commands to replicate state of the exp_routing_estimate_similar_topology_routing_fast property.
# exp_routing_estimate_similar_topology_routing_fast has default value.
## Tcl commands to replicate state of the exp_routing_estimate_skip_3d_blockage_violation_free_nets property.
# exp_routing_estimate_skip_3d_blockage_violation_free_nets has default value.
## Tcl commands to replicate state of the exp_routing_estimate_skip_must_layer_relax_segments property.
# exp_routing_estimate_skip_must_layer_relax_segments has default value.
## Tcl commands to replicate state of the exp_routing_estimate_snap_original_points_to_manufacturing_grid property.
# exp_routing_estimate_snap_original_points_to_manufacturing_grid has default value.
## Tcl commands to replicate state of the exp_routing_estimate_soft_top_layer_constraint property.
# exp_routing_estimate_soft_top_layer_constraint has default value.
## Tcl commands to replicate state of the exp_routing_estimate_thread_number_fraction property.
# exp_routing_estimate_thread_number_fraction has default value.
## Tcl commands to replicate state of the exp_routing_estimate_use_2d_route_est_inside_virtual_circuit property.
# exp_routing_estimate_use_2d_route_est_inside_virtual_circuit has default value.
## Tcl commands to replicate state of the exp_routing_estimate_use_3d_route_est property.
# exp_routing_estimate_use_3d_route_est has default value.
## Tcl commands to replicate state of the exp_routing_estimate_use_eg_blk_vio_check_on_edge property.
# exp_routing_estimate_use_eg_blk_vio_check_on_edge has default value.
## Tcl commands to replicate state of the exp_routing_use_clock_net_status_replacement_api property.
# exp_routing_use_clock_net_status_replacement_api has default value.
## Tcl commands to replicate state of the exp_save_clock_trees_in_dag_order property.
# exp_save_clock_trees_in_dag_order has default value.
## Tcl commands to replicate state of the exp_save_dbs_before_and_after_cong_repair property.
# exp_save_dbs_before_and_after_cong_repair has default value.
## Tcl commands to replicate state of the exp_set_dont_use_on_fterm_distinct_eeq_cells_during_refine_place property.
# exp_set_dont_use_on_fterm_distinct_eeq_cells_during_refine_place has default value.
## Tcl commands to replicate state of the exp_set_driver_in_term_before_setupnet_in_abs_stage_delay_model property.
# exp_set_driver_in_term_before_setupnet_in_abs_stage_delay_model has default value.
## Tcl commands to replicate state of the exp_set_is_clk_parameter_for_aae_create_net property.
# exp_set_is_clk_parameter_for_aae_create_net has default value.
## Tcl commands to replicate state of the exp_set_net_weights property.
# exp_set_net_weights has default value.
## Tcl commands to replicate state of the exp_set_not_in_ccopt_scope_for_refine_place_calls property.
# exp_set_not_in_ccopt_scope_for_refine_place_calls has default value.
## Tcl commands to replicate state of the exp_set_null_via_location_for_extraction_in_virtual_estimate property.
# exp_set_null_via_location_for_extraction_in_virtual_estimate has default value.
## Tcl commands to replicate state of the exp_sink_is_enable_latch property.
## Tcl commands to replicate state of the exp_skip_consistency_check_on_multi_driver_net property.
# exp_skip_consistency_check_on_multi_driver_net has default value.
## Tcl commands to replicate state of the exp_skip_database_callback_assert_check_for_non_clock_cells property.
# exp_skip_database_callback_assert_check_for_non_clock_cells has default value.
## Tcl commands to replicate state of the exp_slew_distribution_over_target_report_buckets property.
# exp_slew_distribution_over_target_report_buckets has default value.
## Tcl commands to replicate state of the exp_slew_distribution_under_target_report_buckets property.
# exp_slew_distribution_under_target_report_buckets has default value.
## Tcl commands to replicate state of the exp_slew_fixing_ccr_1984380_misc_fixes property.
# exp_slew_fixing_ccr_1984380_misc_fixes has default value.
## Tcl commands to replicate state of the exp_slew_fixing_check_distance_and_fanout_when_buffering property.
# exp_slew_fixing_check_distance_and_fanout_when_buffering has default value.
## Tcl commands to replicate state of the exp_slew_fixing_dont_break_parents property.
# exp_slew_fixing_dont_break_parents has default value.
## Tcl commands to replicate state of the exp_slew_fixing_only_force_slews_on_violators property.
# exp_slew_fixing_only_force_slews_on_violators has default value.
## Tcl commands to replicate state of the exp_slew_fixing_use_quick_buffering property.
# exp_slew_fixing_use_quick_buffering has default value.
## Tcl commands to replicate state of the exp_snap_target_locations_without_window_to_placeable_area property.
# exp_snap_target_locations_without_window_to_placeable_area has default value.
## Tcl commands to replicate state of the exp_source_group_balancing_mean_latency_threshold property.
# exp_source_group_balancing_mean_latency_threshold has default value.
## Tcl commands to replicate state of the exp_source_group_latencies_balancing_use_buffers property.
# exp_source_group_latencies_balancing_use_buffers has default value.
## Tcl commands to replicate state of the exp_sparse_store_expand_nfs_enum_keys property.
# exp_sparse_store_expand_nfs_enum_keys has default value.
## Tcl commands to replicate state of the exp_spec_config_measure_ilm_internal_timing property.
# exp_spec_config_measure_ilm_internal_timing has default value.
## Tcl commands to replicate state of the exp_spec_config_measure_ilm_internal_timing_latency_file_prefix property.
# exp_spec_config_measure_ilm_internal_timing_latency_file_prefix has default value.
## Tcl commands to replicate state of the exp_spec_config_use_early_for_min_ilm_internal_timing property.
# exp_spec_config_use_early_for_min_ilm_internal_timing has default value.
## Tcl commands to replicate state of the exp_stage_delay_model_worst_case_event_at_output property.
# exp_stage_delay_model_worst_case_event_at_output has default value.
## Tcl commands to replicate state of the exp_steiner_opt_allow_leaf_driver_wirelength_moves_in_extreme_flow property.
# exp_steiner_opt_allow_leaf_driver_wirelength_moves_in_extreme_flow has default value.
## Tcl commands to replicate state of the exp_steiner_opt_enable_flop_move property.
# exp_steiner_opt_enable_flop_move has default value.
## Tcl commands to replicate state of the exp_steiner_opt_extra_effort property.
# exp_steiner_opt_extra_effort has default value.
## Tcl commands to replicate state of the exp_steiner_opt_extra_effort_minimum_move property.
# exp_steiner_opt_extra_effort_minimum_move has default value.
## Tcl commands to replicate state of the exp_steiner_opt_extra_effort_skew_band_with_timing_windows property.
# exp_steiner_opt_extra_effort_skew_band_with_timing_windows has default value.
## Tcl commands to replicate state of the exp_steiner_opt_extra_effort_skew_safe property.
# exp_steiner_opt_extra_effort_skew_safe has default value.
## Tcl commands to replicate state of the exp_steiner_opt_extra_effort_slew_target_multiplier property.
# exp_steiner_opt_extra_effort_slew_target_multiplier has default value.
## Tcl commands to replicate state of the exp_steiner_opt_flipopt_invalidate_routes property.
# exp_steiner_opt_flipopt_invalidate_routes has default value.
## Tcl commands to replicate state of the exp_steiner_opt_flipopt_iterations property.
# exp_steiner_opt_flipopt_iterations has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_optimizes_wire_cap property.
# exp_steiner_opt_move_optimizes_wire_cap has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_route_cache property.
# exp_steiner_opt_move_route_cache has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_bbox_growth property.
# exp_steiner_opt_move_sinks_for_wire_length_bbox_growth has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_check_bounding_boxes property.
# exp_steiner_opt_move_sinks_for_wire_length_check_bounding_boxes has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_check_in_radius property.
# exp_steiner_opt_move_sinks_for_wire_length_check_in_radius has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_in_groups property.
# exp_steiner_opt_move_sinks_for_wire_length_in_groups has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_iterations property.
# exp_steiner_opt_move_sinks_for_wire_length_iterations has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_max_row_heights property.
# exp_steiner_opt_move_sinks_for_wire_length_max_row_heights has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_min_reduction_ratio property.
# exp_steiner_opt_move_sinks_for_wire_length_min_reduction_ratio has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_min_row_heights property.
# exp_steiner_opt_move_sinks_for_wire_length_min_row_heights has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_specify_target_rectangle property.
# exp_steiner_opt_move_sinks_for_wire_length_specify_target_rectangle has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_target_fraction property.
# exp_steiner_opt_move_sinks_for_wire_length_target_fraction has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_to_core property.
# exp_steiner_opt_move_sinks_for_wire_length_to_core has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_sinks_for_wire_length_use_activity property.
# exp_steiner_opt_move_sinks_for_wire_length_use_activity has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_to_core_common_path property.
# exp_steiner_opt_move_to_core_common_path has default value.
## Tcl commands to replicate state of the exp_steiner_opt_move_to_core_iterations property.
# exp_steiner_opt_move_to_core_iterations has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_access_enable property.
# exp_steiner_opt_overfix_access_enable has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_enable property.
# exp_steiner_opt_overfix_enable has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_flipopt_enable property.
# exp_steiner_opt_overfix_flipopt_enable has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_flipopt_mode property.
# exp_steiner_opt_overfix_flipopt_mode has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_pdopt_enable property.
# exp_steiner_opt_overfix_pdopt_enable has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_slew_target_multiplier property.
# exp_steiner_opt_overfix_slew_target_multiplier has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_wire_cap_reduction property.
# exp_steiner_opt_overfix_wire_cap_reduction has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_wire_cap_reduction_minimum_move property.
# exp_steiner_opt_overfix_wire_cap_reduction_minimum_move has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_wire_cap_reduction_preserve_band property.
# exp_steiner_opt_overfix_wire_cap_reduction_preserve_band has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_wire_cap_reduction_slew_target_multiplier property.
# exp_steiner_opt_overfix_wire_cap_reduction_slew_target_multiplier has default value.
## Tcl commands to replicate state of the exp_steiner_opt_overfix_wire_reduction property.
# exp_steiner_opt_overfix_wire_reduction has default value.
## Tcl commands to replicate state of the exp_steiner_opt_pinkv2_skew_safe property.
# exp_steiner_opt_pinkv2_skew_safe has default value.
## Tcl commands to replicate state of the exp_steiner_opt_power_reclaim_enable property.
# exp_steiner_opt_power_reclaim_enable has default value.
## Tcl commands to replicate state of the exp_steiner_opt_power_reclaim_move_optimizes_wire_cap property.
# exp_steiner_opt_power_reclaim_move_optimizes_wire_cap has default value.
## Tcl commands to replicate state of the exp_steiner_opt_recovery_enable property.
# exp_steiner_opt_recovery_enable has default value.
## Tcl commands to replicate state of the exp_steiner_opt_recovery_prim_dijkstra_id_opt property.
# exp_steiner_opt_recovery_prim_dijkstra_id_opt has default value.
## Tcl commands to replicate state of the exp_steiner_opt_recovery_slew_target_multiplier property.
# exp_steiner_opt_recovery_slew_target_multiplier has default value.
## Tcl commands to replicate state of the exp_steiner_opt_recovery_wire_reduction property.
# exp_steiner_opt_recovery_wire_reduction has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_cap_reduction_can_move_leaf_drivers property.
# exp_steiner_opt_wire_cap_reduction_can_move_leaf_drivers has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_reduction_decreasing_moves property.
# exp_steiner_opt_wire_reduction_decreasing_moves has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_reduction_iterations property.
# exp_steiner_opt_wire_reduction_iterations has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_reduction_max_move property.
# exp_steiner_opt_wire_reduction_max_move has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_reduction_minimum_move property.
# exp_steiner_opt_wire_reduction_minimum_move has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_reduction_move_to_core property.
# exp_steiner_opt_wire_reduction_move_to_core has default value.
## Tcl commands to replicate state of the exp_steiner_opt_wire_reduction_respect_clock_gate_regions property.
# exp_steiner_opt_wire_reduction_respect_clock_gate_regions has default value.
## Tcl commands to replicate state of the exp_store_locations_and_orientations_of_flops property.
# exp_store_locations_and_orientations_of_flops has default value.
## Tcl commands to replicate state of the exp_substituting_inverting_clock_gates_before_idr_optimization_goal property.
# exp_substituting_inverting_clock_gates_before_idr_optimization_goal has default value.
## Tcl commands to replicate state of the exp_substituting_inverting_clock_gates_optimization_goal property.
# exp_substituting_inverting_clock_gates_optimization_goal has default value.
## Tcl commands to replicate state of the exp_target_max_stage_delay_sigma property.
# exp_target_max_stage_delay_sigma has default value for all objects.
## Tcl commands to replicate state of the exp_timing_enable_parallel_multicorner property.
# exp_timing_enable_parallel_multicorner has default value.
## Tcl commands to replicate state of the exp_timing_enable_predictive_cache property.
# exp_timing_enable_predictive_cache has default value.
## Tcl commands to replicate state of the exp_transforms_algorithm_list property.
# exp_transforms_algorithm_list has default value.
## Tcl commands to replicate state of the exp_trap_new_unfixable_slews property.
# exp_trap_new_unfixable_slews has default value.
## Tcl commands to replicate state of the exp_trim_route_type_layer_rc_table_report property.
# exp_trim_route_type_layer_rc_table_report has default value.
## Tcl commands to replicate state of the exp_try_changing_delay_families_before_adding_more_buffers property.
# exp_try_changing_delay_families_before_adding_more_buffers has default value.
## Tcl commands to replicate state of the exp_try_changing_delay_families_cache_max_id property.
# exp_try_changing_delay_families_cache_max_id has default value.
## Tcl commands to replicate state of the exp_try_changing_delay_families_separate_criteria_for_ideal_nets property.
# exp_try_changing_delay_families_separate_criteria_for_ideal_nets has default value.
## Tcl commands to replicate state of the exp_unfiltered_slew_targeted_half_corners property.
set_ccopt_property exp_unfiltered_slew_targeted_half_corners {}
## Tcl commands to replicate state of the exp_unlock_exclusion_drivers property.
# exp_unlock_exclusion_drivers has default value.
## Tcl commands to replicate state of the exp_update_slacks_flush_all_invalid_timing_lists property.
# exp_update_slacks_flush_all_invalid_timing_lists has default value.
## Tcl commands to replicate state of the exp_use_both_aae_and_fdc_for_analysis property.
# exp_use_both_aae_and_fdc_for_analysis has default value.
## Tcl commands to replicate state of the exp_use_caller_specified_preferred_rectangles property.
# exp_use_caller_specified_preferred_rectangles has default value.
## Tcl commands to replicate state of the exp_use_db_based_activity_interface property.
# exp_use_db_based_activity_interface has default value.
## Tcl commands to replicate state of the exp_use_flipper_to_reserve_space_for_clock_sinks property.
# exp_use_flipper_to_reserve_space_for_clock_sinks has default value.
## Tcl commands to replicate state of the exp_use_high_frequency_detailed_router property.
# exp_use_high_frequency_detailed_router has default value.
## Tcl commands to replicate state of the exp_use_inst_term_voltage_lookup property.
# exp_use_inst_term_voltage_lookup has default value.
## Tcl commands to replicate state of the exp_use_legacy_naming property.
# exp_use_legacy_naming has default value.
## Tcl commands to replicate state of the exp_use_min_unit_delay_across_power_contexts_for_auto_skew_target property.
# exp_use_min_unit_delay_across_power_contexts_for_auto_skew_target has default value.
## Tcl commands to replicate state of the exp_use_multi_corner_bufferability property.
# exp_use_multi_corner_bufferability has default value.
## Tcl commands to replicate state of the exp_use_new_get_cap_for_downstream_net property.
# exp_use_new_get_cap_for_downstream_net has default value.
## Tcl commands to replicate state of the exp_use_nldm_pin_cap_for_downstream_net property.
# exp_use_nldm_pin_cap_for_downstream_net has default value.
## Tcl commands to replicate state of the exp_use_preferred_extra_space_with_ndr property.
# exp_use_preferred_extra_space_with_ndr has default value.
## Tcl commands to replicate state of the exp_use_region_union_when_constructing_route_regions property.
# exp_use_region_union_when_constructing_route_regions has default value.
## Tcl commands to replicate state of the exp_use_route_geodesics property.
# exp_use_route_geodesics has default value.
## Tcl commands to replicate state of the exp_use_scoped_exit_ccopt_for_all_refine_place_calls property.
# exp_use_scoped_exit_ccopt_for_all_refine_place_calls has default value.
## Tcl commands to replicate state of the exp_use_under_bufferability_in_prefilter_in_sizing property.
# exp_use_under_bufferability_in_prefilter_in_sizing has default value.
## Tcl commands to replicate state of the exp_useful_skew_apply_movement_limit_after_initial_cluster property.
# exp_useful_skew_apply_movement_limit_after_initial_cluster has default value.
## Tcl commands to replicate state of the exp_useful_skew_assert_non_representative_driver_network_latencies property.
# exp_useful_skew_assert_non_representative_driver_network_latencies has default value.
## Tcl commands to replicate state of the exp_useful_skew_clip_min_virtual_delay_to_zero property.
# exp_useful_skew_clip_min_virtual_delay_to_zero has default value.
## Tcl commands to replicate state of the exp_useful_skew_clock_gate_movement_limit_um property.
# exp_useful_skew_clock_gate_movement_limit_um has default value.
## Tcl commands to replicate state of the exp_useful_skew_compute_typical_delay_sum_all_trees property.
# exp_useful_skew_compute_typical_delay_sum_all_trees has default value.
## Tcl commands to replicate state of the exp_useful_skew_confine_virtual_delay_to_sinks property.
# exp_useful_skew_confine_virtual_delay_to_sinks has default value.
## Tcl commands to replicate state of the exp_useful_skew_force_inf_max_removable_delay property.
# exp_useful_skew_force_inf_max_removable_delay has default value.
## Tcl commands to replicate state of the exp_useful_skew_force_local_delta property.
# exp_useful_skew_force_local_delta has default value.
## Tcl commands to replicate state of the exp_useful_skew_gap_offset_removable_clustering_delay property.
# exp_useful_skew_gap_offset_removable_clustering_delay has default value.
## Tcl commands to replicate state of the exp_useful_skew_gate_skew_band_size_factor property.
# exp_useful_skew_gate_skew_band_size_factor has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_delta_by_view property.
# exp_useful_skew_ideal_delta_by_view has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_delta_by_view_bug_fix property.
# exp_useful_skew_ideal_delta_by_view_bug_fix has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_clock_tracker_enable_all_views property.
# exp_useful_skew_ideal_mode_clock_tracker_enable_all_views has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_filter_clock_gen_flops_in_calc_latency property.
# exp_useful_skew_ideal_mode_filter_clock_gen_flops_in_calc_latency has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_force_local_delta property.
# exp_useful_skew_ideal_mode_force_local_delta has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_high_priority_assignment_in_clustering property.
# exp_useful_skew_ideal_mode_high_priority_assignment_in_clustering has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_ideal_delta_by_view property.
# exp_useful_skew_ideal_mode_ideal_delta_by_view has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_ignore_bufferability_reasons property.
# exp_useful_skew_ideal_mode_ignore_bufferability_reasons has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_initial_global_use_max_delay property.
# exp_useful_skew_ideal_mode_initial_global_use_max_delay has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_initial_global_use_trial_balancer property.
# exp_useful_skew_ideal_mode_initial_global_use_trial_balancer has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_inter_fragment_skewing property.
# exp_useful_skew_ideal_mode_inter_fragment_skewing has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_late_scaling_only property.
# exp_useful_skew_ideal_mode_late_scaling_only has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_min_max_latency property.
# exp_useful_skew_ideal_mode_min_max_latency has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_reset_clock_tree_latencies property.
# exp_useful_skew_ideal_mode_reset_clock_tree_latencies has default value.
## Tcl commands to replicate state of the exp_useful_skew_ideal_mode_skew_ignore_pins property.
# exp_useful_skew_ideal_mode_skew_ignore_pins has default value.
## Tcl commands to replicate state of the exp_useful_skew_initial_global_use_max_delay property.
# exp_useful_skew_initial_global_use_max_delay has default value.
## Tcl commands to replicate state of the exp_useful_skew_initial_global_use_trial_balancer property.
# exp_useful_skew_initial_global_use_trial_balancer has default value.
## Tcl commands to replicate state of the exp_useful_skew_inter_fragment_skewing property.
# exp_useful_skew_inter_fragment_skewing has default value.
## Tcl commands to replicate state of the exp_useful_skew_max_allowed_delay_budget_user_pid property.
# exp_useful_skew_max_allowed_delay_budget_user_pid has default value.
## Tcl commands to replicate state of the exp_useful_skew_max_removable_exclude_node_delay property.
# exp_useful_skew_max_removable_exclude_node_delay has default value.
## Tcl commands to replicate state of the exp_useful_skew_partly_enable_inter_fragment_skewing property.
# exp_useful_skew_partly_enable_inter_fragment_skewing has default value.
## Tcl commands to replicate state of the exp_useful_skew_pin_insertion_delay_quantization_after_skewing property.
# exp_useful_skew_pin_insertion_delay_quantization_after_skewing has default value.
## Tcl commands to replicate state of the exp_useful_skew_pin_insertion_delay_quantization_before_skewing property.
# exp_useful_skew_pin_insertion_delay_quantization_before_skewing has default value.
## Tcl commands to replicate state of the exp_verify_legal_corrects_errors property.
# exp_verify_legal_corrects_errors has default value.
## Tcl commands to replicate state of the exp_vgbuffering_cell_timing_cache_cap_seed_relax_ratio property.
# exp_vgbuffering_cell_timing_cache_cap_seed_relax_ratio has default value.
## Tcl commands to replicate state of the exp_vgbuffering_compute_cap_seed_by_opt_driving_distance property.
# exp_vgbuffering_compute_cap_seed_by_opt_driving_distance has default value.
## Tcl commands to replicate state of the exp_vgbuffering_distance_to_legalized_location_tolerance property.
# exp_vgbuffering_distance_to_legalized_location_tolerance has default value.
## Tcl commands to replicate state of the exp_vgbuffering_kernel_slew_target_relax_ratio property.
# exp_vgbuffering_kernel_slew_target_relax_ratio has default value.
## Tcl commands to replicate state of the exp_vgbuffering_long_wire_segmentation_ratio property.
# exp_vgbuffering_long_wire_segmentation_ratio has default value.
## Tcl commands to replicate state of the exp_vgbuffering_prefer_always_on_power_context property.
# exp_vgbuffering_prefer_always_on_power_context has default value.
## Tcl commands to replicate state of the exp_virtual_delay_skip_disabled_views property.
# exp_virtual_delay_skip_disabled_views has default value.
## Tcl commands to replicate state of the exp_write_pre_balance_summary_to_file property.
# exp_write_pre_balance_summary_to_file has default value.
## Tcl commands to replicate state of the exp_write_steiner_routes_to_db_after_clustering_cong_repair property.
# exp_write_steiner_routes_to_db_after_clustering_cong_repair has default value.
## Tcl commands to replicate state of the expand_multi_child_regions property.
# expand_multi_child_regions has default value for all objects.
## Tcl commands to replicate state of the expand_multi_child_regions_above property.
# expand_multi_child_regions_above has default value for all objects.
## Tcl commands to replicate state of the expand_multi_child_regions_for_furthest_sinks property.
# expand_multi_child_regions_for_furthest_sinks has default value.
## Tcl commands to replicate state of the expand_multi_child_regions_for_sinks_with_min_depth property.
# expand_multi_child_regions_for_sinks_with_min_depth has default value.
## Tcl commands to replicate state of the extract_additional_clock_tree_symbols property.
# extract_additional_clock_tree_symbols has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_delete_temp_files property.
# extract_clock_trees_ilm_flow_delete_temp_files has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_run_with_fork property.
# extract_clock_trees_ilm_flow_run_with_fork has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_run_with_propagated_clocks property.
# extract_clock_trees_ilm_flow_run_with_propagated_clocks has default value.
## Tcl commands to replicate state of the extract_clock_trees_ilm_flow_use_skew_group_delays property.
# extract_clock_trees_ilm_flow_use_skew_group_delays has default value.
## Tcl commands to replicate state of the extract_clock_trees_use_ilm_flow property.
# extract_clock_trees_use_ilm_flow has default value.
## Tcl commands to replicate state of the extract_explicit_ignores_for_implicit_excludes_beyond_sta_clocks property.
# extract_explicit_ignores_for_implicit_excludes_beyond_sta_clocks has default value.
## Tcl commands to replicate state of the extract_ilm_fanout_limit property.
# extract_ilm_fanout_limit has default value.
## Tcl commands to replicate state of the extract_minimize_generated_clock_insertion_delay property.
# extract_minimize_generated_clock_insertion_delay has default value.
## Tcl commands to replicate state of the extract_per_skew_group_source_latencies property.
# extract_per_skew_group_source_latencies has default value.
## Tcl commands to replicate state of the extract_sdc_slew_targets_for_hold property.
# extract_sdc_slew_targets_for_hold has default value.
## Tcl commands to replicate state of the extract_trace_forced_arcs property.
# extract_trace_forced_arcs has default value.
## Tcl commands to replicate state of the extract_trace_forced_arcs_insertion_delay property.
# extract_trace_forced_arcs_insertion_delay has default value.
## Tcl commands to replicate state of the extract_use_unit_delays property.
# extract_use_unit_delays has default value.
## Tcl commands to replicate state of the extract_use_zero_delays property.
# extract_use_zero_delays has default value.
## Tcl commands to replicate state of the extracted_from_clock_name property.
set_ccopt_property extracted_from_clock_name -skew_group default.clk/cons_mode clk
## Tcl commands to replicate state of the extracted_from_constraint_mode_name property.
set_ccopt_property extracted_from_constraint_mode_name -skew_group default.clk/cons_mode cons_mode
## Tcl commands to replicate state of the extracted_from_delay_corners property.
set_ccopt_property extracted_from_delay_corners -skew_group default.clk/cons_mode {fast_delay fast_delay typ_delay typ_delay slow_delay slow_delay}
## Tcl commands to replicate state of the extractrc_after_commit_net_attributes_and_route_estimates property.
# extractrc_after_commit_net_attributes_and_route_estimates has default value.
## Tcl commands to replicate state of the fanout_report_num_bins property.
# fanout_report_num_bins has default value.
## Tcl commands to replicate state of the fast_clock_extraction property.
# fast_clock_extraction has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_ecsm_pin_cap_cache_size property.
# fast_delay_calc_set_ecsm_pin_cap_cache_size has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_margin_for_convergence_in_delay_with_ecsm_pin_cap property.
# fast_delay_calc_set_margin_for_convergence_in_delay_with_ecsm_pin_cap has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_margin_for_convergence_in_slew_with_ecsm_pin_cap property.
# fast_delay_calc_set_margin_for_convergence_in_slew_with_ecsm_pin_cap has default value.
## Tcl commands to replicate state of the fast_delay_calc_set_max_iter_for_ecsm_pin_cap property.
# fast_delay_calc_set_max_iter_for_ecsm_pin_cap has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_aae_for_gate_model property.
# fast_delay_calc_use_aae_for_gate_model has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_d2m_for_slew property.
# fast_delay_calc_use_d2m_for_slew has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_d2m_with_ramp_input_for_delay property.
# fast_delay_calc_use_d2m_with_ramp_input_for_delay has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_d2m_with_step_input_for_delay property.
# fast_delay_calc_use_d2m_with_step_input_for_delay has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_delay_ceff property.
# fast_delay_calc_use_delay_ceff has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_ecsm_pin_cap_in_first_iteration property.
# fast_delay_calc_use_ecsm_pin_cap_in_first_iteration has default value.
## Tcl commands to replicate state of the fast_delay_calc_use_slew_ceff property.
# fast_delay_calc_use_slew_ceff has default value.
## Tcl commands to replicate state of the fast_path_multiple property.
# fast_path_multiple has default value.
## Tcl commands to replicate state of the fast_path_multiple_debug_limits property.
# fast_path_multiple_debug_limits has default value.
## Tcl commands to replicate state of the fast_pre_route_cap_extraction property.
# fast_pre_route_cap_extraction has default value.
## Tcl commands to replicate state of the fast_trial_debug_placeable_regions property.
# fast_trial_debug_placeable_regions has default value.
## Tcl commands to replicate state of the fast_trial_use_overlay property.
# fast_trial_use_overlay has default value.
## Tcl commands to replicate state of the fastest_buffer property.
# fastest_buffer has default value.
## Tcl commands to replicate state of the fastest_buffer_max_trans property.
# fastest_buffer_max_trans has default value.
## Tcl commands to replicate state of the fastest_inverter property.
# fastest_inverter has default value.
## Tcl commands to replicate state of the fastest_inverter_max_trans property.
# fastest_inverter_max_trans has default value.
## Tcl commands to replicate state of the filter_cell_lists_for_frequency_dependent_max_cap_constraints property.
# filter_cell_lists_for_frequency_dependent_max_cap_constraints has default value.
## Tcl commands to replicate state of the find_clustering_level_lunk_node_bounding_box_limit property.
# find_clustering_level_lunk_node_bounding_box_limit has default value.
## Tcl commands to replicate state of the find_clustering_level_lunk_sink_count_ratio property.
# find_clustering_level_lunk_sink_count_ratio has default value.
## Tcl commands to replicate state of the find_max_driver_cap_default_separation property.
# find_max_driver_cap_default_separation has default value.
## Tcl commands to replicate state of the find_max_driver_cap_use_zero_and_default_wire_separation property.
# find_max_driver_cap_use_zero_and_default_wire_separation has default value.
## Tcl commands to replicate state of the fix_clock_gate_enable_slacks_after_cluster property.
# fix_clock_gate_enable_slacks_after_cluster has default value.
## Tcl commands to replicate state of the fix_clock_routes_during_final_implementation property.
# fix_clock_routes_during_final_implementation has default value.
## Tcl commands to replicate state of the flexible_htree_default_layer_density property.
# flexible_htree_default_layer_density has default value.
## Tcl commands to replicate state of the flexible_htree_default_target_grid_step_multiplier property.
# flexible_htree_default_target_grid_step_multiplier has default value.
## Tcl commands to replicate state of the flexible_htree_filter_taps property.
# flexible_htree_filter_taps has default value.
## Tcl commands to replicate state of the flexible_htree_hterm_locations property.
# flexible_htree_hterm_locations has default value.
## Tcl commands to replicate state of the flexible_htree_ignore_strip_net_min_space property.
# flexible_htree_ignore_strip_net_min_space has default value.
## Tcl commands to replicate state of the flexible_htree_max_synthesis_grid_points property.
# flexible_htree_max_synthesis_grid_points has default value.
## Tcl commands to replicate state of the flexible_htree_new_symmetric property.
# flexible_htree_new_symmetric has default value.
## Tcl commands to replicate state of the flexible_htree_placement_legalization_effort property.
# flexible_htree_placement_legalization_effort has default value.
## Tcl commands to replicate state of the flexible_htree_rotate_buffers property.
# flexible_htree_rotate_buffers has default value.
## Tcl commands to replicate state of the flexible_htree_route_gcell_grid_size property.
# flexible_htree_route_gcell_grid_size has default value.
## Tcl commands to replicate state of the flexible_htree_symmetric_force_schedule property.
# flexible_htree_symmetric_force_schedule has default value.
## Tcl commands to replicate state of the flexible_htree_symmetric_limited_legalization property.
# flexible_htree_symmetric_limited_legalization has default value.
## Tcl commands to replicate state of the flexible_htree_trunk_cell_blocked_warning_threshold property.
# flexible_htree_trunk_cell_blocked_warning_threshold has default value.
## Tcl commands to replicate state of the flexible_htree_verbose_balancer_initialize property.
# flexible_htree_verbose_balancer_initialize has default value.
## Tcl commands to replicate state of the forbid_leaf_drivers_to_move_over_cts_optimization property.
# forbid_leaf_drivers_to_move_over_cts_optimization has default value.
## Tcl commands to replicate state of the force_all_module_boundaries_dont_touch property.
# force_all_module_boundaries_dont_touch has default value.
## Tcl commands to replicate state of the force_all_virtual_delay_updates property.
# force_all_virtual_delay_updates has default value.
## Tcl commands to replicate state of the force_analysis_with_abstract_stage_delay_model property.
# force_analysis_with_abstract_stage_delay_model has default value.
## Tcl commands to replicate state of the force_analysis_with_estimated_routes property.
# force_analysis_with_estimated_routes has default value.
## Tcl commands to replicate state of the force_analysis_with_fast_delay_calc property.
# force_analysis_with_fast_delay_calc has default value.
## Tcl commands to replicate state of the force_analysis_with_next_stage_cap_estimate property.
# force_analysis_with_next_stage_cap_estimate has default value.
## Tcl commands to replicate state of the force_clock_topology_changed_after_recalibrate property.
# force_clock_topology_changed_after_recalibrate has default value.
## Tcl commands to replicate state of the force_clock_tree property.
# force_clock_tree has default value for all objects.
## Tcl commands to replicate state of the force_cloning_of_gates_and_logics_with_sparse_fanout property.
# force_cloning_of_gates_and_logics_with_sparse_fanout has default value.
## Tcl commands to replicate state of the force_cluster_only property.
# force_cluster_only has default value.
## Tcl commands to replicate state of the force_design_routing_status property.
set_ccopt_property force_design_routing_status auto
## Tcl commands to replicate state of the force_ilm_keepflatten_status property.
set_ccopt_property force_ilm_keepflatten_status false
## Tcl commands to replicate state of the force_nanoroute_single_threaded property.
# force_nanoroute_single_threaded has default value.
## Tcl commands to replicate state of the force_update_io_latency property.
# force_update_io_latency has default value.
## Tcl commands to replicate state of the force_virtual_delay_update_before_skewing_adjustors property.
# force_virtual_delay_update_before_skewing_adjustors has default value.
## Tcl commands to replicate state of the frequency_dependent_max_cap_usability_check_max_cap_fanout_factor property.
# frequency_dependent_max_cap_usability_check_max_cap_fanout_factor has default value.
## Tcl commands to replicate state of the gate_max_delta_slack_factor property.
# gate_max_delta_slack_factor has default value.
## Tcl commands to replicate state of the gate_max_delta_slack_factor_ideal_mode property.
# gate_max_delta_slack_factor_ideal_mode has default value.
## Tcl commands to replicate state of the get_downstream_net_for_sink property.
# get_downstream_net_for_sink has default value.
## Tcl commands to replicate state of the global_route_and_buffer_clock_trees property.
# global_route_and_buffer_clock_trees has default value.
## Tcl commands to replicate state of the global_route_and_buffer_clock_trees_with_trunk_rules property.
# global_route_and_buffer_clock_trees_with_trunk_rules has default value.
## Tcl commands to replicate state of the global_route_chains_create_routing_obstructions property.
# global_route_chains_create_routing_obstructions has default value.
## Tcl commands to replicate state of the global_route_chains_early_global_dump_book_shelf_files property.
# global_route_chains_early_global_dump_book_shelf_files has default value.
## Tcl commands to replicate state of the global_route_chains_high_effort property.
# global_route_chains_high_effort has default value.
## Tcl commands to replicate state of the global_route_chains_prioritize_nets_by_underdelay property.
# global_route_chains_prioritize_nets_by_underdelay has default value.
## Tcl commands to replicate state of the global_route_chains_punch_through_distance property.
# global_route_chains_punch_through_distance has default value.
## Tcl commands to replicate state of the global_route_chains_reroute_and_buffer_everything property.
# global_route_chains_reroute_and_buffer_everything has default value.
## Tcl commands to replicate state of the global_route_chains_route_buffering_location_multiplier property.
# global_route_chains_route_buffering_location_multiplier has default value.
## Tcl commands to replicate state of the ground_xcaps property.
# ground_xcaps has default value.
## Tcl commands to replicate state of the guide_terminal_edge_filter_threshold_multiple_of_m2_pitch property.
# guide_terminal_edge_filter_threshold_multiple_of_m2_pitch has default value.
## Tcl commands to replicate state of the gzip_debug property.
# gzip_debug has default value.
## Tcl commands to replicate state of the honor_timing_library_infer_cap_range_config property.
# honor_timing_library_infer_cap_range_config has default value.
## Tcl commands to replicate state of the ideal_net property.
# ideal_net has default value for all objects.
## Tcl commands to replicate state of the ignore_unpreserved_undriven_output_ports property.
# ignore_unpreserved_undriven_output_ports has default value.
## Tcl commands to replicate state of the igpc_clone_and_divide_overslew_threshold property.
# igpc_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the igpc_downsize_algorithm_passes property.
# igpc_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the igpc_downsize_algorithm_use_single_step property.
# igpc_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the igpc_downsize_slew_target_multiplier property.
# igpc_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the igpc_drv_buffering_number_to_keep property.
# igpc_drv_buffering_number_to_keep has default value.
## Tcl commands to replicate state of the igpc_drv_buffering_second_pass_number_to_keep property.
# igpc_drv_buffering_second_pass_number_to_keep has default value.
## Tcl commands to replicate state of the igpc_enable property.
# igpc_enable has default value.
## Tcl commands to replicate state of the igpc_enable_clone_and_divide property.
# igpc_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the igpc_enable_down_sizing_pass property.
# igpc_enable_down_sizing_pass has default value.
## Tcl commands to replicate state of the igpc_enable_drv_fixing_by_rebuffering property.
# igpc_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the igpc_enable_drv_fixing_by_rebuffering_second_pass property.
# igpc_enable_drv_fixing_by_rebuffering_second_pass has default value.
## Tcl commands to replicate state of the igpc_enable_drv_fixing_with_restructuring property.
# igpc_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the igpc_enable_drv_initial_sizing property.
# igpc_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the igpc_enable_initial_down_sizing_pass property.
# igpc_enable_initial_down_sizing_pass has default value.
## Tcl commands to replicate state of the igpc_enable_max_length_checks property.
# igpc_enable_max_length_checks has default value.
## Tcl commands to replicate state of the igpc_enable_move_down property.
# igpc_enable_move_down has default value.
## Tcl commands to replicate state of the igpc_enable_skew_fixing_by_cell_sizing property.
# igpc_enable_skew_fixing_by_cell_sizing has default value.
## Tcl commands to replicate state of the igpc_enable_skew_fixing_by_rebuffering property.
# igpc_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the igpc_max_move_multiplier property.
# igpc_max_move_multiplier has default value.
## Tcl commands to replicate state of the igpc_min_overslew_to_fix_using_buffering_in_ps property.
# igpc_min_overslew_to_fix_using_buffering_in_ps has default value.
## Tcl commands to replicate state of the igpc_min_overslew_to_fix_using_buffering_second_pass_in_ps property.
# igpc_min_overslew_to_fix_using_buffering_second_pass_in_ps has default value.
## Tcl commands to replicate state of the igpc_min_overslew_to_fix_using_sizing_in_ps property.
# igpc_min_overslew_to_fix_using_sizing_in_ps has default value.
## Tcl commands to replicate state of the igpc_update_timing property.
# igpc_update_timing has default value.
## Tcl commands to replicate state of the igpc_use_fast_cell_sizing_algorithm property.
# igpc_use_fast_cell_sizing_algorithm has default value.
## Tcl commands to replicate state of the importance property.
# importance has default value for all objects.
## Tcl commands to replicate state of the improved_conditional_arc_cell_equivalence_check property.
# improved_conditional_arc_cell_equivalence_check has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_preserves_route_lengths property.
# improving_clock_tree_routing_preserves_route_lengths has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing property.
# improving_clock_tree_routing_use_routing has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing_include_driver_location property.
# improving_clock_tree_routing_use_routing_include_driver_location has default value.
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing_move_leaves property.
set_ccopt_property improving_clock_tree_routing_use_routing_move_leaves 0
## Tcl commands to replicate state of the improving_clock_tree_routing_use_routing_skew_margin property.
set_ccopt_property improving_clock_tree_routing_use_routing_skew_margin 0.8
## Tcl commands to replicate state of the improving_skew_before_reducing_clock_tree_power property.
# improving_skew_before_reducing_clock_tree_power has default value.
## Tcl commands to replicate state of the improving_skew_target_wire_skew property.
# improving_skew_target_wire_skew has default value.
## Tcl commands to replicate state of the inbound_cell_area_fix property.
# inbound_cell_area_fix has default value.
## Tcl commands to replicate state of the include_source_latency property.
set_ccopt_property include_source_latency -skew_group default.clk/cons_mode 1
set_ccopt_property include_source_latency -skew_group icts.clk/cons_mode 1
## Tcl commands to replicate state of the include_vias_when_treating_special_nets_as_routing_blockages property.
# include_vias_when_treating_special_nets_as_routing_blockages has default value.
## Tcl commands to replicate state of the init_adjust_sink_grid_for_aspect_ratio property.
# init_adjust_sink_grid_for_aspect_ratio has default value for all objects.
## Tcl commands to replicate state of the init_balance_weight property.
# init_balance_weight has default value for all objects.
## Tcl commands to replicate state of the init_branch_point_buffer_schedule property.
# init_branch_point_buffer_schedule has default value for all objects.
## Tcl commands to replicate state of the init_cannot_clone_reason property.
# init_cannot_clone_reason has default value for all objects.
## Tcl commands to replicate state of the init_cannot_fix_pre_route property.
# init_cannot_fix_pre_route has default value for all objects.
## Tcl commands to replicate state of the init_cannot_merge_reason property.
# init_cannot_merge_reason has default value for all objects.
## Tcl commands to replicate state of the init_ccopt_engine_pin_state property.
# init_ccopt_engine_pin_state has default value for all objects.
## Tcl commands to replicate state of the init_chosen_route_type property.
# init_chosen_route_type has default value for all objects.
## Tcl commands to replicate state of the init_chosen_route_type_source property.
# init_chosen_route_type_source has default value for all objects.
## Tcl commands to replicate state of the init_clock_domain_skew_group property.
# init_clock_domain_skew_group has default value for all objects.
## Tcl commands to replicate state of the init_clock_period property.
# init_clock_period has default value for all objects.
## Tcl commands to replicate state of the init_cluster_for_htree_topology property.
# init_cluster_for_htree_topology has default value for all objects.
## Tcl commands to replicate state of the init_clustering_region property.
# init_clustering_region has default value for all objects.
## Tcl commands to replicate state of the init_effort property.
# init_effort has default value for all objects.
## Tcl commands to replicate state of the init_exclude_delays_below_sinks property.
# init_exclude_delays_below_sinks has default value for all objects.
## Tcl commands to replicate state of the init_exclusion_zones property.
# init_exclusion_zones has default value for all objects.
## Tcl commands to replicate state of the init_exclusive_sinks_rank property.
# init_exclusive_sinks_rank has default value for all objects.
## Tcl commands to replicate state of the init_exp_flexible_htree_layer_demote_distance property.
# init_exp_flexible_htree_layer_demote_distance has default value for all objects.
## Tcl commands to replicate state of the init_exp_pre_existing_driver property.
# init_exp_pre_existing_driver has default value for all objects.
## Tcl commands to replicate state of the init_final_cell property.
# init_final_cell has default value for all objects.
## Tcl commands to replicate state of the init_htree_relative_inst_name property.
# init_htree_relative_inst_name has default value for all objects.
## Tcl commands to replicate state of the init_htree_sinks property.
# init_htree_sinks has default value for all objects.
## Tcl commands to replicate state of the init_hv_balance property.
# init_hv_balance has default value for all objects.
## Tcl commands to replicate state of the init_image property.
# init_image has default value for all objects.
## Tcl commands to replicate state of the init_image_directory property.
# init_image_directory has default value for all objects.
## Tcl commands to replicate state of the init_insertion_delay property.
# init_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the init_insertion_delay_wire property.
# init_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the init_inverting property.
# init_inverting has default value for all objects.
## Tcl commands to replicate state of the init_is_clone property.
# init_is_clone has default value for all objects.
## Tcl commands to replicate state of the init_last_effective_sinks property.
# init_last_effective_sinks has default value for all objects.
## Tcl commands to replicate state of the init_layer_density property.
# init_layer_density has default value for all objects.
## Tcl commands to replicate state of the init_locked_originally property.
# init_locked_originally has default value for all objects.
## Tcl commands to replicate state of the init_max_driver_distance property.
# init_max_driver_distance has default value for all objects.
## Tcl commands to replicate state of the init_max_root_distance property.
# init_max_root_distance has default value for all objects.
## Tcl commands to replicate state of the init_maximum_insertion_delay property.
# init_maximum_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the init_maximum_stage_depth property.
# init_maximum_stage_depth has default value for all objects.
## Tcl commands to replicate state of the init_mode property.
# init_mode has default value for all objects.
## Tcl commands to replicate state of the init_net_unbufferable_flags property.
# init_net_unbufferable_flags has default value for all objects.
## Tcl commands to replicate state of the init_no_symmetry_branches property.
# init_no_symmetry_branches has default value for all objects.
## Tcl commands to replicate state of the init_no_symmetry_buffers property.
# init_no_symmetry_buffers has default value for all objects.
## Tcl commands to replicate state of the init_offset_x property.
# init_offset_x has default value for all objects.
## Tcl commands to replicate state of the init_offset_y property.
# init_offset_y has default value for all objects.
## Tcl commands to replicate state of the init_original_names property.
# init_original_names has default value for all objects.
## Tcl commands to replicate state of the init_partition_boundary_inverting property.
# init_partition_boundary_inverting has default value for all objects.
## Tcl commands to replicate state of the init_partition_groups property.
# init_partition_groups has default value for all objects.
## Tcl commands to replicate state of the init_pin property.
# init_pin has default value for all objects.
## Tcl commands to replicate state of the init_power_weight property.
# init_power_weight has default value for all objects.
## Tcl commands to replicate state of the init_pre_routed property.
# init_pre_routed has default value for all objects.
## Tcl commands to replicate state of the init_preferred_min_split_level property.
# init_preferred_min_split_level has default value for all objects.
## Tcl commands to replicate state of the init_prioritize_driver_levels property.
# init_prioritize_driver_levels has default value for all objects.
## Tcl commands to replicate state of the init_route_topology property.
# init_route_topology has default value for all objects.
## Tcl commands to replicate state of the init_routing_override property.
# init_routing_override has default value for all objects.
## Tcl commands to replicate state of the init_routing_top_fanout_count property.
# init_routing_top_fanout_count has default value for all objects.
## Tcl commands to replicate state of the init_single_driver_per_grid_point property.
# init_single_driver_per_grid_point has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid property.
# init_sink_grid has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid_box property.
# init_sink_grid_box has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid_exclusion_zones property.
# init_sink_grid_exclusion_zones has default value for all objects.
## Tcl commands to replicate state of the init_sink_grid_sink_area property.
# init_sink_grid_sink_area has default value for all objects.
## Tcl commands to replicate state of the init_sink_instance_prefix property.
# init_sink_instance_prefix has default value for all objects.
## Tcl commands to replicate state of the init_sink_pin_merge_area property.
# init_sink_pin_merge_area has default value for all objects.
## Tcl commands to replicate state of the init_skew_group_insertion_delay property.
# init_skew_group_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the init_skew_group_insertion_delay_wire property.
# init_skew_group_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the init_skew_group_source_latency property.
# init_skew_group_source_latency has default value for all objects.
## Tcl commands to replicate state of the init_source_group_clock_trees property.
# init_source_group_clock_trees has default value for all objects.
## Tcl commands to replicate state of the init_stop_at_sdc_clock_roots property.
# init_stop_at_sdc_clock_roots has default value for all objects.
## Tcl commands to replicate state of the init_symmetric_bottom_level_merge_direction property.
# init_symmetric_bottom_level_merge_direction has default value for all objects.
## Tcl commands to replicate state of the init_target_centers property.
# init_target_centers has default value for all objects.
## Tcl commands to replicate state of the init_trunk_cell property.
# init_trunk_cell has default value for all objects.
## Tcl commands to replicate state of the init_user_skew_group property.
# init_user_skew_group has default value for all objects.
## Tcl commands to replicate state of the init_virtual_delay property.
# init_virtual_delay has default value for all objects.
## Tcl commands to replicate state of the initialize_cte_for_aae_mode property.
# initialize_cte_for_aae_mode has default value.
## Tcl commands to replicate state of the insert_source_group_roots_verbose_balancer_initialize property.
# insert_source_group_roots_verbose_balancer_initialize has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_clone_at_leaf property.
# insertion_delay_outlier_clone_at_leaf has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_iteration_db_prefix property.
# insertion_delay_outlier_iteration_db_prefix has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_iteration_limit property.
# insertion_delay_outlier_iteration_limit has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_min_num_skew_group_sinks property.
# insertion_delay_outlier_min_num_skew_group_sinks has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_standard_deviation_factor property.
# insertion_delay_outlier_standard_deviation_factor has default value.
## Tcl commands to replicate state of the insertion_delay_outlier_try_cloning property.
# insertion_delay_outlier_try_cloning has default value.
## Tcl commands to replicate state of the inst_name_prefix property.
# inst_name_prefix has default value.
## Tcl commands to replicate state of the integration property.
# integration has default value.
## Tcl commands to replicate state of the invalidate_timing_graph_after_disconnect_clock_trees property.
# invalidate_timing_graph_after_disconnect_clock_trees has default value.
## Tcl commands to replicate state of the inverter_cells property.
# inverter_cells has default value for all objects.
## Tcl commands to replicate state of the io_iterations property.
# io_iterations has default value.
## Tcl commands to replicate state of the is_clone property.
# is_clone has default value for all objects.
## Tcl commands to replicate state of the keep_clock_gates_in_same_family property.
# keep_clock_gates_in_same_family has default value.
## Tcl commands to replicate state of the keep_global_routes_after_post_conditioning property.
# keep_global_routes_after_post_conditioning has default value.
## Tcl commands to replicate state of the keep_global_routes_source_sink_length_delta property.
# keep_global_routes_source_sink_length_delta has default value.
## Tcl commands to replicate state of the keep_global_routes_total_length_delta property.
# keep_global_routes_total_length_delta has default value.
## Tcl commands to replicate state of the keep_global_routes_where_lengths_differ property.
# keep_global_routes_where_lengths_differ has default value.
## Tcl commands to replicate state of the last_effective_sinks property.
# last_effective_sinks has default value for all objects.
## Tcl commands to replicate state of the last_target_insertion_delay property.
set_ccopt_property last_target_insertion_delay -skew_group icts.clk/cons_mode 0.10266
set_ccopt_property last_target_insertion_delay -skew_group fragment.1 0.0753
## Tcl commands to replicate state of the last_target_insertion_delay_wire property.
# last_target_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the last_target_max_trans property.
set_ccopt_property last_target_max_trans -clock_tree clk -delay_corner slow_delay -net_type leaf -power_domain auto-default -late 0.4
set_ccopt_property last_target_max_trans -clock_tree clk -delay_corner fast_delay -net_type leaf -power_domain auto-default -late 0.4
set_ccopt_property last_target_max_trans -clock_tree clk -delay_corner slow_delay -net_type trunk -power_domain auto-default -late 0.4
set_ccopt_property last_target_max_trans -clock_tree clk -delay_corner fast_delay -net_type trunk -power_domain auto-default -late 0.4
set_ccopt_property last_target_max_trans -clock_tree clk -delay_corner slow_delay -net_type top -power_domain auto-default -late 0.4
set_ccopt_property last_target_max_trans -clock_tree clk -delay_corner fast_delay -net_type top -power_domain auto-default -late 0.4
## Tcl commands to replicate state of the last_target_skew property.
set_ccopt_property last_target_skew -delay_corner slow_delay -skew_group default.clk/cons_mode -early default
set_ccopt_property last_target_skew -delay_corner slow_delay -skew_group default.clk/cons_mode -late 0.15408
set_ccopt_property last_target_skew -delay_corner fast_delay -skew_group default.clk/cons_mode -early default
set_ccopt_property last_target_skew -delay_corner fast_delay -skew_group default.clk/cons_mode -late 0.1
set_ccopt_property last_target_skew -delay_corner typ_delay -skew_group default.clk/cons_mode -early default
set_ccopt_property last_target_skew -delay_corner typ_delay -skew_group default.clk/cons_mode -late default
set_ccopt_property last_target_skew -delay_corner slow_delay -skew_group icts.clk/cons_mode -early 0.154
set_ccopt_property last_target_skew -delay_corner slow_delay -skew_group icts.clk/cons_mode -late 0.15408
set_ccopt_property last_target_skew -delay_corner fast_delay -skew_group icts.clk/cons_mode -early 0.0598
set_ccopt_property last_target_skew -delay_corner fast_delay -skew_group icts.clk/cons_mode -late 0.1
set_ccopt_property last_target_skew -delay_corner typ_delay -skew_group icts.clk/cons_mode -early 0.0935
set_ccopt_property last_target_skew -delay_corner typ_delay -skew_group icts.clk/cons_mode -late 0.0935
set_ccopt_property last_target_skew -delay_corner slow_delay -skew_group fragment.1 -early 0.0144
set_ccopt_property last_target_skew -delay_corner slow_delay -skew_group fragment.1 -late 0.0144
set_ccopt_property last_target_skew -delay_corner fast_delay -skew_group fragment.1 -early 0.0056
set_ccopt_property last_target_skew -delay_corner fast_delay -skew_group fragment.1 -late 0.0056
set_ccopt_property last_target_skew -delay_corner typ_delay -skew_group fragment.1 -early 0.00876
set_ccopt_property last_target_skew -delay_corner typ_delay -skew_group fragment.1 -late 0.00876
## Tcl commands to replicate state of the last_target_skew_wire property.
set_ccopt_property last_target_skew_wire -delay_corner slow_delay -skew_group default.clk/cons_mode -early default
set_ccopt_property last_target_skew_wire -delay_corner slow_delay -skew_group default.clk/cons_mode -late ignore
set_ccopt_property last_target_skew_wire -delay_corner fast_delay -skew_group default.clk/cons_mode -early default
set_ccopt_property last_target_skew_wire -delay_corner fast_delay -skew_group default.clk/cons_mode -late default
set_ccopt_property last_target_skew_wire -delay_corner typ_delay -skew_group default.clk/cons_mode -early default
set_ccopt_property last_target_skew_wire -delay_corner typ_delay -skew_group default.clk/cons_mode -late default
set_ccopt_property last_target_skew_wire -delay_corner slow_delay -skew_group icts.clk/cons_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner slow_delay -skew_group icts.clk/cons_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner fast_delay -skew_group icts.clk/cons_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner fast_delay -skew_group icts.clk/cons_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner typ_delay -skew_group icts.clk/cons_mode -early 0
set_ccopt_property last_target_skew_wire -delay_corner typ_delay -skew_group icts.clk/cons_mode -late 0
set_ccopt_property last_target_skew_wire -delay_corner slow_delay -skew_group fragment.1 -early 0
set_ccopt_property last_target_skew_wire -delay_corner slow_delay -skew_group fragment.1 -late 0
set_ccopt_property last_target_skew_wire -delay_corner fast_delay -skew_group fragment.1 -early 0
set_ccopt_property last_target_skew_wire -delay_corner fast_delay -skew_group fragment.1 -late 0
set_ccopt_property last_target_skew_wire -delay_corner typ_delay -skew_group fragment.1 -early 0
set_ccopt_property last_target_skew_wire -delay_corner typ_delay -skew_group fragment.1 -late 0
## Tcl commands to replicate state of the leaf_buffer_cells property.
# leaf_buffer_cells has default value for all objects.
## Tcl commands to replicate state of the leaf_inverter_cells property.
# leaf_inverter_cells has default value for all objects.
## Tcl commands to replicate state of the legacy_annotations_mode property.
# legacy_annotations_mode has default value.
## Tcl commands to replicate state of the legalize_on_stripes_throughout_cts property.
# legalize_on_stripes_throughout_cts has default value.
## Tcl commands to replicate state of the legalized_on_clock_spine property.
# legalized_on_clock_spine has default value for all objects.
## Tcl commands to replicate state of the legalizer_placeable_area_use_psp property.
# legalizer_placeable_area_use_psp has default value.
## Tcl commands to replicate state of the liberty_min_max_path_delay_limit_absolute property.
# liberty_min_max_path_delay_limit_absolute has default value.
## Tcl commands to replicate state of the library_trimming property.
# library_trimming has default value.
## Tcl commands to replicate state of the lock_on_clock_spine property.
# lock_on_clock_spine has default value for all objects.
## Tcl commands to replicate state of the locked_originally property.
# locked_originally has default value for all objects.
## Tcl commands to replicate state of the log_special_case_cell_selections property.
# log_special_case_cell_selections has default value.
## Tcl commands to replicate state of the logic_cells property.
# logic_cells has default value for all objects.
## Tcl commands to replicate state of the logic_movement_limit property.
# logic_movement_limit has default value.
## Tcl commands to replicate state of the long_path_removal_cutoff_id property.
# long_path_removal_cutoff_id has default value for all objects.
## Tcl commands to replicate state of the long_path_removal_percentile property.
# long_path_removal_percentile has default value for all objects.
## Tcl commands to replicate state of the long_path_removal_standard_deviation_factor property.
# long_path_removal_standard_deviation_factor has default value for all objects.
## Tcl commands to replicate state of the long_path_removal_uses_min_offset property.
# long_path_removal_uses_min_offset has default value.
## Tcl commands to replicate state of the macro_max_delta_slack_factor property.
# macro_max_delta_slack_factor has default value.
## Tcl commands to replicate state of the macro_max_delta_slack_factor_ideal_mode property.
# macro_max_delta_slack_factor_ideal_mode has default value.
## Tcl commands to replicate state of the maintain_skew_band_occupancy_during_reducing_clock_tree_power_3 property.
# maintain_skew_band_occupancy_during_reducing_clock_tree_power_3 has default value.
## Tcl commands to replicate state of the make_dc_think_everything_needs_recomputing property.
# make_dc_think_everything_needs_recomputing has default value.
## Tcl commands to replicate state of the manage_power_management_illegalities property.
# manage_power_management_illegalities has default value.
## Tcl commands to replicate state of the max_buffer_depth property.
# max_buffer_depth has default value for all objects.
## Tcl commands to replicate state of the max_cell_height property.
# max_cell_height has default value.
## Tcl commands to replicate state of the max_delta_band_factor property.
# max_delta_band_factor has default value.
## Tcl commands to replicate state of the max_delta_band_factor_ideal_mode property.
# max_delta_band_factor_ideal_mode has default value.
## Tcl commands to replicate state of the max_delta_slack_factor property.
# max_delta_slack_factor has default value.
## Tcl commands to replicate state of the max_delta_slack_factor_ideal_mode property.
# max_delta_slack_factor_ideal_mode has default value.
## Tcl commands to replicate state of the max_fanout property.
# max_fanout has default value for all objects.
## Tcl commands to replicate state of the max_hierarchy_colors property.
# max_hierarchy_colors has default value.
## Tcl commands to replicate state of the max_latency_margin property.
# max_latency_margin has default value.
## Tcl commands to replicate state of the max_skew_passes_with_insufficient_progress property.
# max_skew_passes_with_insufficient_progress has default value.
## Tcl commands to replicate state of the max_skew_passes_with_insufficient_progress_consider_single_pass property.
# max_skew_passes_with_insufficient_progress_consider_single_pass has default value.
## Tcl commands to replicate state of the max_skew_passes_with_insufficient_progress_ideal_mode property.
# max_skew_passes_with_insufficient_progress_ideal_mode has default value.
## Tcl commands to replicate state of the max_source_to_sink_net_length property.
# max_source_to_sink_net_length has default value for all objects.
## Tcl commands to replicate state of the max_source_to_sink_net_length_error_multiple property.
# max_source_to_sink_net_length_error_multiple has default value.
## Tcl commands to replicate state of the max_source_to_sink_net_length_warn_multiple property.
# max_source_to_sink_net_length_warn_multiple has default value.
## Tcl commands to replicate state of the max_source_to_sink_net_resistance property.
# max_source_to_sink_net_resistance has default value.
## Tcl commands to replicate state of the maximum_insertion_delay property.
# maximum_insertion_delay has default value for all objects.
## Tcl commands to replicate state of the maximum_stage_depth property.
# maximum_stage_depth has default value for all objects.
## Tcl commands to replicate state of the merge_balancing_drivers_for_power_balancing_only property.
# merge_balancing_drivers_for_power_balancing_only has default value.
## Tcl commands to replicate state of the merge_gates_considers_cell_familes property.
# merge_gates_considers_cell_familes has default value.
## Tcl commands to replicate state of the merge_ignore_sdc property.
# merge_ignore_sdc has default value.
## Tcl commands to replicate state of the merged_clock_gates_survivor_placement property.
# merged_clock_gates_survivor_placement has default value.
## Tcl commands to replicate state of the merging_use_logic_expressions property.
# merging_use_logic_expressions has default value.
## Tcl commands to replicate state of the min_delta_band_factor property.
# min_delta_band_factor has default value.
## Tcl commands to replicate state of the min_delta_band_factor_ideal_mode property.
# min_delta_band_factor_ideal_mode has default value.
## Tcl commands to replicate state of the min_segment_length_for_shielding property.
# min_segment_length_for_shielding has default value.
## Tcl commands to replicate state of the min_trunk_net_bounding_box_hp property.
# min_trunk_net_bounding_box_hp has default value.
## Tcl commands to replicate state of the mini_not_full_band_size_factor property.
set_ccopt_property mini_not_full_band_size_factor 100
## Tcl commands to replicate state of the minimum_skew_target_factor property.
# minimum_skew_target_factor has default value.
## Tcl commands to replicate state of the mixed_buffer_budget property.
# mixed_buffer_budget has default value.
## Tcl commands to replicate state of the mixed_buffer_budget_override property.
# mixed_buffer_budget_override has default value for all objects.
## Tcl commands to replicate state of the mixed_fanout_net_type property.
# mixed_fanout_net_type has default value.
## Tcl commands to replicate state of the move_cells_below_node_before_adding_more_buffers property.
# move_cells_below_node_before_adding_more_buffers has default value.
## Tcl commands to replicate state of the move_clock_gates_band_size property.
# move_clock_gates_band_size has default value.
## Tcl commands to replicate state of the move_clock_nodes_for_slack property.
# move_clock_nodes_for_slack has default value for all objects.
## Tcl commands to replicate state of the move_datapath_while_clock_net_routing property.
# move_datapath_while_clock_net_routing has default value.
## Tcl commands to replicate state of the move_gates_to_siblings_do_sizing property.
# move_gates_to_siblings_do_sizing has default value.
## Tcl commands to replicate state of the move_gates_to_siblings_in_bottom_up_balancing property.
# move_gates_to_siblings_in_bottom_up_balancing has default value.
## Tcl commands to replicate state of the move_gates_to_siblings_in_detailed_balancing property.
# move_gates_to_siblings_in_detailed_balancing has default value.
## Tcl commands to replicate state of the move_global_route_buffers property.
# move_global_route_buffers has default value.
## Tcl commands to replicate state of the move_logic property.
# move_logic has default value.
## Tcl commands to replicate state of the move_middle_cell_first_when_adding_wire_delay property.
# move_middle_cell_first_when_adding_wire_delay has default value.
## Tcl commands to replicate state of the move_power_management_cells property.
# move_power_management_cells has default value.
## Tcl commands to replicate state of the movement_limit property.
# movement_limit has default value for all objects.
## Tcl commands to replicate state of the movement_reports_show_top_n_movements property.
# movement_reports_show_top_n_movements has default value.
## Tcl commands to replicate state of the moving_gates_to_balance_delay_uses_net_lengths_directly property.
# moving_gates_to_balance_delay_uses_net_lengths_directly has default value.
## Tcl commands to replicate state of the nanoroute_tcl_function property.
# nanoroute_tcl_function has default value.
## Tcl commands to replicate state of the neg_unate_arcs_count_half_for_stage_depth_counting property.
# neg_unate_arcs_count_half_for_stage_depth_counting has default value.
## Tcl commands to replicate state of the neg_unate_arcs_count_half_towards_maximum_stage_depth property.
set_ccopt_property neg_unate_arcs_count_half_towards_maximum_stage_depth 0
## Tcl commands to replicate state of the net_name_prefix property.
# net_name_prefix has default value.
## Tcl commands to replicate state of the net_unbufferable_flags property.
# net_unbufferable_flags has default value for all objects.
## Tcl commands to replicate state of the net_violation_report_show_top_n_violations property.
# net_violation_report_show_top_n_violations has default value.
## Tcl commands to replicate state of the netlist_add_hterm_batch_size property.
# netlist_add_hterm_batch_size has default value.
## Tcl commands to replicate state of the netlist_cache_cellinst_touches_preroute property.
# netlist_cache_cellinst_touches_preroute has default value.
## Tcl commands to replicate state of the netlist_consider_assigns_in_cte_constraints property.
# netlist_consider_assigns_in_cte_constraints has default value.
## Tcl commands to replicate state of the netlist_replace_cell_physical_term_invalidate_route property.
# netlist_replace_cell_physical_term_invalidate_route has default value.
## Tcl commands to replicate state of the next_stage_cap_estimate_pin_cap_factor property.
# next_stage_cap_estimate_pin_cap_factor has default value.
## Tcl commands to replicate state of the non_default_routing_rule_propagation_behaviour property.
# non_default_routing_rule_propagation_behaviour has default value.
## Tcl commands to replicate state of the only_use_aon_cells_if_in_cpf property.
# only_use_aon_cells_if_in_cpf has default value.
## Tcl commands to replicate state of the opt_enable_cloning property.
# opt_enable_cloning has default value.
## Tcl commands to replicate state of the opt_ignore property.
# opt_ignore has default value for all objects.
## Tcl commands to replicate state of the optimize_leaf_net_placement property.
# optimize_leaf_net_placement has default value.
## Tcl commands to replicate state of the original_names property.
# original_names has default value for all objects.
## Tcl commands to replicate state of the override_minimum_max_trans_target property.
# override_minimum_max_trans_target has default value.
## Tcl commands to replicate state of the override_minimum_skew_target property.
# override_minimum_skew_target has default value.
## Tcl commands to replicate state of the override_minimum_stage_delay property.
# override_minimum_stage_delay has default value.
## Tcl commands to replicate state of the override_modify_clock_latency property.
# override_modify_clock_latency has default value.
## Tcl commands to replicate state of the override_vias property.
# override_vias has default value.
## Tcl commands to replicate state of the override_zero_placeable_area property.
# override_zero_placeable_area has default value.
## Tcl commands to replicate state of the pathoptimization_task_throttle_denominator property.
# pathoptimization_task_throttle_denominator has default value.
## Tcl commands to replicate state of the per_stage_total_delay_limit property.
# per_stage_total_delay_limit has default value.
## Tcl commands to replicate state of the per_stage_total_delay_limit_halved_for_inverting_stages property.
# per_stage_total_delay_limit_halved_for_inverting_stages has default value.
## Tcl commands to replicate state of the per_stage_wire_delay_limit property.
# per_stage_wire_delay_limit has default value.
## Tcl commands to replicate state of the per_stage_wire_delay_limit_halved_for_inverting_stages property.
# per_stage_wire_delay_limit_halved_for_inverting_stages has default value.
## Tcl commands to replicate state of the pin_allow_buffering property.
# pin_allow_buffering has default value for all objects.
## Tcl commands to replicate state of the pin_alternative_route_types property.
# pin_alternative_route_types has default value for all objects.
## Tcl commands to replicate state of the pin_route_type property.
# pin_route_type has default value for all objects.
## Tcl commands to replicate state of the pin_target_max_trans property.
# pin_target_max_trans has default value for all objects.
## Tcl commands to replicate state of the pin_use_inverters property.
# pin_use_inverters has default value for all objects.
## Tcl commands to replicate state of the place_detail_method_add_source_group_roots property.
# place_detail_method_add_source_group_roots has default value.
## Tcl commands to replicate state of the place_detail_method_after_clustering property.
# place_detail_method_after_clustering has default value.
## Tcl commands to replicate state of the place_detail_method_after_implementation property.
# place_detail_method_after_implementation has default value.
## Tcl commands to replicate state of the place_detail_method_before_cts property.
# place_detail_method_before_cts has default value.
## Tcl commands to replicate state of the place_detail_method_early_global_post_conditioning property.
# place_detail_method_early_global_post_conditioning has default value.
## Tcl commands to replicate state of the place_detail_method_flexible_htree property.
# place_detail_method_flexible_htree has default value.
## Tcl commands to replicate state of the place_detail_method_initial_global_post_conditioning property.
# place_detail_method_initial_global_post_conditioning has default value.
## Tcl commands to replicate state of the place_detail_method_post_conditioning property.
# place_detail_method_post_conditioning has default value.
## Tcl commands to replicate state of the place_detail_method_post_route property.
# place_detail_method_post_route has default value.
## Tcl commands to replicate state of the place_driver_in_center_of_fanout property.
# place_driver_in_center_of_fanout has default value.
## Tcl commands to replicate state of the place_read_only property.
# place_read_only has default value.
## Tcl commands to replicate state of the place_use_far_eye_optimization property.
# place_use_far_eye_optimization has default value.
## Tcl commands to replicate state of the place_use_partial_cleanup property.
# place_use_partial_cleanup has default value.
## Tcl commands to replicate state of the place_use_reset_site_arr property.
# place_use_reset_site_arr has default value.
## Tcl commands to replicate state of the place_use_tcl_mode_setting property.
# place_use_tcl_mode_setting has default value.
## Tcl commands to replicate state of the placeable_region_is_overlap_ok property.
# placeable_region_is_overlap_ok has default value.
## Tcl commands to replicate state of the port_preservation_store property.
set_ccopt_property port_preservation_store {}
## Tcl commands to replicate state of the port_preservation_store_allow_location_on_any_port property.
# port_preservation_store_allow_location_on_any_port has default value.
## Tcl commands to replicate state of the post_conditioning property.
# post_conditioning has default value.
## Tcl commands to replicate state of the post_conditioning_auto_set_longest_path_removal_thresholds property.
# post_conditioning_auto_set_longest_path_removal_thresholds has default value.
## Tcl commands to replicate state of the post_conditioning_auto_set_longest_path_removal_thresholds_factor property.
# post_conditioning_auto_set_longest_path_removal_thresholds_factor has default value.
## Tcl commands to replicate state of the post_conditioning_clone_and_divide_overslew_threshold property.
# post_conditioning_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the post_conditioning_debug_second_pass property.
# post_conditioning_debug_second_pass has default value.
## Tcl commands to replicate state of the post_conditioning_downsize_algorithm_passes property.
# post_conditioning_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the post_conditioning_downsize_algorithm_use_single_step property.
# post_conditioning_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the post_conditioning_downsize_slew_target_multiplier property.
# post_conditioning_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the post_conditioning_enable_average_id_reduction property.
# post_conditioning_enable_average_id_reduction has default value.
## Tcl commands to replicate state of the post_conditioning_enable_clone_and_divide property.
# post_conditioning_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the post_conditioning_enable_delete property.
# post_conditioning_enable_delete has default value.
## Tcl commands to replicate state of the post_conditioning_enable_downsizing_pass property.
# post_conditioning_enable_downsizing_pass has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_fixing property.
# post_conditioning_enable_drv_fixing has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_fixing_by_rebuffering property.
# post_conditioning_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_fixing_with_restructuring property.
# post_conditioning_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the post_conditioning_enable_drv_initial_sizing property.
# post_conditioning_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the post_conditioning_enable_initial_downsizing_pass property.
# post_conditioning_enable_initial_downsizing_pass has default value.
## Tcl commands to replicate state of the post_conditioning_enable_initial_fixing_long_paths property.
# post_conditioning_enable_initial_fixing_long_paths has default value.
## Tcl commands to replicate state of the post_conditioning_enable_max_length_checks property.
# post_conditioning_enable_max_length_checks has default value.
## Tcl commands to replicate state of the post_conditioning_enable_move_down property.
# post_conditioning_enable_move_down has default value.
## Tcl commands to replicate state of the post_conditioning_enable_routing_eco property.
# post_conditioning_enable_routing_eco has default value.
## Tcl commands to replicate state of the post_conditioning_enable_skew_fixing property.
# post_conditioning_enable_skew_fixing has default value.
## Tcl commands to replicate state of the post_conditioning_enable_skew_fixing_by_rebuffering property.
# post_conditioning_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the post_conditioning_enable_timing_update property.
# post_conditioning_enable_timing_update has default value.
## Tcl commands to replicate state of the post_conditioning_initial_cte_update property.
# post_conditioning_initial_cte_update has default value.
## Tcl commands to replicate state of the post_conditioning_keep_route_buffering_best_solution property.
# post_conditioning_keep_route_buffering_best_solution has default value.
## Tcl commands to replicate state of the post_conditioning_max_cell_move property.
# post_conditioning_max_cell_move has default value.
## Tcl commands to replicate state of the post_conditioning_remove_longest_paths property.
# post_conditioning_remove_longest_paths has default value.
## Tcl commands to replicate state of the post_conditioning_remove_longest_paths_after_drv_fixing property.
# post_conditioning_remove_longest_paths_after_drv_fixing has default value.
## Tcl commands to replicate state of the post_conditioning_reroute_clock_tree property.
# post_conditioning_reroute_clock_tree has default value.
## Tcl commands to replicate state of the post_conditioning_route_select_entire_clock_tree property.
# post_conditioning_route_select_entire_clock_tree has default value.
## Tcl commands to replicate state of the post_conditioning_save_datapath_trialroutes property.
# post_conditioning_save_datapath_trialroutes has default value.
## Tcl commands to replicate state of the post_conditioning_slew_fix_sizing_preserve_skew property.
# post_conditioning_slew_fix_sizing_preserve_skew has default value.
## Tcl commands to replicate state of the post_conditioning_speed_up_cell_sizing property.
# post_conditioning_speed_up_cell_sizing has default value.
## Tcl commands to replicate state of the post_conditioning_trial_route_when_nanoroute_disabled property.
# post_conditioning_trial_route_when_nanoroute_disabled has default value.
## Tcl commands to replicate state of the post_conditioning_uses_inst_based_legalization property.
# post_conditioning_uses_inst_based_legalization has default value.
## Tcl commands to replicate state of the post_conditioning_verify_legal property.
# post_conditioning_verify_legal has default value.
## Tcl commands to replicate state of the post_cts_callback property.
# post_cts_callback has default value.
## Tcl commands to replicate state of the post_route_leave_clock_tree_cells_placed property.
# post_route_leave_clock_tree_cells_placed has default value.
## Tcl commands to replicate state of the power_effort property.
# power_effort has default value.
## Tcl commands to replicate state of the power_effort_activity_driven property.
# power_effort_activity_driven has default value.
## Tcl commands to replicate state of the pre_routed property.
# pre_routed has default value for all objects.
## Tcl commands to replicate state of the prefer_trunk_routing_for_rams property.
# prefer_trunk_routing_for_rams has default value.
## Tcl commands to replicate state of the preferred_extra_space property.
# preferred_extra_space has default value for all objects.
## Tcl commands to replicate state of the preserve_enable_latch_clock_inverters property.
# preserve_enable_latch_clock_inverters has default value.
## Tcl commands to replicate state of the prim_dijkstra_factor property.
# prim_dijkstra_factor has default value for all objects.
## Tcl commands to replicate state of the prim_dijkstra_factor_for_clustering property.
# prim_dijkstra_factor_for_clustering has default value for all objects.
## Tcl commands to replicate state of the primary_reporting_skew_groups property.
# primary_reporting_skew_groups has default value.
## Tcl commands to replicate state of the primary_reporting_skew_groups_log_min_max_sinks property.
# primary_reporting_skew_groups_log_min_max_sinks has default value.
## Tcl commands to replicate state of the pro_auto_bypass_place_and_route property.
# pro_auto_bypass_place_and_route has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds property.
# pro_auto_set_longest_path_removal_thresholds has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds_downsizing property.
# pro_auto_set_longest_path_removal_thresholds_downsizing has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds_factor property.
# pro_auto_set_longest_path_removal_thresholds_factor has default value.
## Tcl commands to replicate state of the pro_auto_set_longest_path_removal_thresholds_factor_downsizing property.
# pro_auto_set_longest_path_removal_thresholds_factor_downsizing has default value.
## Tcl commands to replicate state of the pro_buffer_move_candidate_location_count property.
# pro_buffer_move_candidate_location_count has default value.
## Tcl commands to replicate state of the pro_buffering_full_search_minimum_fraction_overslew_to_fix property.
# pro_buffering_full_search_minimum_fraction_overslew_to_fix has default value.
## Tcl commands to replicate state of the pro_buffering_minimum_fraction_overslew_to_fix property.
# pro_buffering_minimum_fraction_overslew_to_fix has default value.
## Tcl commands to replicate state of the pro_can_move_datapath_insts property.
# pro_can_move_datapath_insts has default value.
## Tcl commands to replicate state of the pro_check_parents_for_slew_changes property.
# pro_check_parents_for_slew_changes has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_can_clone_clock_gates property.
# pro_clone_and_divide_can_clone_clock_gates has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_max_move_for_downsize_in_microns property.
# pro_clone_and_divide_max_move_for_downsize_in_microns has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_max_move_in_microns property.
# pro_clone_and_divide_max_move_in_microns has default value.
## Tcl commands to replicate state of the pro_clone_and_divide_overslew_threshold property.
# pro_clone_and_divide_overslew_threshold has default value.
## Tcl commands to replicate state of the pro_cte_identify_clock_tree_at_start property.
# pro_cte_identify_clock_tree_at_start has default value.
## Tcl commands to replicate state of the pro_disable_power_net_select_fix property.
# pro_disable_power_net_select_fix has default value.
## Tcl commands to replicate state of the pro_downsize_algorithm_passes property.
# pro_downsize_algorithm_passes has default value.
## Tcl commands to replicate state of the pro_downsize_algorithm_use_single_step property.
# pro_downsize_algorithm_use_single_step has default value.
## Tcl commands to replicate state of the pro_downsize_id_threshold property.
# pro_downsize_id_threshold has default value.
## Tcl commands to replicate state of the pro_downsize_skip_close_to_target property.
# pro_downsize_skip_close_to_target has default value.
## Tcl commands to replicate state of the pro_downsize_slew_target_multiplier property.
# pro_downsize_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_drv_buffering_downsize_root property.
# pro_drv_buffering_downsize_root has default value.
## Tcl commands to replicate state of the pro_drv_buffering_second_pass_number_to_keep property.
# pro_drv_buffering_second_pass_number_to_keep has default value.
## Tcl commands to replicate state of the pro_enable_alt_flow property.
# pro_enable_alt_flow has default value.
## Tcl commands to replicate state of the pro_enable_clone_and_divide property.
# pro_enable_clone_and_divide has default value.
## Tcl commands to replicate state of the pro_enable_constraint_analysis_during_skew_sizing property.
# pro_enable_constraint_analysis_during_skew_sizing has default value.
## Tcl commands to replicate state of the pro_enable_delete property.
# pro_enable_delete has default value.
## Tcl commands to replicate state of the pro_enable_downsizing_pass property.
# pro_enable_downsizing_pass has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_by_cell_sizing_full property.
# pro_enable_drv_fixing_by_cell_sizing_full has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_by_rebuffering property.
# pro_enable_drv_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_by_rebuffering_second_pass property.
# pro_enable_drv_fixing_by_rebuffering_second_pass has default value.
## Tcl commands to replicate state of the pro_enable_drv_fixing_with_restructuring property.
# pro_enable_drv_fixing_with_restructuring has default value.
## Tcl commands to replicate state of the pro_enable_drv_initial_sizing property.
# pro_enable_drv_initial_sizing has default value.
## Tcl commands to replicate state of the pro_enable_initial_downsizing_pass property.
# pro_enable_initial_downsizing_pass has default value.
## Tcl commands to replicate state of the pro_enable_internals_timing_update property.
# pro_enable_internals_timing_update has default value.
## Tcl commands to replicate state of the pro_enable_max_fanout_fixing property.
# pro_enable_max_fanout_fixing has default value.
## Tcl commands to replicate state of the pro_enable_max_length_checks property.
# pro_enable_max_length_checks has default value.
## Tcl commands to replicate state of the pro_enable_move_down property.
# pro_enable_move_down has default value.
## Tcl commands to replicate state of the pro_enable_post_commit_delay_update property.
set_ccopt_property pro_enable_post_commit_delay_update 1
## Tcl commands to replicate state of the pro_enable_quick_buffer property.
# pro_enable_quick_buffer has default value.
## Tcl commands to replicate state of the pro_enable_recompute_for_slack property.
# pro_enable_recompute_for_slack has default value.
## Tcl commands to replicate state of the pro_enable_route_buffering_on_bus_nets property.
# pro_enable_route_buffering_on_bus_nets has default value.
## Tcl commands to replicate state of the pro_enable_skew_fixing_by_rebuffering property.
# pro_enable_skew_fixing_by_rebuffering has default value.
## Tcl commands to replicate state of the pro_force_allow_datapath_overlap property.
# pro_force_allow_datapath_overlap has default value.
## Tcl commands to replicate state of the pro_global_route_vg_buffering property.
# pro_global_route_vg_buffering has default value.
## Tcl commands to replicate state of the pro_id_reduction_lower_threshold property.
# pro_id_reduction_lower_threshold has default value.
## Tcl commands to replicate state of the pro_id_reduction_top_down property.
# pro_id_reduction_top_down has default value.
## Tcl commands to replicate state of the pro_id_reduction_upper_threshold property.
# pro_id_reduction_upper_threshold has default value.
## Tcl commands to replicate state of the pro_infer_routing_info property.
# pro_infer_routing_info has default value.
## Tcl commands to replicate state of the pro_internals_timing_update_everything property.
# pro_internals_timing_update_everything has default value.
## Tcl commands to replicate state of the pro_invalidate_timing_at_start property.
# pro_invalidate_timing_at_start has default value.
## Tcl commands to replicate state of the pro_invalidate_timing_when_resizing property.
# pro_invalidate_timing_when_resizing has default value.
## Tcl commands to replicate state of the pro_max_cell_move property.
# pro_max_cell_move has default value.
## Tcl commands to replicate state of the pro_max_nodes_in_slew_diagnostics_report property.
# pro_max_nodes_in_slew_diagnostics_report has default value.
## Tcl commands to replicate state of the pro_min_clock_tree_routed_fraction property.
# pro_min_clock_tree_routed_fraction has default value.
## Tcl commands to replicate state of the pro_minimum_overslew_to_fix_ps property.
# pro_minimum_overslew_to_fix_ps has default value.
## Tcl commands to replicate state of the pro_move_down_permitted_bounding_box_reduction property.
# pro_move_down_permitted_bounding_box_reduction has default value.
## Tcl commands to replicate state of the pro_move_gate_slew_target_multiplier property.
# pro_move_gate_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_null_op_timing_change_margin property.
# pro_null_op_timing_change_margin has default value.
## Tcl commands to replicate state of the pro_optimization_slew_target_multiplier property.
# pro_optimization_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_overlap_dont_care_threshold property.
# pro_overlap_dont_care_threshold has default value.
## Tcl commands to replicate state of the pro_overlap_multiplier property.
# pro_overlap_multiplier has default value.
## Tcl commands to replicate state of the pro_recompute_icts_targets property.
# pro_recompute_icts_targets has default value.
## Tcl commands to replicate state of the pro_recompute_implementation_windows property.
# pro_recompute_implementation_windows has default value.
## Tcl commands to replicate state of the pro_remove_longest_paths property.
# pro_remove_longest_paths has default value.
## Tcl commands to replicate state of the pro_remove_longest_paths_after_drv_fixing property.
# pro_remove_longest_paths_after_drv_fixing has default value.
## Tcl commands to replicate state of the pro_remove_longest_paths_downsizing property.
# pro_remove_longest_paths_downsizing has default value.
## Tcl commands to replicate state of the pro_report_routing_correlation property.
# pro_report_routing_correlation has default value.
## Tcl commands to replicate state of the pro_report_timing_at_start property.
# pro_report_timing_at_start has default value.
## Tcl commands to replicate state of the pro_required_slew_outlier_factor property.
# pro_required_slew_outlier_factor has default value.
## Tcl commands to replicate state of the pro_reset_all_bufferability property.
# pro_reset_all_bufferability has default value.
## Tcl commands to replicate state of the pro_respect_cell_density_and_adjacent_row_legal property.
# pro_respect_cell_density_and_adjacent_row_legal has default value.
## Tcl commands to replicate state of the pro_route_buffering_prune_number_to_keep property.
# pro_route_buffering_prune_number_to_keep has default value.
## Tcl commands to replicate state of the pro_sanitize_min_max_delays property.
# pro_sanitize_min_max_delays has default value.
## Tcl commands to replicate state of the pro_semi_skew_safe property.
# pro_semi_skew_safe has default value.
## Tcl commands to replicate state of the pro_semi_skew_safe_permitted_id_fraction_increase property.
# pro_semi_skew_safe_permitted_id_fraction_increase has default value.
## Tcl commands to replicate state of the pro_semi_skew_safe_permitted_id_increase property.
# pro_semi_skew_safe_permitted_id_increase has default value.
## Tcl commands to replicate state of the pro_skew_aware_drv_buffering property.
# pro_skew_aware_drv_buffering has default value.
## Tcl commands to replicate state of the pro_skew_fix_buffer_overdelay property.
# pro_skew_fix_buffer_overdelay has default value.
## Tcl commands to replicate state of the pro_skew_fix_buffer_underdelay property.
# pro_skew_fix_buffer_underdelay has default value.
## Tcl commands to replicate state of the pro_skew_fix_longest property.
# pro_skew_fix_longest has default value.
## Tcl commands to replicate state of the pro_skew_fix_max_buffer_attempts_per_net property.
# pro_skew_fix_max_buffer_attempts_per_net has default value.
## Tcl commands to replicate state of the pro_skew_fix_max_outer_loop_iterations property.
# pro_skew_fix_max_outer_loop_iterations has default value.
## Tcl commands to replicate state of the pro_skew_fix_outer_loop_include_sizing property.
# pro_skew_fix_outer_loop_include_sizing has default value.
## Tcl commands to replicate state of the pro_skew_fix_relax_overdelay_in_final_pass property.
# pro_skew_fix_relax_overdelay_in_final_pass has default value.
## Tcl commands to replicate state of the pro_skew_fix_shortest property.
# pro_skew_fix_shortest has default value.
## Tcl commands to replicate state of the pro_skew_fix_size_driver_when_buffering_sinks property.
# pro_skew_fix_size_driver_when_buffering_sinks has default value.
## Tcl commands to replicate state of the pro_skew_fix_use_fast_buffer property.
# pro_skew_fix_use_fast_buffer has default value.
## Tcl commands to replicate state of the pro_skew_fixing_slew_target_multiplier property.
# pro_skew_fixing_slew_target_multiplier has default value.
## Tcl commands to replicate state of the pro_skew_safe_drv_buffering property.
# pro_skew_safe_drv_buffering has default value.
## Tcl commands to replicate state of the pro_slack_fix_band_size property.
# pro_slack_fix_band_size has default value.
## Tcl commands to replicate state of the pro_slack_fix_max_adjustment_iterations property.
# pro_slack_fix_max_adjustment_iterations has default value.
## Tcl commands to replicate state of the pro_slack_fix_max_slack_to_fix property.
# pro_slack_fix_max_slack_to_fix has default value.
## Tcl commands to replicate state of the pro_slew_change_warning_threshold_ps property.
# pro_slew_change_warning_threshold_ps has default value.
## Tcl commands to replicate state of the pro_slew_fix_sizing_preserve_skew property.
# pro_slew_fix_sizing_preserve_skew has default value.
## Tcl commands to replicate state of the pro_slew_fix_use_new_version property.
# pro_slew_fix_use_new_version has default value.
## Tcl commands to replicate state of the pro_speed_up_cell_sizing property.
# pro_speed_up_cell_sizing has default value.
## Tcl commands to replicate state of the pro_standalone_update_timing_graph_at_start property.
# pro_standalone_update_timing_graph_at_start has default value.
## Tcl commands to replicate state of the pro_update_timing_graph_at_start property.
# pro_update_timing_graph_at_start has default value.
## Tcl commands to replicate state of the pro_use_inst_based_legalization property.
# pro_use_inst_based_legalization has default value.
## Tcl commands to replicate state of the pro_verbose_initialization property.
# pro_verbose_initialization has default value.
## Tcl commands to replicate state of the pro_verify_legal property.
# pro_verify_legal has default value.
## Tcl commands to replicate state of the propagate_slews property.
# propagate_slews has default value.
## Tcl commands to replicate state of the quadrant_clustering_evaluator_bbox_limit_multiplier property.
# quadrant_clustering_evaluator_bbox_limit_multiplier has default value.
## Tcl commands to replicate state of the quadrant_clustering_evaluator_cap_limit_multiplier property.
# quadrant_clustering_evaluator_cap_limit_multiplier has default value.
## Tcl commands to replicate state of the quadrant_clustering_evaluator_fuse_quadrants property.
# quadrant_clustering_evaluator_fuse_quadrants has default value.
## Tcl commands to replicate state of the r2r_iterations property.
set_ccopt_property r2r_iterations 1
## Tcl commands to replicate state of the ratchet_balancer_max_driver_constraint property.
# ratchet_balancer_max_driver_constraint has default value.
## Tcl commands to replicate state of the ratchet_balancer_max_iterations property.
# ratchet_balancer_max_iterations has default value.
## Tcl commands to replicate state of the rctp1_consider_skew property.
# rctp1_consider_skew has default value.
## Tcl commands to replicate state of the rctp3_preserve_skew property.
# rctp3_preserve_skew has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_max_nets_to_consider property.
# rebuffering_skew_fixer_max_nets_to_consider has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_skip_already_improved_nets property.
# rebuffering_skew_fixer_skip_already_improved_nets has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_speed_of_light_multiplier property.
# rebuffering_skew_fixer_speed_of_light_multiplier has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_unit_delay_multiplier_increment property.
# rebuffering_skew_fixer_unit_delay_multiplier_increment has default value.
## Tcl commands to replicate state of the rebuffering_skew_fixer_unit_delay_multiplier_max property.
# rebuffering_skew_fixer_unit_delay_multiplier_max has default value.
## Tcl commands to replicate state of the recluster_ignore_pins property.
# recluster_ignore_pins has default value.
## Tcl commands to replicate state of the recluster_to_reduce_power property.
# recluster_to_reduce_power has default value for all objects.
## Tcl commands to replicate state of the recommit_net_attributes_and_routes_during_resynthesis property.
# recommit_net_attributes_and_routes_during_resynthesis has default value.
## Tcl commands to replicate state of the recompute_slew_target_overrides_after_reduce_clock_tree_power_1 property.
# recompute_slew_target_overrides_after_reduce_clock_tree_power_1 has default value.
## Tcl commands to replicate state of the recycle_unused_ports property.
# recycle_unused_ports has default value.
## Tcl commands to replicate state of the reducing_clock_tree_power_1_fast_mode property.
# reducing_clock_tree_power_1_fast_mode has default value.
## Tcl commands to replicate state of the refine_clock_placement_single_pass property.
# refine_clock_placement_single_pass has default value.
## Tcl commands to replicate state of the refine_place_preserve_affected_routing property.
# refine_place_preserve_affected_routing has default value.
## Tcl commands to replicate state of the remove_bufferlike_clock_logic property.
# remove_bufferlike_clock_logic has default value for all objects.
## Tcl commands to replicate state of the rename_clock_tree_nets property.
# rename_clock_tree_nets has default value.
## Tcl commands to replicate state of the repair_congestion property.
# repair_congestion has default value.
## Tcl commands to replicate state of the report_detailed_legalization property.
# report_detailed_legalization has default value.
## Tcl commands to replicate state of the report_top_notable_deviations_of_routed_length property.
# report_top_notable_deviations_of_routed_length has default value.
## Tcl commands to replicate state of the report_top_wire_delay_differences property.
# report_top_wire_delay_differences has default value.
## Tcl commands to replicate state of the report_total_virtual_delay_in_clock_dag_stats property.
# report_total_virtual_delay_in_clock_dag_stats has default value.
## Tcl commands to replicate state of the report_under_slew_in_clock_dag_stats property.
# report_under_slew_in_clock_dag_stats has default value.
## Tcl commands to replicate state of the report_unplaced_clock_fraction property.
# report_unplaced_clock_fraction has default value.
## Tcl commands to replicate state of the report_unplaced_noclock_fraction property.
# report_unplaced_noclock_fraction has default value.
## Tcl commands to replicate state of the report_worst_chain_after_clustering property.
# report_worst_chain_after_clustering has default value.
## Tcl commands to replicate state of the report_worst_chain_after_implementation property.
# report_worst_chain_after_implementation has default value.
## Tcl commands to replicate state of the report_worst_chain_after_skewing_adjustors property.
# report_worst_chain_after_skewing_adjustors has default value.
## Tcl commands to replicate state of the report_worst_chain_before_clustering property.
# report_worst_chain_before_clustering has default value.
## Tcl commands to replicate state of the report_worst_chain_before_implementation property.
# report_worst_chain_before_implementation has default value.
## Tcl commands to replicate state of the report_worst_chain_before_skewing_adjustors property.
# report_worst_chain_before_skewing_adjustors has default value.
## Tcl commands to replicate state of the reroute_preroute_during_final_implementation property.
# reroute_preroute_during_final_implementation has default value.
## Tcl commands to replicate state of the reset_clock_tree_latencies_even_if_update_io_latency_ran property.
# reset_clock_tree_latencies_even_if_update_io_latency_ran has default value.
## Tcl commands to replicate state of the reset_clock_tree_latencies_use_all_clocks property.
# reset_clock_tree_latencies_use_all_clocks has default value.
## Tcl commands to replicate state of the reset_cppr_info_before_latch_sta_update property.
# reset_cppr_info_before_latch_sta_update has default value.
## Tcl commands to replicate state of the reset_cppr_info_before_slack_update property.
# reset_cppr_info_before_slack_update has default value.
## Tcl commands to replicate state of the reset_extraction_during_update_timing_graph property.
# reset_extraction_during_update_timing_graph has default value.
## Tcl commands to replicate state of the reset_stage_delay_counters_when_write_clock_dag_timing property.
# reset_stage_delay_counters_when_write_clock_dag_timing has default value.
## Tcl commands to replicate state of the resize_gate_requires_a_legal_location property.
# resize_gate_requires_a_legal_location has default value.
## Tcl commands to replicate state of the respect_frequency_dependent_library_constraints property.
# respect_frequency_dependent_library_constraints has default value.
## Tcl commands to replicate state of the respect_library_dont_touch property.
# respect_library_dont_touch has default value.
## Tcl commands to replicate state of the respect_max_toggle_rate property.
# respect_max_toggle_rate has default value.
## Tcl commands to replicate state of the restore_ccopt_config_fast_parse property.
# restore_ccopt_config_fast_parse has default value.
## Tcl commands to replicate state of the restrict_clock_gate_sizing_in_implementation property.
# restrict_clock_gate_sizing_in_implementation has default value.
## Tcl commands to replicate state of the restrict_clock_gate_sizing_in_implementation_threshold property.
# restrict_clock_gate_sizing_in_implementation_threshold has default value.
## Tcl commands to replicate state of the restrict_hold_window_consideration_to_primary_delay_corner property.
# restrict_hold_window_consideration_to_primary_delay_corner has default value.
## Tcl commands to replicate state of the restrict_to_floorplan_core_box property.
# restrict_to_floorplan_core_box has default value.
## Tcl commands to replicate state of the rmax_rmin_scaling_factor property.
# rmax_rmin_scaling_factor has default value.
## Tcl commands to replicate state of the rmax_rminn_num_fanout property.
# rmax_rminn_num_fanout has default value.
## Tcl commands to replicate state of the route_balancing_buffers_with_default_rule property.
# route_balancing_buffers_with_default_rule has default value.
## Tcl commands to replicate state of the route_buffering_choose_best_location_for_preserved_ports property.
# route_buffering_choose_best_location_for_preserved_ports has default value.
## Tcl commands to replicate state of the route_buffering_enable_full_search property.
# route_buffering_enable_full_search has default value.
## Tcl commands to replicate state of the route_buffering_evaluate_null_locations property.
# route_buffering_evaluate_null_locations has default value.
## Tcl commands to replicate state of the route_buffering_minimize_updates property.
# route_buffering_minimize_updates has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_double_driver_accept_reduced property.
# route_buffering_quick_buffer_double_driver_accept_reduced has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_enable_double_driver property.
# route_buffering_quick_buffer_enable_double_driver has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_enable_fanout_search property.
# route_buffering_quick_buffer_enable_fanout_search has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_enable_single_driver property.
# route_buffering_quick_buffer_enable_single_driver has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_single_driver_accept_reduced property.
# route_buffering_quick_buffer_single_driver_accept_reduced has default value.
## Tcl commands to replicate state of the route_buffering_quick_buffer_single_driver_can_use_inverters property.
# route_buffering_quick_buffer_single_driver_can_use_inverters has default value.
## Tcl commands to replicate state of the route_clock_tree_nets_in_length_order property.
# route_clock_tree_nets_in_length_order has default value.
## Tcl commands to replicate state of the route_data_nets_after_clock_net_routing property.
# route_data_nets_after_clock_net_routing has default value.
## Tcl commands to replicate state of the route_global_route_clock_nets_only property.
# route_global_route_clock_nets_only has default value.
## Tcl commands to replicate state of the route_guide_file property.
# route_guide_file has default value.
## Tcl commands to replicate state of the route_ordering_methods property.
# route_ordering_methods has default value.
## Tcl commands to replicate state of the route_ordering_priority property.
# route_ordering_priority has default value for all objects.
## Tcl commands to replicate state of the route_override_settings property.
# route_override_settings has default value.
## Tcl commands to replicate state of the route_preserve_temp_route_guides property.
# route_preserve_temp_route_guides has default value.
## Tcl commands to replicate state of the route_route_guide_record property.
set_ccopt_property route_route_guide_record {egr_output /home/yingna/temp/innovus_temp_50005_pdk5_yingna_rBle3B/.rgfWNOrLX globalDetailRoute /home/yingna/temp/innovus_temp_50005_pdk5_yingna_rBle3B/.rgfWNOrLX}
## Tcl commands to replicate state of the route_topology property.
# route_topology has default value for all objects.
## Tcl commands to replicate state of the route_two_pass property.
# route_two_pass has default value.
## Tcl commands to replicate state of the route_two_pass_leaf_gcell_size property.
# route_two_pass_leaf_gcell_size has default value.
## Tcl commands to replicate state of the route_two_pass_trunk_gcell_size property.
# route_two_pass_trunk_gcell_size has default value.
## Tcl commands to replicate state of the route_type property.
set_ccopt_property route_type -net_type leaf rule_leaf
set_ccopt_property route_type -net_type trunk rule_trunk
set_ccopt_property route_type -net_type top rule_top
set_ccopt_property route_type -clock_tree clk -net_type leaf rule_leaf
set_ccopt_property route_type -clock_tree clk -net_type trunk rule_trunk
set_ccopt_property route_type -clock_tree clk -net_type top rule_top
## Tcl commands to replicate state of the route_type_autotrim property.
# route_type_autotrim has default value.
## Tcl commands to replicate state of the route_type_autotrim_rc_api property.
# route_type_autotrim_rc_api has default value.
## Tcl commands to replicate state of the route_type_autotrim_rc_match property.
# route_type_autotrim_rc_match has default value.
## Tcl commands to replicate state of the route_type_autotrim_rc_match_threshold property.
# route_type_autotrim_rc_match_threshold has default value.
## Tcl commands to replicate state of the route_type_autotrim_res_match_threshold property.
# route_type_autotrim_res_match_threshold has default value.
## Tcl commands to replicate state of the route_type_override_for_clustering property.
# route_type_override_for_clustering has default value for all objects.
## Tcl commands to replicate state of the route_type_override_preferred_routing_layer_effort property.
# route_type_override_preferred_routing_layer_effort has default value.
## Tcl commands to replicate state of the routing_correlation_report_data_file property.
# routing_correlation_report_data_file has default value.
## Tcl commands to replicate state of the routing_correlation_report_low_fanout_cutoff property.
# routing_correlation_report_low_fanout_cutoff has default value.
## Tcl commands to replicate state of the routing_correlation_report_max_net_violation_count property.
# routing_correlation_report_max_net_violation_count has default value.
## Tcl commands to replicate state of the routing_cost_for_preferred_layer_effort_low property.
# routing_cost_for_preferred_layer_effort_low has default value.
## Tcl commands to replicate state of the routing_cost_for_preferred_layer_effort_medium property.
# routing_cost_for_preferred_layer_effort_medium has default value.
## Tcl commands to replicate state of the routing_estimate_egs_avoid_opt_path_on_maze property.
# routing_estimate_egs_avoid_opt_path_on_maze has default value.
## Tcl commands to replicate state of the routing_estimate_egs_opt_path_error_rate property.
# routing_estimate_egs_opt_path_error_rate has default value.
## Tcl commands to replicate state of the routing_estimate_hs_honor_global_topology property.
# routing_estimate_hs_honor_global_topology has default value.
## Tcl commands to replicate state of the routing_estimate_hs_layer_relax_cost property.
# routing_estimate_hs_layer_relax_cost has default value.
## Tcl commands to replicate state of the routing_estimate_hs_skip_unroutable_nets property.
# routing_estimate_hs_skip_unroutable_nets has default value.
## Tcl commands to replicate state of the routing_estimate_hs_use_top_two_layers property.
# routing_estimate_hs_use_top_two_layers has default value.
## Tcl commands to replicate state of the routing_estimate_num_rows_per_gcell property.
# routing_estimate_num_rows_per_gcell has default value.
## Tcl commands to replicate state of the routing_estimate_set_estimated_route_bit property.
# routing_estimate_set_estimated_route_bit has default value.
## Tcl commands to replicate state of the routing_estimate_set_hs_topology property.
# routing_estimate_set_hs_topology has default value.
## Tcl commands to replicate state of the routing_estimate_use_early_global_route_properties property.
# routing_estimate_use_early_global_route_properties has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_escape_pins property.
# routing_estimate_use_hs_escape_pins has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_layer_assignment property.
# routing_estimate_use_hs_layer_assignment has default value.
## Tcl commands to replicate state of the routing_estimate_use_hs_ndr_rule property.
# routing_estimate_use_hs_ndr_rule has default value.
## Tcl commands to replicate state of the routing_override property.
# routing_override has default value for all objects.
## Tcl commands to replicate state of the routing_save_datapath_trialroutes property.
# routing_save_datapath_trialroutes has default value.
## Tcl commands to replicate state of the routing_scale_factors property.
# routing_scale_factors has default value.
## Tcl commands to replicate state of the routing_top_fanout_count property.
# routing_top_fanout_count has default value for all objects.
## Tcl commands to replicate state of the routing_top_min_fanout property.
# routing_top_min_fanout has default value for all objects.
## Tcl commands to replicate state of the routing_use_highest_pin_layer property.
# routing_use_highest_pin_layer has default value.
## Tcl commands to replicate state of the row_height_multiplier_when_cleaning_up_net property.
# row_height_multiplier_when_cleaning_up_net has default value.
## Tcl commands to replicate state of the run_latch_sta_during_slack_update property.
# run_latch_sta_during_slack_update has default value.
## Tcl commands to replicate state of the save_design_in_qthread property.
# save_design_in_qthread has default value.
## Tcl commands to replicate state of the save_state_before_out_of_sync property.
# save_state_before_out_of_sync has default value.
## Tcl commands to replicate state of the scan_reorder property.
# scan_reorder has default value.
## Tcl commands to replicate state of the schedule property.
# schedule has default value for all objects.
## Tcl commands to replicate state of the search_sibling_footprints_for_equivalence property.
# search_sibling_footprints_for_equivalence has default value.
## Tcl commands to replicate state of the set_net_avoid_chaining property.
# set_net_avoid_chaining has default value.
## Tcl commands to replicate state of the set_propagated_clock property.
# set_propagated_clock has default value.
## Tcl commands to replicate state of the set_sink_centroid_as_cluster_center property.
# set_sink_centroid_as_cluster_center has default value.
## Tcl commands to replicate state of the shared_legalizer_enable_legalize_on_move property.
# shared_legalizer_enable_legalize_on_move has default value.
## Tcl commands to replicate state of the show_property_errors_in_get_db property.
# show_property_errors_in_get_db has default value.
## Tcl commands to replicate state of the size_clock_source property.
# size_clock_source has default value for all objects.
## Tcl commands to replicate state of the size_logic property.
# size_logic has default value.
## Tcl commands to replicate state of the skew_band_minimum_adjustors property.
# skew_band_minimum_adjustors has default value.
## Tcl commands to replicate state of the skew_band_size property.
# skew_band_size has default value.
## Tcl commands to replicate state of the skew_group_property_keys_include_mode property.
set_ccopt_property skew_group_property_keys_include_mode 1
## Tcl commands to replicate state of the skew_group_report_columns property.
# skew_group_report_columns has default value.
## Tcl commands to replicate state of the skew_group_report_histogram_bin_size property.
# skew_group_report_histogram_bin_size has default value.
## Tcl commands to replicate state of the skew_pass_sufficient_progress_band_size_factor property.
# skew_pass_sufficient_progress_band_size_factor has default value.
## Tcl commands to replicate state of the skew_pass_sufficient_progress_band_size_factor_ideal_mode property.
# skew_pass_sufficient_progress_band_size_factor_ideal_mode has default value.
## Tcl commands to replicate state of the skew_passes property.
# skew_passes has default value.
## Tcl commands to replicate state of the skew_passes_ideal_mode property.
# skew_passes_ideal_mode has default value.
## Tcl commands to replicate state of the skew_passes_per_band property.
set_ccopt_property skew_passes_per_band 10
## Tcl commands to replicate state of the skew_passes_per_band_ideal_mode property.
# skew_passes_per_band_ideal_mode has default value.
## Tcl commands to replicate state of the skew_passes_per_band_with_latches property.
# skew_passes_per_band_with_latches has default value.
## Tcl commands to replicate state of the skew_passes_per_cluster property.
# skew_passes_per_cluster has default value.
## Tcl commands to replicate state of the skip_initialize_cte_for_aae_with_abstract_stage_delay_analysis property.
# skip_initialize_cte_for_aae_with_abstract_stage_delay_analysis has default value.
## Tcl commands to replicate state of the slew_fixing_start_upsizing_from_current_size property.
# slew_fixing_start_upsizing_from_current_size has default value.
## Tcl commands to replicate state of the small_trans_violation_threshold property.
# small_trans_violation_threshold has default value.
## Tcl commands to replicate state of the source_driver property.
# source_driver has default value for all objects.
## Tcl commands to replicate state of the source_group_clock_trees property.
# source_group_clock_trees has default value for all objects.
## Tcl commands to replicate state of the source_input_max_trans property.
# source_input_max_trans has default value for all objects.
## Tcl commands to replicate state of the source_latency property.
# source_latency has default value for all objects.
## Tcl commands to replicate state of the source_max_capacitance property.
# source_max_capacitance has default value for all objects.
## Tcl commands to replicate state of the source_output_max_trans property.
set_ccopt_property source_output_max_trans -clock_tree clk -delay_corner slow_delay -early 0.15
set_ccopt_property source_output_max_trans -clock_tree clk -delay_corner slow_delay -late 0.2
set_ccopt_property source_output_max_trans -clock_tree clk -delay_corner fast_delay -early 0.15
set_ccopt_property source_output_max_trans -clock_tree clk -delay_corner fast_delay -late 0.2
set_ccopt_property source_output_max_trans -clock_tree clk -delay_corner typ_delay -early 0.15
set_ccopt_property source_output_max_trans -clock_tree clk -delay_corner typ_delay -late 0.2
## Tcl commands to replicate state of the spec_config_map_ideal_nets_and_annotations property.
# spec_config_map_ideal_nets_and_annotations has default value.
## Tcl commands to replicate state of the spec_update_ideal_nets_and_annotations property.
# spec_update_ideal_nets_and_annotations has default value.
## Tcl commands to replicate state of the stack_via_rule property.
# stack_via_rule has default value for all objects.
## Tcl commands to replicate state of the stack_via_rule_required property.
# stack_via_rule_required has default value for all objects.
## Tcl commands to replicate state of the stacktrace_on_impccopt4375 property.
# stacktrace_on_impccopt4375 has default value.
## Tcl commands to replicate state of the stop_before_implementation property.
# stop_before_implementation has default value.
## Tcl commands to replicate state of the stop_before_long_segment_when_cleaning_up_net property.
# stop_before_long_segment_when_cleaning_up_net has default value.
## Tcl commands to replicate state of the stop_before_preferred_layer_when_cleaning_up_net property.
# stop_before_preferred_layer_when_cleaning_up_net has default value.
## Tcl commands to replicate state of the stop_if_clock_trees_modified property.
# stop_if_clock_trees_modified has default value.
## Tcl commands to replicate state of the stop_if_useful_skew_goes_backwards property.
# stop_if_useful_skew_goes_backwards has default value.
## Tcl commands to replicate state of the suppress_timing_updates_after_initial_cluster property.
# suppress_timing_updates_after_initial_cluster has default value.
## Tcl commands to replicate state of the suppress_timing_updates_after_initial_cluster_ideal_mode property.
# suppress_timing_updates_after_initial_cluster_ideal_mode has default value.
## Tcl commands to replicate state of the swapping_buffers_and_inverters_for_power_skip_latency_check property.
# swapping_buffers_and_inverters_for_power_skip_latency_check has default value.
## Tcl commands to replicate state of the target_em_max_capacitance property.
# target_em_max_capacitance has default value for all objects.
## Tcl commands to replicate state of the target_insertion_delay property.
set_ccopt_property target_insertion_delay -skew_group fragment.1 0.0753
## Tcl commands to replicate state of the target_insertion_delay_wire property.
# target_insertion_delay_wire has default value for all objects.
## Tcl commands to replicate state of the target_max_capacitance property.
# target_max_capacitance has default value for all objects.
## Tcl commands to replicate state of the target_max_trans property.
set_ccopt_property target_max_trans -delay_corner fast_delay -late auto
## Tcl commands to replicate state of the target_max_trans_edge property.
# target_max_trans_edge has default value for all objects.
## Tcl commands to replicate state of the target_max_trans_sdc property.
set_ccopt_property target_max_trans_sdc -clock_tree clk -delay_corner fast_delay -early 0.15
set_ccopt_property target_max_trans_sdc -clock_tree clk -delay_corner fast_delay -late 0.4
set_ccopt_property target_max_trans_sdc -clock_tree clk -delay_corner typ_delay -early 0.15
set_ccopt_property target_max_trans_sdc -clock_tree clk -delay_corner typ_delay -late 0.4
set_ccopt_property target_max_trans_sdc -clock_tree clk -delay_corner slow_delay -early 0.15
set_ccopt_property target_max_trans_sdc -clock_tree clk -delay_corner slow_delay -late 0.4
## Tcl commands to replicate state of the target_multi_corner_allowed_insertion_delay_increase property.
# target_multi_corner_allowed_insertion_delay_increase has default value for all objects.
## Tcl commands to replicate state of the target_skew property.
set_ccopt_property target_skew -delay_corner fast_delay -late 0.1
set_ccopt_property target_skew -delay_corner slow_delay -skew_group icts.clk/cons_mode -early default
set_ccopt_property target_skew -delay_corner slow_delay -skew_group icts.clk/cons_mode -late default
set_ccopt_property target_skew -delay_corner fast_delay -skew_group icts.clk/cons_mode -early default
set_ccopt_property target_skew -delay_corner fast_delay -skew_group icts.clk/cons_mode -late 0.1
set_ccopt_property target_skew -delay_corner typ_delay -skew_group icts.clk/cons_mode -early default
set_ccopt_property target_skew -delay_corner typ_delay -skew_group icts.clk/cons_mode -late default
set_ccopt_property target_skew -delay_corner fast_delay -skew_group fragment.1 -late 0.0056
## Tcl commands to replicate state of the target_skew_wire property.
set_ccopt_property target_skew_wire -delay_corner slow_delay -skew_group icts.clk/cons_mode -early default
set_ccopt_property target_skew_wire -delay_corner slow_delay -skew_group icts.clk/cons_mode -late default
set_ccopt_property target_skew_wire -delay_corner fast_delay -skew_group icts.clk/cons_mode -early default
set_ccopt_property target_skew_wire -delay_corner fast_delay -skew_group icts.clk/cons_mode -late default
set_ccopt_property target_skew_wire -delay_corner typ_delay -skew_group icts.clk/cons_mode -early default
set_ccopt_property target_skew_wire -delay_corner typ_delay -skew_group icts.clk/cons_mode -late default
set_ccopt_property target_skew_wire -delay_corner fast_delay -skew_group fragment.1 -late 0
## Tcl commands to replicate state of the threshold_for_design_being_routed property.
# threshold_for_design_being_routed has default value.
## Tcl commands to replicate state of the tighten_max_trans_band_size property.
# tighten_max_trans_band_size has default value.
## Tcl commands to replicate state of the time_clock_tree_disconnected property.
# time_clock_tree_disconnected has default value.
## Tcl commands to replicate state of the timing_connectivity_based_skew_groups property.
# timing_connectivity_based_skew_groups has default value.
## Tcl commands to replicate state of the timing_connectivity_based_skew_groups_balance_master_clocks property.
# timing_connectivity_based_skew_groups_balance_master_clocks has default value.
## Tcl commands to replicate state of the timing_delta property.
set_ccopt_property timing_delta auto
## Tcl commands to replicate state of the top_buffer_cells property.
# top_buffer_cells has default value for all objects.
## Tcl commands to replicate state of the top_inverter_cells property.
# top_inverter_cells has default value for all objects.
## Tcl commands to replicate state of the trace_bidi_as_input property.
# trace_bidi_as_input has default value.
## Tcl commands to replicate state of the trade_right_size_for_delay_factor property.
# trade_right_size_for_delay_factor has default value.
## Tcl commands to replicate state of the trans_violation_report_num_buckets property.
# trans_violation_report_num_buckets has default value.
## Tcl commands to replicate state of the transition_report_in_dag_stats_num_bins property.
# transition_report_in_dag_stats_num_bins has default value.
## Tcl commands to replicate state of the treat_clock_gates_as_logics property.
# treat_clock_gates_as_logics has default value.
## Tcl commands to replicate state of the treat_null_power_domain_as_default property.
# treat_null_power_domain_as_default has default value.
## Tcl commands to replicate state of the treat_special_nets_as_routing_blockages property.
# treat_special_nets_as_routing_blockages has default value.
## Tcl commands to replicate state of the trial_balance_large_virtual_delay_bail_threshold property.
# trial_balance_large_virtual_delay_bail_threshold has default value.
## Tcl commands to replicate state of the trial_balance_large_virtual_delay_factor property.
# trial_balance_large_virtual_delay_factor has default value.
## Tcl commands to replicate state of the trial_balance_sink_driver_bail_threshold property.
# trial_balance_sink_driver_bail_threshold has default value.
## Tcl commands to replicate state of the trial_route_after_commit_net_attributes_and_route_estimates property.
# trial_route_after_commit_net_attributes_and_route_estimates has default value.
## Tcl commands to replicate state of the trial_route_in_synth_clock_trees property.
# trial_route_in_synth_clock_trees has default value.
## Tcl commands to replicate state of the trim_cell_lists_using_cell_properties property.
# trim_cell_lists_using_cell_properties has default value.
## Tcl commands to replicate state of the trunk_override property.
# trunk_override has default value for all objects.
## Tcl commands to replicate state of the try_harder_to_minimize_skew property.
# try_harder_to_minimize_skew has default value for all objects.
## Tcl commands to replicate state of the up_skew_band_size_ideal_mode property.
# up_skew_band_size_ideal_mode has default value.
## Tcl commands to replicate state of the update_io_latency property.
# update_io_latency has default value.
## Tcl commands to replicate state of the update_io_latency_after_implementation property.
# update_io_latency_after_implementation has default value.
## Tcl commands to replicate state of the update_movement_limit_after_clustering property.
# update_movement_limit_after_clustering has default value.
## Tcl commands to replicate state of the update_timing_after_cts property.
# update_timing_after_cts has default value.
## Tcl commands to replicate state of the update_timing_after_resynth property.
# update_timing_after_resynth has default value.
## Tcl commands to replicate state of the uplift_limit property.
# uplift_limit has default value.
## Tcl commands to replicate state of the uplift_max_slack_loss property.
# uplift_max_slack_loss has default value.
## Tcl commands to replicate state of the uplift_min property.
# uplift_min has default value.
## Tcl commands to replicate state of the uplifts_band_size property.
# uplifts_band_size has default value.
## Tcl commands to replicate state of the use_accurate_downstream_capacitance_in_optimization property.
# use_accurate_downstream_capacitance_in_optimization has default value.
## Tcl commands to replicate state of the use_cte_dynamic_constraints property.
# use_cte_dynamic_constraints has default value.
## Tcl commands to replicate state of the use_delayed_legalization property.
# use_delayed_legalization has default value.
## Tcl commands to replicate state of the use_early_global_for_clock_routing property.
# use_early_global_for_clock_routing has default value.
## Tcl commands to replicate state of the use_egr_routes_for_congestion_update property.
# use_egr_routes_for_congestion_update has default value.
## Tcl commands to replicate state of the use_estimated_routes_during_final_implementation property.
# use_estimated_routes_during_final_implementation has default value.
## Tcl commands to replicate state of the use_fast_delay_arc_phase_transform property.
# use_fast_delay_arc_phase_transform has default value.
## Tcl commands to replicate state of the use_guides_with_freedom_regions property.
# use_guides_with_freedom_regions has default value.
## Tcl commands to replicate state of the use_inverters property.
set_ccopt_property use_inverters false
## Tcl commands to replicate state of the use_only_combinational_arcs property.
# use_only_combinational_arcs has default value.
## Tcl commands to replicate state of the use_only_setup_views_for_target_insertion_delay property.
# use_only_setup_views_for_target_insertion_delay has default value.
## Tcl commands to replicate state of the use_optimal_skew_band property.
# use_optimal_skew_band has default value.
## Tcl commands to replicate state of the use_overlay_algorithms_when_single_threaded property.
# use_overlay_algorithms_when_single_threaded has default value.
## Tcl commands to replicate state of the use_receiver_model_capacitance_for_drv property.
# use_receiver_model_capacitance_for_drv has default value.
## Tcl commands to replicate state of the use_receiver_model_capacitance_for_reporting property.
# use_receiver_model_capacitance_for_reporting has default value.
## Tcl commands to replicate state of the use_sdc_annotation_for_ideal_nets property.
# use_sdc_annotation_for_ideal_nets has default value.
## Tcl commands to replicate state of the use_setup_and_hold_views_for_create_clock_tree_spec property.
# use_setup_and_hold_views_for_create_clock_tree_spec has default value.
## Tcl commands to replicate state of the useful_skew_adjust_gates_final_pass_only property.
# useful_skew_adjust_gates_final_pass_only has default value.
## Tcl commands to replicate state of the useful_skew_adjust_macros_first_pass_only property.
# useful_skew_adjust_macros_first_pass_only has default value.
## Tcl commands to replicate state of the useful_skew_adjust_macros_first_pass_only_ideal_mode property.
# useful_skew_adjust_macros_first_pass_only_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_adjust_worst_n_pct_only property.
# useful_skew_adjust_worst_n_pct_only has default value.
## Tcl commands to replicate state of the useful_skew_adjust_worst_n_pct_only_ideal_mode property.
# useful_skew_adjust_worst_n_pct_only_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_adjustment_sequence property.
# useful_skew_adjustment_sequence has default value.
## Tcl commands to replicate state of the useful_skew_align_tns_windows property.
# useful_skew_align_tns_windows has default value.
## Tcl commands to replicate state of the useful_skew_align_tns_windows_min_size property.
# useful_skew_align_tns_windows_min_size has default value.
## Tcl commands to replicate state of the useful_skew_align_tns_windows_quantum property.
# useful_skew_align_tns_windows_quantum has default value.
## Tcl commands to replicate state of the useful_skew_assert_output_pin_network_latencies property.
# useful_skew_assert_output_pin_network_latencies has default value.
## Tcl commands to replicate state of the useful_skew_build_below_clock_gate_skew_groups property.
# useful_skew_build_below_clock_gate_skew_groups has default value.
## Tcl commands to replicate state of the useful_skew_clear_network_latency_map property.
# useful_skew_clear_network_latency_map has default value.
## Tcl commands to replicate state of the useful_skew_clock_gate_movement_limit property.
# useful_skew_clock_gate_movement_limit has default value.
## Tcl commands to replicate state of the useful_skew_clock_gate_window_slack_budget property.
# useful_skew_clock_gate_window_slack_budget has default value.
## Tcl commands to replicate state of the useful_skew_clustering_cache_hold_slacks property.
# useful_skew_clustering_cache_hold_slacks has default value.
## Tcl commands to replicate state of the useful_skew_compute_slack_windows_by_category property.
# useful_skew_compute_slack_windows_by_category has default value.
## Tcl commands to replicate state of the useful_skew_configure_ideal_mode_reference property.
# useful_skew_configure_ideal_mode_reference has default value.
## Tcl commands to replicate state of the useful_skew_convert_default_mode_for_clock_domain_mode property.
# useful_skew_convert_default_mode_for_clock_domain_mode has default value.
## Tcl commands to replicate state of the useful_skew_dont_skew_adjustor_if_unbufferable_children property.
# useful_skew_dont_skew_adjustor_if_unbufferable_children has default value.
## Tcl commands to replicate state of the useful_skew_enable_flop_merge_split_support property.
# useful_skew_enable_flop_merge_split_support has default value.
## Tcl commands to replicate state of the useful_skew_enable_macro_only_passes property.
# useful_skew_enable_macro_only_passes has default value.
## Tcl commands to replicate state of the useful_skew_equalize_offsets_use_chosen_windows property.
set_ccopt_property useful_skew_equalize_offsets_use_chosen_windows 1
## Tcl commands to replicate state of the useful_skew_equalize_offsets_use_chosen_windows_ideal_mode property.
# useful_skew_equalize_offsets_use_chosen_windows_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_export_implementation_windows_file property.
# useful_skew_export_implementation_windows_file has default value.
## Tcl commands to replicate state of the useful_skew_final_db property.
# useful_skew_final_db has default value.
## Tcl commands to replicate state of the useful_skew_hold_threshold_window_size property.
# useful_skew_hold_threshold_window_size has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_as_extra_effort_in_ideal_mode property.
# useful_skew_hyperspace_uplift_as_extra_effort_in_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_as_extra_effort_num_iterations property.
# useful_skew_hyperspace_uplift_as_extra_effort_num_iterations has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_max_fraction_per_subtree property.
# useful_skew_hyperspace_uplift_max_fraction_per_subtree has default value.
## Tcl commands to replicate state of the useful_skew_hyperspace_uplift_try_local_adjustment_first property.
# useful_skew_hyperspace_uplift_try_local_adjustment_first has default value.
## Tcl commands to replicate state of the useful_skew_ideal_delta_opt_on_only property.
# useful_skew_ideal_delta_opt_on_only has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_apply_move_limit property.
# useful_skew_ideal_mode_apply_move_limit has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_early_global_route_clock_nets property.
# useful_skew_ideal_mode_early_global_route_clock_nets has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_early_global_route_for_opus_drv property.
# useful_skew_ideal_mode_early_global_route_for_opus_drv has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_ideal_delta_opt_on_only property.
# useful_skew_ideal_mode_ideal_delta_opt_on_only has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_ignore_bufferability property.
# useful_skew_ideal_mode_ignore_bufferability has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_max_allowed_delay property.
# useful_skew_ideal_mode_max_allowed_delay has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_min_allowed_delay property.
# useful_skew_ideal_mode_min_allowed_delay has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_min_forwarding_skew property.
# useful_skew_ideal_mode_min_forwarding_skew has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_place_detail_method_after_clustering property.
# useful_skew_ideal_mode_place_detail_method_after_clustering has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_reference_aggregate property.
# useful_skew_ideal_mode_reference_aggregate has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_reference_quantum property.
# useful_skew_ideal_mode_reference_quantum has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_set_clock_latency property.
# useful_skew_ideal_mode_set_clock_latency has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_set_clock_latency_on_propagated_mode_clocks property.
# useful_skew_ideal_mode_set_clock_latency_on_propagated_mode_clocks has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_unfix_estimated_clock_routes property.
# useful_skew_ideal_mode_unfix_estimated_clock_routes has default value.
## Tcl commands to replicate state of the useful_skew_ideal_mode_use_fast_trial_balancer property.
# useful_skew_ideal_mode_use_fast_trial_balancer has default value.
## Tcl commands to replicate state of the useful_skew_implement_with_clock_gate_skew_groups property.
# useful_skew_implement_with_clock_gate_skew_groups has default value.
## Tcl commands to replicate state of the useful_skew_implementation_cache_hold_slacks property.
# useful_skew_implementation_cache_hold_slacks has default value.
## Tcl commands to replicate state of the useful_skew_implementation_chosen_window_adjust property.
# useful_skew_implementation_chosen_window_adjust has default value.
## Tcl commands to replicate state of the useful_skew_import_implementation_windows_file property.
# useful_skew_import_implementation_windows_file has default value.
## Tcl commands to replicate state of the useful_skew_incremental_latch_sta property.
# useful_skew_incremental_latch_sta has default value.
## Tcl commands to replicate state of the useful_skew_macro_pin_count_threshold property.
# useful_skew_macro_pin_count_threshold has default value.
## Tcl commands to replicate state of the useful_skew_max_down_skew_fraction_per_round property.
# useful_skew_max_down_skew_fraction_per_round has default value.
## Tcl commands to replicate state of the useful_skew_max_down_skew_fraction_per_round_ideal_mode property.
# useful_skew_max_down_skew_fraction_per_round_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_max_sources_per_clock_gate_skew_group property.
# useful_skew_max_sources_per_clock_gate_skew_group has default value.
## Tcl commands to replicate state of the useful_skew_max_up_skew_fraction_per_round property.
# useful_skew_max_up_skew_fraction_per_round has default value.
## Tcl commands to replicate state of the useful_skew_max_up_skew_fraction_per_round_ideal_mode property.
# useful_skew_max_up_skew_fraction_per_round_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_max_window_down_delay_factor property.
# useful_skew_max_window_down_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_max_window_up_delay_factor property.
# useful_skew_max_window_up_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_min_delta property.
# useful_skew_min_delta has default value.
## Tcl commands to replicate state of the useful_skew_min_wns_window_factor property.
# useful_skew_min_wns_window_factor has default value.
## Tcl commands to replicate state of the useful_skew_minimum_slack_change property.
# useful_skew_minimum_slack_change has default value.
## Tcl commands to replicate state of the useful_skew_multi_corner property.
# useful_skew_multi_corner has default value.
## Tcl commands to replicate state of the useful_skew_node_to_node_pin_insertion_delays property.
# useful_skew_node_to_node_pin_insertion_delays has default value.
## Tcl commands to replicate state of the useful_skew_only_adjust_critical_gigaopt_gates property.
# useful_skew_only_adjust_critical_gigaopt_gates has default value.
## Tcl commands to replicate state of the useful_skew_only_adjust_critical_gigaopt_gates_ideal_mode property.
# useful_skew_only_adjust_critical_gigaopt_gates_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_only_adjust_critical_gigaopt_sinks property.
# useful_skew_only_adjust_critical_gigaopt_sinks has default value.
## Tcl commands to replicate state of the useful_skew_only_adjust_critical_gigaopt_sinks_ideal_mode property.
# useful_skew_only_adjust_critical_gigaopt_sinks_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_overshoot property.
# useful_skew_overshoot has default value.
## Tcl commands to replicate state of the useful_skew_post_clustering_latch_sta property.
set_ccopt_property useful_skew_post_clustering_latch_sta 1
## Tcl commands to replicate state of the useful_skew_postconditioning_check_sibling_slacks property.
# useful_skew_postconditioning_check_sibling_slacks has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_buffer_insertion property.
# useful_skew_postconditioning_enable_buffer_insertion has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_buffer_removal property.
# useful_skew_postconditioning_enable_buffer_removal has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_move_gate property.
# useful_skew_postconditioning_enable_move_gate has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_resize_gate property.
# useful_skew_postconditioning_enable_resize_gate has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_sink_buffering property.
# useful_skew_postconditioning_enable_sink_buffering has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_enable_slack_estimation property.
# useful_skew_postconditioning_enable_slack_estimation has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_initial_min_delay_unit_delay_factor property.
# useful_skew_postconditioning_initial_min_delay_unit_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_iterations property.
# useful_skew_postconditioning_iterations has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_min_delta_factor property.
# useful_skew_postconditioning_min_delta_factor has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_optimizations_per_iteration property.
# useful_skew_postconditioning_optimizations_per_iteration has default value.
## Tcl commands to replicate state of the useful_skew_postconditioning_slack_estimation_factor property.
# useful_skew_postconditioning_slack_estimation_factor has default value.
## Tcl commands to replicate state of the useful_skew_recluster_push_clock_gates_into_windows property.
# useful_skew_recluster_push_clock_gates_into_windows has default value.
## Tcl commands to replicate state of the useful_skew_refresh_adjustors_per_band_skew_pass property.
# useful_skew_refresh_adjustors_per_band_skew_pass has default value.
## Tcl commands to replicate state of the useful_skew_removable_clustering_delay_factor property.
# useful_skew_removable_clustering_delay_factor has default value.
## Tcl commands to replicate state of the useful_skew_report_detailed_slack_changes property.
# useful_skew_report_detailed_slack_changes has default value.
## Tcl commands to replicate state of the useful_skew_report_implementation_schedule_file property.
# useful_skew_report_implementation_schedule_file has default value.
## Tcl commands to replicate state of the useful_skew_report_implementation_skewing_offsets_file property.
# useful_skew_report_implementation_skewing_offsets_file has default value.
## Tcl commands to replicate state of the useful_skew_report_unbufferable_clock_nets_ideal_mode property.
# useful_skew_report_unbufferable_clock_nets_ideal_mode has default value.
## Tcl commands to replicate state of the useful_skew_save_ccopt_mode_for_save_restore property.
set_ccopt_property useful_skew_save_ccopt_mode_for_save_restore default
## Tcl commands to replicate state of the useful_skew_show_all_high_effort_path_group_timing_stats property.
# useful_skew_show_all_high_effort_path_group_timing_stats has default value.
## Tcl commands to replicate state of the useful_skew_sink_safety_margin property.
# useful_skew_sink_safety_margin has default value.
## Tcl commands to replicate state of the useful_skew_slack_window_tns_offset_factor property.
# useful_skew_slack_window_tns_offset_factor has default value.
## Tcl commands to replicate state of the useful_skew_slack_window_wns_offset_factor property.
# useful_skew_slack_window_wns_offset_factor has default value.
## Tcl commands to replicate state of the useful_skew_use_clock_gate_network_latencies property.
# useful_skew_use_clock_gate_network_latencies has default value.
## Tcl commands to replicate state of the useful_skew_use_clock_network_slacks property.
# useful_skew_use_clock_network_slacks has default value.
## Tcl commands to replicate state of the useful_skew_use_zero_delays_for_clock_domain_mode property.
# useful_skew_use_zero_delays_for_clock_domain_mode has default value.
## Tcl commands to replicate state of the useful_skew_window_size property.
# useful_skew_window_size has default value.
## Tcl commands to replicate state of the useful_skew_window_top_unit_delay_factor property.
# useful_skew_window_top_unit_delay_factor has default value.
## Tcl commands to replicate state of the user_skew_group property.
set_ccopt_property user_skew_group -skew_group default.clk/cons_mode 1
## Tcl commands to replicate state of the virtual_delay property.
# virtual_delay has default value for all objects.
## Tcl commands to replicate state of the virtual_delay_report_in_dag_stats_num_bins property.
# virtual_delay_report_in_dag_stats_num_bins has default value.
## Tcl commands to replicate state of the weak_driver_check_bounding_box_vs_drive_distance property.
# weak_driver_check_bounding_box_vs_drive_distance has default value.
## Tcl commands to replicate state of the write_clock_dag_hash_for_every_step property.
# write_clock_dag_hash_for_every_step has default value.
## Tcl commands to replicate state of the write_clock_dag_timing_stats_for_balancing_intermediate_steps property.
# write_clock_dag_timing_stats_for_balancing_intermediate_steps has default value.
## Tcl commands to replicate state of the write_routing_correlation_report_to_log property.
# write_routing_correlation_report_to_log has default value.
## Tcl commands to replicate state of the write_sink_depths_to_file property.
# write_sink_depths_to_file has default value.
#### End of writing state for properties.
